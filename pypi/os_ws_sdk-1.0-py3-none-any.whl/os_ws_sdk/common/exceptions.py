class WorkspaceException(Exception):

    error: int
    message: str

class ModelNotFoundError(Exception):
    def __init__(self, model: str):
        super().__init__(f"Модель {model=} не найдена")
