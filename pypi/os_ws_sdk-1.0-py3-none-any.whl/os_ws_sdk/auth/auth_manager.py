from os_ws_sdk.auth.credentials import Credentials


class AuthManager:
    def __init__(self, credentials: Credentials):
        self.credentials = credentials
