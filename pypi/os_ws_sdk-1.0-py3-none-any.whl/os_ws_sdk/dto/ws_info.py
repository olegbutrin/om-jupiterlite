from dataclasses import dataclass
from typing import Any, List

from dataclasses_json import dataclass_json, LetterCase

from os_ws_sdk.objects.base_object import BaseObject
from os_ws_sdk.objects.model import Model
from os_ws_sdk.dto.audit_settings_Info import AuditSettingsInfo
from os_ws_sdk.components.tag_message import TagMessage


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class WsInfo(BaseObject):
    workspace_name: str
    workspace_size_allowance: int
    current_workspace_size: int
    workspace_id: str
    model_ids: List[str]
    model_internal_ids: List[int]
    model_names: List[str]
    model_sources: List[List]
    storage_version: str
    model_summaries: List[Model]
    tag_summaries: List[TagMessage]
    audit_settings_info: AuditSettingsInfo
    flags: List[Any]
    check_license_status: bool
    concurrency_max: int
    concurrency_default: int
    active_model_only: bool
