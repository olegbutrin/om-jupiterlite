from dataclasses import dataclass, field
from typing import Optional

from dataclasses_json import dataclass_json, LetterCase, config

from os_ws_sdk.objects.base_object import BaseObject


def encode_str(value):
    return value.encode("utf-8").decode("utf-8")


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class ModelInfo(BaseObject):
    model_name: str = field(metadata=config(encoder=encode_str))
    cell_count: int
    memory: int
    model_id: str
    model_definition_serial_number: int
    is_offline: bool = False
