from dataclasses import dataclass

from dataclasses_json import dataclass_json, LetterCase

from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class CatalogViewInfo(BaseObject):
    id: int
    name: str
    model_id: str
    catalog_id: int