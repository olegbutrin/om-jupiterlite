import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.components.base_message import BaseMessage
from os_ws_sdk.components.cube_formula_message import (
    ChangeCubeFormulaMessage,
    GetCubesInfoMessage,
)


GET_CUBES_INFO_ACTION_ID = "GET_CUBES_INFO"

# Dynamic grid "Line Items" для конкретного мультикуба.
MULTICUBE_LINE_ITEMS_GRID_TYPE_ID = 137000000005

# System Property "Formula".
FORMULA_PROPERTY_ID = 4000000009

DEFAULT_CUBES_INFO_PAGE_SIZE = 100
DEFAULT_GRID_ROW_PAGE_SIZE = 500
DEFAULT_GRID_COLUMN_COUNT = 40


@dataclass
class CubeFormulaManager:
    """Читает и изменяет формулы кубов.

    Публичному пользователю достаточно передать только cube id и новый
    текст формулы. Multicube id, dynamic grid id и Formula property
    определяются внутри SDK автоматически.
    """

    model_id: str
    base_url: str
    connector: Any
    model_definition_serial_number: Optional[int] = None
    page_size: int = DEFAULT_CUBES_INFO_PAGE_SIZE
    grid_row_page_size: int = DEFAULT_GRID_ROW_PAGE_SIZE

    @classmethod
    def from_model(cls, model) -> "CubeFormulaManager":
        return cls(
            model_id=model.model_id,
            base_url=model.json_rpc_url,
            connector=model._connector,
            model_definition_serial_number=(
                model.model_definition_serial_number
            ),
        )

    async def get_formula(self, identifier: Union[int, str]) -> str:
        """Возвращает текст формулы куба по его longId."""
        _, cube_info = await self._get_cube_info(identifier)
        return self._formula_to_text(cube_info.get("formula"))

    async def change_formula(
        self,
        identifier: Union[int, str],
        formula: str,
    ) -> int:
        """Изменяет Formula-property куба и возвращает 1, либо 0 для no-op.

        SDK автоматически:
        1. находит куб через GET_CUBES_INFO;
        2. получает его moduleLongId;
        3. находит dynamic Line Items grid мультикуба;
        4. проверяет строку куба и редактируемость Formula;
        5. отправляет cellInput;
        6. повторно читает формулу и проверяет результат.
        """
        if identifier is None or str(identifier).strip() == "":
            raise WorkspaceException(
                400,
                "Идентификатор куба не может быть пустым",
            )
        if not isinstance(formula, str):
            raise WorkspaceException(
                400,
                "Параметр formula должен быть строкой",
            )

        cube_id, cube_info = await self._get_cube_info(identifier)
        current_formula = self._formula_to_text(
            cube_info.get("formula")
        )

        if current_formula == formula:
            return 0

        multicube_id = self._to_positive_int(
            cube_info.get("moduleLongId"),
            name="moduleLongId",
            context=f"куба id={identifier}",
        )

        grid_id = await self._find_multicube_line_items_grid(
            multicube_id
        )

        await self._validate_formula_cell(
            grid_id=grid_id,
            multicube_id=multicube_id,
            cube_id=cube_id,
        )

        message = ChangeCubeFormulaMessage(
            model_id=self.model_id,
            model_definition_serial_number=(
                self.model_definition_serial_number
            ),
            grid_id=grid_id,
            multicube_id=multicube_id,
            cube_id=cube_id,
            formula_property_id=FORMULA_PROPERTY_ID,
            current_formula=current_formula,
            new_formula=formula,
        )

        response = await self.connector._post(
            url=self.base_url,
            model=message,
        )
        self._validate_submission_response(
            response=response,
            cube_id=cube_id,
            data_type=(
                (cube_info.get("format") or {}).get("dataType")
                if isinstance(cube_info.get("format"), dict)
                else None
            ),
        )

        updated_formula = await self.get_formula(cube_id)
        if updated_formula != formula:
            raise WorkspaceException(
                500,
                "Формула куба после записи не совпала с ожидаемой: "
                f"id={cube_id}, expected={formula!r}, "
                f"actual={updated_formula!r}",
            )

        return 1

    async def _get_cube_info(
        self,
        identifier: Union[int, str],
    ) -> Tuple[Union[int, str], Dict[str, Any]]:
        wanted_identifier = self._normalize_identifier(identifier)
        if not wanted_identifier:
            raise WorkspaceException(
                400,
                "Идентификатор куба не может быть пустым",
            )

        start = 0

        while True:
            message = GetCubesInfoMessage(
                model_id=self.model_id,
                model_definition_serial_number=(
                    self.model_definition_serial_number
                ),
                start=start,
                count=self.page_size,
            )
            response = await self.connector._post(
                url=self.base_url,
                model=message,
            )
            result = self._get_action_result(
                response,
                GET_CUBES_INFO_ACTION_ID,
            )

            cube_infos = result.get("cubeInfos") or []
            cubes_label_page = result.get("cubesLabelPage") or {}
            entity_long_ids = self._flatten_page_values(
                cubes_label_page.get("entityLongIds")
            )

            if len(cube_infos) != len(entity_long_ids):
                raise WorkspaceException(
                    500,
                    "GET_CUBES_INFO вернул несогласованные cubeInfos и "
                    "cubesLabelPage.entityLongIds: "
                    f"{len(cube_infos)} != {len(entity_long_ids)}",
                )

            for cube_identifier, cube_info in zip(
                entity_long_ids,
                cube_infos,
            ):
                if (
                    self._normalize_identifier(cube_identifier)
                    != wanted_identifier
                ):
                    continue

                if not isinstance(cube_info, dict):
                    raise WorkspaceException(
                        500,
                        f"Некорректный cubeInfo для куба id={identifier}",
                    )

                return cube_identifier, cube_info

            total_count = self._to_non_negative_int(
                result.get("totalCount"),
                default=start + len(cube_infos),
            )
            returned_count = len(cube_infos)

            if (
                returned_count == 0
                or start + returned_count >= total_count
            ):
                break

            start += returned_count

        raise WorkspaceException(
            404,
            f"Куб с id={identifier} не найден",
        )

    async def _find_multicube_line_items_grid(
        self,
        multicube_id: int,
    ) -> int:
        # modelDefinitionSerialNumber=-1 принудительно запрашивает полный
        # modelInfo, где есть gridsInfos.gridInfo.
        message = BaseMessage(
            model_id=self.model_id,
            model_definition_serial_number=-1,
        )
        response = await self.connector._post(
            url=self.base_url,
            model=message,
        )

        if not isinstance(response, dict):
            raise WorkspaceException(
                500,
                "Не удалось получить modelInfo для поиска grid мультикуба",
            )

        top_level_error = response.get("error")
        if top_level_error:
            raise WorkspaceException(
                400,
                f"MODEL_INFO: {self._error_to_text(top_level_error)}",
            )

        model_info = (
            response
            .get("result", {})
            .get("modelInfo")
        )
        if not isinstance(model_info, dict):
            raise WorkspaceException(
                500,
                "Backend не вернул modelInfo для поиска grid мультикуба",
            )

        grids = (
            model_info
            .get("gridsInfos", {})
            .get("gridInfo", [])
        )
        if not isinstance(grids, list):
            grids = []

        matches = []
        for grid in grids:
            if not isinstance(grid, dict):
                continue
            if (
                self._normalize_identifier(
                    grid.get("gridTypeLongId")
                )
                == str(MULTICUBE_LINE_ITEMS_GRID_TYPE_ID)
                and self._normalize_identifier(
                    grid.get("contextEntityLongId")
                )
                == str(multicube_id)
            ):
                matches.append(grid)

        if not matches:
            raise WorkspaceException(
                404,
                "Не найден Line Items grid для мультикуба "
                f"id={multicube_id}",
            )

        if len(matches) > 1:
            raise WorkspaceException(
                500,
                "Найдено несколько Line Items grid для мультикуба "
                f"id={multicube_id}",
            )

        return self._to_positive_int(
            matches[0].get("entityLongId"),
            name="grid entityLongId",
            context=f"мультикуба id={multicube_id}",
        )

    async def _validate_formula_cell(
        self,
        *,
        grid_id: int,
        multicube_id: int,
        cube_id: Union[int, str],
    ) -> None:
        start_row = 0
        wanted_cube_id = self._normalize_identifier(cube_id)

        while True:
            raw = await self.connector.get_system_grid_data(
                url=self.base_url,
                model_id=self.model_id,
                grid_id=grid_id,
                model_definition_serial_number=(
                    self.model_definition_serial_number
                ),
                context_entity_long_id=multicube_id,
                start_row=start_row,
                start_column=0,
                row_count=self.grid_row_page_size,
                column_count=DEFAULT_GRID_COLUMN_COUNT,
            )

            row_pages = raw.get("rowLabelPages") or []
            column_pages = raw.get("columnLabelPages") or []
            data_pages = raw.get("dataPages") or []

            if not row_pages or not column_pages or not data_pages:
                raise WorkspaceException(
                    500,
                    "Line Items grid вернул неполные данные",
                )

            row_ids = self._flatten_page_values(
                row_pages[0].get("entityLongIds")
            )
            column_ids = self._flatten_page_values(
                column_pages[0].get("entityLongIds")
            )

            formula_column_index = self._index_of_identifier(
                column_ids,
                FORMULA_PROPERTY_ID,
            )
            if formula_column_index is None:
                raise WorkspaceException(
                    500,
                    "В Line Items grid не найдена колонка Formula "
                    f"(property id={FORMULA_PROPERTY_ID})",
                )

            row_index = self._index_of_identifier(
                row_ids,
                wanted_cube_id,
            )
            if row_index is not None:
                data_page = data_pages[0]
                column_count = self._to_non_negative_int(
                    data_page.get("columnCount"),
                    default=len(column_ids),
                )
                flat_index = (
                    row_index * column_count
                    + formula_column_index
                )

                editable = data_page.get("isEditable") or []
                if (
                    flat_index >= len(editable)
                    or not bool(editable[flat_index])
                ):
                    raise WorkspaceException(
                        403,
                        "Formula куба недоступна для редактирования: "
                        f"cube id={cube_id}, multicube id={multicube_id}",
                    )
                return

            returned_count = len(row_ids)
            if returned_count == 0:
                break
            if returned_count < self.grid_row_page_size:
                break

            start_row += returned_count

        raise WorkspaceException(
            404,
            "Куб не найден в Line Items grid своего мультикуба: "
            f"cube id={cube_id}, multicube id={multicube_id}",
        )

    @classmethod
    def _validate_submission_response(
        cls,
        *,
        response: Any,
        cube_id: Union[int, str],
        data_type: Optional[str],
    ) -> None:
        if not isinstance(response, dict):
            raise WorkspaceException(
                500,
                "Backend вернул некорректный ответ на изменение формулы",
            )

        top_level_error = response.get("error")
        if top_level_error:
            raise WorkspaceException(
                400,
                "Ошибка изменения формулы куба "
                f"id={cube_id}: {cls._error_to_text(top_level_error)}",
            )

        results = (
            response
            .get("result", {})
            .get("submissionResults", [])
        )
        if not isinstance(results, list) or not results:
            raise WorkspaceException(
                500,
                "Backend не вернул submissionResults "
                f"для изменения формулы куба id={cube_id}",
            )

        errors: List[Any] = []
        for result in results:
            if not isinstance(result, dict):
                continue

            modal_info = result.get("modalInfo")
            if isinstance(modal_info, dict) and modal_info.get("isError"):
                errors.append(cls._modal_info_to_text(modal_info))

            errors.extend(result.get("cellChangeErrorInfos") or [])

        if errors:
            type_context = (
                f", тип куба={data_type}"
                if data_type
                else ""
            )
            raise WorkspaceException(
                400,
                "Не удалось изменить формулу куба "
                f"id={cube_id}{type_context}: "
                f"{cls._error_to_text(errors)}",
            )

    @classmethod
    def _get_action_result(
        cls,
        response: Any,
        action_id: str,
    ) -> Dict[str, Any]:
        if not isinstance(response, dict):
            raise WorkspaceException(
                500,
                f"{action_id}: backend вернул некорректный ответ "
                f"типа {type(response).__name__}",
            )

        top_level_error = response.get("error")
        if top_level_error:
            raise WorkspaceException(
                400,
                f"{action_id}: {cls._error_to_text(top_level_error)}",
            )

        action_results = (
            response
            .get("result", {})
            .get("systemActionResults", [])
        )
        if not isinstance(action_results, list) or not action_results:
            raise WorkspaceException(
                404,
                f"{action_id}: в ответе отсутствует systemActionResults",
            )

        result = next(
            (
                item
                for item in action_results
                if isinstance(item, dict)
                and item.get("actionId") == action_id
            ),
            action_results[0],
        )
        if not isinstance(result, dict):
            raise WorkspaceException(
                500,
                f"{action_id}: systemActionResults содержит "
                "некорректный результат",
            )

        modal_info = result.get("modalInfo")
        if isinstance(modal_info, dict) and modal_info.get("isError"):
            raise WorkspaceException(
                400,
                f"{action_id}: {cls._modal_info_to_text(modal_info)}",
            )

        nested_error = result.get("error")
        if nested_error:
            raise WorkspaceException(
                400,
                f"{action_id}: {cls._error_to_text(nested_error)}",
            )

        return result

    @staticmethod
    def _formula_to_text(value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, str):
            return value
        return str(value)

    @staticmethod
    def _flatten_page_values(value: Any) -> List[Any]:
        if not isinstance(value, list):
            return []
        if not value:
            return []
        if len(value) == 1 and isinstance(value[0], list):
            return value[0]

        result: List[Any] = []
        for item in value:
            if isinstance(item, list):
                result.extend(item)
            else:
                result.append(item)
        return result

    @classmethod
    def _index_of_identifier(
        cls,
        values: List[Any],
        wanted: Any,
    ) -> Optional[int]:
        wanted_text = cls._normalize_identifier(wanted)
        for index, value in enumerate(values):
            if cls._normalize_identifier(value) == wanted_text:
                return index
        return None

    @staticmethod
    def _normalize_identifier(value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        text = str(value).strip()
        if text.endswith(".0") and text[:-2].lstrip("-").isdigit():
            text = text[:-2]
        return text

    @staticmethod
    def _to_non_negative_int(value: Any, default: int) -> int:
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            return default
        return parsed if parsed >= 0 else default

    @staticmethod
    def _to_positive_int(
        value: Any,
        *,
        name: str,
        context: str,
    ) -> int:
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            raise WorkspaceException(
                500,
                f"Некорректный {name} для {context}: {value!r}",
            )
        if parsed <= 0:
            raise WorkspaceException(
                500,
                f"Некорректный {name} для {context}: {value!r}",
            )
        return parsed

    @classmethod
    def _modal_info_to_text(cls, modal_info: Dict[str, Any]) -> str:
        message = modal_info.get("message") or {}
        if isinstance(message, dict):
            title = message.get("title")
            body = message.get("body")
            if title and body and str(title).strip().casefold() != "error":
                return f"{title}: {body}"
            if body:
                return str(body)
            if title:
                return str(title)

        error_trace = modal_info.get("errorTrace")
        if error_trace:
            return str(error_trace)

        return json.dumps(
            modal_info,
            ensure_ascii=False,
            default=str,
        )

    @staticmethod
    def _error_to_text(error: Any) -> str:
        if isinstance(error, str):
            return error

        if isinstance(error, dict):
            message = error.get("message")
            data = error.get("data")
            code = error.get("code")

            if isinstance(data, dict) and data.get("message"):
                data = data.get("message")

            parts = []
            if code is not None:
                parts.append(f"code={code}")
            if message:
                parts.append(str(message))
            if data:
                parts.append(str(data))
            if parts:
                return ": ".join(parts)

        return json.dumps(
            error,
            ensure_ascii=False,
            default=str,
        )
