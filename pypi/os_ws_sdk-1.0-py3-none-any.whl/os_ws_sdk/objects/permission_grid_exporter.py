"""Выгрузка матриц доступов Optimacros и нормализация прав пользователей."""

from __future__ import annotations

import ast
import json
import math
import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, TYPE_CHECKING

import pandas as pd

from os_ws_sdk.api.endpoints import JsonRPS
from os_ws_sdk.common.exceptions import WorkspaceException

if TYPE_CHECKING:
    from os_ws_sdk.api.v1.connector_v1 import ConnectorV1
    from os_ws_sdk.objects.model import Model
else:
    ConnectorV1 = Any


MULTICUBE_PERMISSIONS_GRID_LONG_ID = 137000000019
VERSION_PERMISSIONS_GRID_LONG_ID = 137000000015
LIST_PERMISSIONS_GRID_LONG_ID = 137000000012
MACRO_PERMISSIONS_GRID_LONG_ID = 137000000045

ACCESS_NONE = "none"
ACCESS_READ = "read"
ACCESS_WRITE = "write"

_READ_ACCESS_LONG_ID = 17000000001
_WRITE_ACCESS_LONG_ID = 17000000002
_NONE_ACCESS_LONG_ID = 17000000000

USER_PERMISSION_COLUMNS = [
    "user",
    "object_type",
    "object_id",
    "access_type",
    "role",
]

_USER_COLUMN_CANDIDATES = (
    "rowLabel",
    "User",
    "Пользователь",
    "Email",
    "E-mail",
    "Login",
    "Логин",
)

_USER_ROLES_COLUMN_CANDIDATES = (
    "User Roles",
    "Роли",
    "Roles",
    "User Role",
    "Роль",
    "Role",
)


@dataclass(frozen=True, slots=True)
class PermissionRoleColumn:
    """Связь longId роли, её отображаемого имени и колонки DataFrame."""

    role_id: Optional[int]
    role: str
    column: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role_id": self.role_id,
            "role": self.role,
            "column": self.column,
        }


@dataclass(slots=True)
class PermissionGridData:
    """Матрица доступов и метаданные её ролевых колонок."""

    dataframe: pd.DataFrame
    role_columns: List[PermissionRoleColumn]


class PermissionGridExporter:
    """Читает permission-grid с пагинацией одновременно по строкам и ролям."""

    def __init__(
        self,
        *,
        model_id: str,
        base_url: str,
        connector: ConnectorV1,
        model_definition_serial_number: Optional[int] = None,
    ) -> None:
        self.model_id = model_id
        self.base_url = base_url
        self.connector = connector
        self.model_definition_serial_number = model_definition_serial_number

    @classmethod
    def from_model(cls, model: "Model") -> "PermissionGridExporter":
        if model.base_url is None or model._connector is None:
            raise ValueError(
                "Model должен быть получен через Workspace.get_model(...)"
            )

        return cls(
            model_id=model.model_id,
            base_url=model.base_url,
            connector=model._connector,
            model_definition_serial_number=(
                model.model_definition_serial_number
            ),
        )

    @property
    def json_rpc_url(self) -> str:
        return f"{self.base_url.rstrip('/')}{JsonRPS.JSONRPC.value}"

    async def export(
        self,
        grid_id: int,
        *,
        row_page_size: int = 200,
        column_page_size: int = 100,
    ) -> PermissionGridData:
        """Возвращает полную матрицу прав, включая все строки и все роли."""

        self._validate_page_sizes(row_page_size, column_page_size)

        first_result = await self._get_page(
            grid_id=grid_id,
            start_row=0,
            start_column=0,
            row_count=row_page_size,
            column_count=column_page_size,
        )

        total_rows = self._non_negative_int(
            first_result.get("rowCount"),
            fallback=self._page_row_count(first_result),
        )
        total_columns = self._non_negative_int(
            first_result.get("columnCount"),
            fallback=self._page_column_count(first_result),
        )

        row_starts = list(range(0, total_rows, row_page_size))
        if not row_starts:
            row_starts = [0]

        column_starts = list(range(0, total_columns, column_page_size))
        if not column_starts:
            column_starts = [0]

        role_definitions: List[tuple[Optional[int], str]] = []
        role_columns: List[PermissionRoleColumn] = []
        row_frames: List[pd.DataFrame] = []

        for start_row in row_starts:
            row_ids: List[Any] = []
            row_labels: List[Any] = []
            horizontal_values: List[List[List[str]]] = []
            current_role_definitions: List[tuple[Optional[int], str]] = []
            expected_page_rows: Optional[int] = None

            for start_column in column_starts:
                if start_row == 0 and start_column == 0:
                    view_result = first_result
                else:
                    view_result = await self._get_page(
                        grid_id=grid_id,
                        start_row=start_row,
                        start_column=start_column,
                        row_count=row_page_size,
                        column_count=column_page_size,
                    )

                page = self._parse_page(view_result)

                if not row_ids:
                    row_ids = page["row_ids"]
                    row_labels = page["row_labels"]
                    expected_page_rows = len(page["values"])
                elif len(page["values"]) != expected_page_rows:
                    raise WorkspaceException(
                        500,
                        "Permission-grid вернул разное количество строк "
                        "на страницах столбцов",
                    )

                horizontal_values.append(page["values"])
                current_role_definitions.extend(page["roles"])

            if not role_definitions:
                role_definitions = current_role_definitions
                unique_columns = _make_unique_role_columns(
                    [role_name for _, role_name in role_definitions]
                )
                role_columns = [
                    PermissionRoleColumn(
                        role_id=role_id,
                        role=role_name,
                        column=column_name,
                    )
                    for (role_id, role_name), column_name in zip(
                        role_definitions,
                        unique_columns,
                    )
                ]
            elif current_role_definitions != role_definitions:
                raise WorkspaceException(
                    500,
                    "Набор ролей permission-grid изменился между страницами",
                )

            page_row_count = expected_page_rows or 0
            merged_values: List[List[str]] = []
            for row_index in range(page_row_count):
                merged_row: List[str] = []
                for page_values in horizontal_values:
                    merged_row.extend(page_values[row_index])
                merged_values.append(merged_row)

            row_frame = pd.DataFrame(
                merged_values,
                columns=[item.column for item in role_columns],
            )

            if len(row_ids) == page_row_count:
                row_frame.insert(0, "rowEntityLongId", row_ids)
            else:
                row_frame.insert(0, "rowEntityLongId", [None] * page_row_count)

            if len(row_labels) == page_row_count:
                row_frame.insert(1, "rowLabel", row_labels)
            else:
                row_frame.insert(1, "rowLabel", [None] * page_row_count)

            if page_row_count:
                row_frames.append(row_frame)
            elif total_rows == 0:
                row_frames = [row_frame]

        if row_frames:
            dataframe = pd.concat(row_frames, ignore_index=True)
        else:
            dataframe = pd.DataFrame(
                columns=[
                    "rowEntityLongId",
                    "rowLabel",
                    *[item.column for item in role_columns],
                ]
            )

        dataframe.attrs["grid_id"] = int(grid_id)
        dataframe.attrs["role_columns"] = [
            item.to_dict() for item in role_columns
        ]

        return PermissionGridData(
            dataframe=dataframe,
            role_columns=role_columns,
        )

    async def _get_page(
        self,
        *,
        grid_id: int,
        start_row: int,
        start_column: int,
        row_count: int,
        column_count: int,
    ) -> Dict[str, Any]:
        return await self.connector.get_system_grid_data(
            url=self.json_rpc_url,
            model_id=self.model_id,
            grid_id=grid_id,
            model_definition_serial_number=(
                self.model_definition_serial_number
            ),
            start_row=start_row,
            start_column=start_column,
            row_count=row_count,
            column_count=column_count,
        )

    @staticmethod
    def _validate_page_sizes(row_count: int, column_count: int) -> None:
        if row_count <= 0 or column_count <= 0:
            raise ValueError(
                "row_page_size и column_page_size должны быть больше 0"
            )
        if row_count + column_count > 100_000:
            raise ValueError(
                "Сумма row_page_size и column_page_size не должна "
                "превышать 100000"
            )
        if row_count * column_count > 40_000:
            raise ValueError(
                "Количество ячеек страницы не должно превышать 40000"
            )

    @staticmethod
    def _non_negative_int(value: Any, fallback: int) -> int:
        if isinstance(value, bool):
            return fallback
        if isinstance(value, int) and value >= 0:
            return value
        return fallback

    @classmethod
    def _parse_page(cls, view_result: Mapping[str, Any]) -> Dict[str, Any]:
        cls._raise_grid_error(view_result)

        column_page = cls._first_mapping(view_result.get("columnLabelPages"))
        row_page = cls._first_mapping(view_result.get("rowLabelPages"))
        data_page = cls._first_mapping(view_result.get("dataPages"))

        role_names = [
            str(value) if value not in (None, "") else "Role"
            for value in cls._flatten_axis(column_page.get("labels"))
        ]
        raw_role_ids = cls._flatten_axis(column_page.get("entityLongIds"))
        role_ids = [cls._normalize_optional_int(value) for value in raw_role_ids]

        if len(role_ids) < len(role_names):
            role_ids.extend([None] * (len(role_names) - len(role_ids)))
        elif len(role_ids) > len(role_names):
            role_ids = role_ids[: len(role_names)]

        row_ids = cls._flatten_axis(row_page.get("entityLongIds"))
        row_labels = cls._flatten_axis(row_page.get("labels"))

        column_count = len(role_names)
        if column_count == 0:
            column_count = cls._non_negative_int(
                data_page.get("columnCount"),
                fallback=0,
            )
            role_names = [f"Role {index}" for index in range(column_count)]
            role_ids = [None] * column_count

        cell_values = data_page.get("cellValues")
        cell_text = data_page.get("cellText")
        flat_values = cell_values if isinstance(cell_values, list) else []
        flat_text = cell_text if isinstance(cell_text, list) else []

        row_count = cls._non_negative_int(
            data_page.get("rowCount"),
            fallback=max(len(row_ids), len(row_labels)),
        )
        if row_count == 0 and column_count:
            row_count = max(
                len(flat_values) // column_count,
                len(flat_text) // column_count,
            )

        values: List[List[str]] = []
        for row_index in range(row_count):
            row: List[str] = []
            for column_index in range(column_count):
                flat_index = row_index * column_count + column_index
                text_value = (
                    flat_text[flat_index]
                    if flat_index < len(flat_text)
                    else None
                )
                raw_value = (
                    flat_values[flat_index]
                    if flat_index < len(flat_values)
                    else None
                )
                source_value = (
                    text_value if text_value not in (None, "") else raw_value
                )
                row.append(normalize_access_type(source_value))
            values.append(row)

        return {
            "roles": list(zip(role_ids, role_names)),
            "row_ids": row_ids,
            "row_labels": row_labels,
            "values": values,
        }

    @staticmethod
    def _raise_grid_error(view_result: Mapping[str, Any]) -> None:
        modal_info = view_result.get("modalInfo")
        if isinstance(modal_info, dict) and modal_info.get("isError"):
            message = modal_info.get("message") or {}
            body = (
                message.get("body")
                or message.get("title")
                or "Permission-grid returned error"
            )
            raise WorkspaceException(
                400,
                f"Ошибка permission-grid: {body}",
            )

    @staticmethod
    def _first_mapping(value: Any) -> Dict[str, Any]:
        if isinstance(value, list) and value and isinstance(value[0], dict):
            return value[0]
        return {}

    @staticmethod
    def _flatten_axis(value: Any) -> List[Any]:
        if not isinstance(value, list):
            return []
        if not value:
            return []
        if len(value) == 1 and isinstance(value[0], list):
            return list(value[0])
        if all(not isinstance(item, list) for item in value):
            return list(value)

        result: List[Any] = []
        for item in value:
            if isinstance(item, list):
                result.extend(item)
        return result

    @classmethod
    def _page_row_count(cls, view_result: Mapping[str, Any]) -> int:
        data_page = cls._first_mapping(view_result.get("dataPages"))
        return cls._non_negative_int(data_page.get("rowCount"), fallback=0)

    @classmethod
    def _page_column_count(cls, view_result: Mapping[str, Any]) -> int:
        data_page = cls._first_mapping(view_result.get("dataPages"))
        return cls._non_negative_int(data_page.get("columnCount"), fallback=0)

    @staticmethod
    def _normalize_optional_int(value: Any) -> Optional[int]:
        if value is None or isinstance(value, bool):
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if math.isnan(value):
                return None
            if value.is_integer():
                return int(value)
            return None
        text = str(value).strip()
        if re.fullmatch(r"-?\d+(?:\.0+)?", text):
            return int(float(text))
        return None


def normalize_access_type(value: Any) -> str:
    """Преобразует backend-код/текст доступа в write, read или none."""

    if value is None:
        return ACCESS_NONE

    if isinstance(value, bool):
        return ACCESS_READ if value else ACCESS_NONE

    if isinstance(value, float):
        if math.isnan(value):
            return ACCESS_NONE
        if value.is_integer():
            value = int(value)

    if isinstance(value, int):
        mapping = {
            _NONE_ACCESS_LONG_ID: ACCESS_NONE,
            _READ_ACCESS_LONG_ID: ACCESS_READ,
            _WRITE_ACCESS_LONG_ID: ACCESS_WRITE,
        }
        if value in mapping:
            return mapping[value]

    text = str(value).strip().casefold()
    if not text or text in {"none", "null", "nan", "false", "0"}:
        return ACCESS_NONE
    if text in {
        "read",
        "true",
        "1",
        str(_READ_ACCESS_LONG_ID),
        f"{_READ_ACCESS_LONG_ID}.0",
    }:
        return ACCESS_READ
    if text in {
        "write",
        str(_WRITE_ACCESS_LONG_ID),
        f"{_WRITE_ACCESS_LONG_ID}.0",
    }:
        return ACCESS_WRITE

    raise WorkspaceException(
        500,
        f"Неизвестное значение уровня доступа: {value!r}",
    )


def filter_permission_dataframe(
    dataframe: pd.DataFrame,
    object_id: Optional[int | str],
) -> pd.DataFrame:
    """Оставляет объект с точным rowEntityLongId; None означает все объекты."""

    if object_id is None:
        return dataframe

    if "rowEntityLongId" not in dataframe.columns:
        raise WorkspaceException(
            404,
            "В permission-grid отсутствует колонка rowEntityLongId",
        )

    wanted = _normalize_identifier(object_id)
    mask = dataframe["rowEntityLongId"].map(_normalize_identifier) == wanted
    result = dataframe.loc[mask].reset_index(drop=True)
    result.attrs = dict(dataframe.attrs)
    return result


def parse_user_roles(value: Any) -> List[Any]:
    """Разбирает одну роль или массив ролей из WS 9.300 без потери порядка."""

    if value is None:
        return []
    if isinstance(value, float) and math.isnan(value):
        return []

    if isinstance(value, (list, tuple, set)):
        raw_items = list(value)
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        raw_items = [value]
    else:
        text = str(value).strip()
        if not text:
            return []

        parsed: Any = None
        for loader in (json.loads, ast.literal_eval):
            try:
                parsed = loader(text)
                break
            except (ValueError, SyntaxError, TypeError, json.JSONDecodeError):
                continue

        if isinstance(parsed, (list, tuple, set)):
            raw_items = list(parsed)
        elif parsed is not None and not isinstance(parsed, dict):
            raw_items = [parsed]
        else:
            raw_items = [
                item.strip()
                for item in re.split(r"[,;|]", text.strip("[](){}"))
                if item.strip()
            ]

    result: List[Any] = []
    seen = set()
    for item in raw_items:
        normalized = _normalize_role_token(item)
        if normalized is None:
            continue
        key = (type(normalized), normalized)
        if key in seen:
            continue
        seen.add(key)
        result.append(normalized)
    return result


def build_user_permissions_dataframe(
    users: pd.DataFrame,
    permission_grids: Mapping[str, pd.DataFrame],
    ignore_missing_roles: bool = True
) -> pd.DataFrame:
    """Связывает пользователей с матрицами прав с учётом нескольких ролей."""

    if users is None or users.empty:
        return pd.DataFrame(columns=USER_PERMISSION_COLUMNS)

    user_column = _find_column(users, _USER_COLUMN_CANDIDATES)
    roles_column = _find_column(users, _USER_ROLES_COLUMN_CANDIDATES)

    if user_column is None:
        raise WorkspaceException(
            404,
            "В grid пользователей не найдена колонка пользователя",
        )
    if roles_column is None:
        if ignore_missing_roles:
            return pd.DataFrame(columns=USER_PERMISSION_COLUMNS)

        raise WorkspaceException(
            404,
            "В grid пользователей не найдена колонка ролей",
        )

    role_by_id: Dict[int, PermissionRoleColumn] = {}
    role_by_name: Dict[str, PermissionRoleColumn] = {}
    source_roles: Dict[str, List[PermissionRoleColumn]] = {}

    for object_type, dataframe in permission_grids.items():
        roles = _permission_roles_from_dataframe(dataframe)
        source_roles[object_type] = roles
        for role in roles:
            if role.role_id is not None:
                role_by_id.setdefault(role.role_id, role)
            role_by_name.setdefault(role.role.strip().casefold(), role)

    rows: List[Dict[str, Any]] = []

    for _, user_row in users.iterrows():
        user_value = user_row.get(user_column)
        if user_value is None or (
            isinstance(user_value, float) and math.isnan(user_value)
        ):
            continue
        user_name = str(user_value).strip()
        if not user_name:
            continue

        role_tokens = parse_user_roles(user_row.get(roles_column))
        resolved_roles: List[PermissionRoleColumn] = []
        resolved_seen = set()

        for token in role_tokens:
            role = None
            if isinstance(token, int):
                role = role_by_id.get(token)
            if role is None:
                role = role_by_name.get(str(token).strip().casefold())
            if role is None:
                if ignore_missing_roles:
                    continue

                raise WorkspaceException(
                    404,
                    f"Роль {token!r} пользователя {user_name!r} "
                    "не найдена в permission-grid",
                )

            role_key = role.role_id if role.role_id is not None else role.role
            if role_key in resolved_seen:
                continue
            resolved_seen.add(role_key)
            resolved_roles.append(role)

        for role in resolved_roles:
            for object_type, dataframe in permission_grids.items():
                role_column = _find_source_role_column(
                    role,
                    source_roles.get(object_type, []),
                )

                for _, permission_row in dataframe.iterrows():
                    object_id = _normalize_object_id(
                        permission_row.get("rowEntityLongId")
                    )
                    if object_id is None:
                        continue

                    access_type = (
                        normalize_access_type(permission_row.get(role_column))
                        if role_column is not None
                        else ACCESS_NONE
                    )

                    rows.append(
                        {
                            "user": user_name,
                            "object_type": object_type,
                            "object_id": object_id,
                            "access_type": access_type,
                            "role": role.role,
                        }
                    )

    return pd.DataFrame(rows, columns=USER_PERMISSION_COLUMNS)


def _permission_roles_from_dataframe(
    dataframe: pd.DataFrame,
) -> List[PermissionRoleColumn]:
    raw_roles = dataframe.attrs.get("role_columns", [])
    result: List[PermissionRoleColumn] = []

    if isinstance(raw_roles, list):
        for raw_role in raw_roles:
            if isinstance(raw_role, PermissionRoleColumn):
                result.append(raw_role)
                continue
            if not isinstance(raw_role, dict):
                continue
            column = raw_role.get("column")
            role = raw_role.get("role")
            if column is None or role is None:
                continue
            result.append(
                PermissionRoleColumn(
                    role_id=PermissionGridExporter._normalize_optional_int(
                        raw_role.get("role_id")
                    ),
                    role=str(role),
                    column=str(column),
                )
            )

    if result:
        return result

    # Fallback для вручную сформированных DataFrame без attrs.
    return [
        PermissionRoleColumn(
            role_id=None,
            role=str(column),
            column=str(column),
        )
        for column in dataframe.columns
        if column not in {"rowEntityLongId", "rowLabel"}
    ]


def _find_source_role_column(
    role: PermissionRoleColumn,
    source_roles: Sequence[PermissionRoleColumn],
) -> Optional[str]:
    if role.role_id is not None:
        for source_role in source_roles:
            if source_role.role_id == role.role_id:
                return source_role.column

    wanted_name = role.role.strip().casefold()
    for source_role in source_roles:
        if source_role.role.strip().casefold() == wanted_name:
            return source_role.column

    return None


def _find_column(
    dataframe: pd.DataFrame,
    candidates: Iterable[str],
) -> Optional[Any]:
    normalized = {
        str(column).strip().casefold(): column for column in dataframe.columns
    }
    for candidate in candidates:
        column = normalized.get(candidate.strip().casefold())
        if column is not None:
            return column
    return None


def _make_unique_role_columns(role_names: Sequence[str]) -> List[str]:
    counts: Dict[str, int] = {}
    result: List[str] = []
    for raw_name in role_names:
        name = str(raw_name) if raw_name not in (None, "") else "Role"
        count = counts.get(name, 0) + 1
        counts[name] = count
        result.append(name if count == 1 else f"{name}.{count}")
    return result


def _normalize_identifier(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        if math.isnan(value):
            return ""
        if value.is_integer():
            value = int(value)
    text = str(value).strip()
    if text.endswith(".0") and text[:-2].lstrip("-").isdigit():
        text = text[:-2]
    return text.casefold()


def _normalize_role_token(value: Any) -> Optional[Any]:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if math.isnan(value):
            return None
        if value.is_integer():
            return int(value)
        return str(value)
    text = str(value).strip().strip("'\"")
    if not text:
        return None
    if re.fullmatch(r"-?\d+(?:\.0+)?", text):
        return int(float(text))
    return text


def _normalize_object_id(value: Any) -> Optional[Any]:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if math.isnan(value):
            return None
        if value.is_integer():
            return int(value)
        return value
    text = str(value).strip()
    if not text:
        return None
    if re.fullmatch(r"-?\d+(?:\.0+)?", text):
        return int(float(text))
    return text
