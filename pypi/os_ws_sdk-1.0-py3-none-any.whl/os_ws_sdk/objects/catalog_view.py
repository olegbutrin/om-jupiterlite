"""Модуль с классом для представления Справочника и работы с ним."""

import os
from dataclasses import dataclass, field
from typing import Optional, Literal, List, Union
import pandas as pd

from dataclasses_json import dataclass_json, LetterCase, Exclude, config

from os_ws_sdk.api.endpoints import JsonRPS
from os_ws_sdk.api.v1.connector_v1 import ConnectorV1
from os_ws_sdk.components.download_format import DownloadFormat, DownloadFormatOM
from os_ws_sdk.components.encoding_type import EncodingTypeExport
from os_ws_sdk.components.export_view_message import (
    ExportViewOmMessage,
    ExportViewMessage,
)
from os_ws_sdk.components.import_view_message import ImportViewMessage
from os_ws_sdk.dto.catalog_view_info import CatalogViewInfo
from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class CatalogView(BaseObject):
    name: str
    id: int
    model_id: str
    catalog_id: int
    _connector: Optional[ConnectorV1] = field(
        metadata=config(exclude=Exclude.ALWAYS), default=None, repr=False
    )

    async def _create_export_view_message(
        self,
        **kwargs,
    ) -> ExportViewMessage:
        """Создает и возвращает экземпляр класса ExportViewMessage с параметрами экспорта представления справочника."""
        from os_ws_sdk.objects.catalog import Catalog

        return await Catalog._create_export_view_message(
            self,
            **kwargs,
        )


    async def _create_export_view_om_message(
        self,
        **kwargs,
    ) -> ExportViewOmMessage:
        """
        Создает и возвращает экземпляр класса сообщения запроса ExportViewOmMessage
        для экспорта представления в OM форматах.
        """

        from os_ws_sdk.objects.catalog import Catalog

        return await Catalog._create_export_view_om_message(self, **kwargs)

    async def _create_import_view_message(self) -> ImportViewMessage:
        """
        Создает экземпляр класса ImportViewMessage и наполняет его данными представления справочника.

        Возвращает:
            ImportViewMessage: Экземпляр класса ImportViewMessage с данными представления.
        """
        message_request = ImportViewMessage(
            model_id=self.model_id, module_long_id=self.catalog_id, key=self.id
        )
        return message_request

    @property
    def json_rpc_url(self) -> str:
        """
        Свойство, возвращающее URL для выполнения HTTP-запросов через /jsonrpc.

        Возвращает:
            str: URL для выполнения HTTP-запросов.
        """
        return str(self.base_url_safe / JsonRPS.JSONRPC.value.lstrip("/"))

    async def info(self) -> CatalogViewInfo:
        """
        Возвращает информацию о представлении справочника.

        Возвращает:
            dict: Информация о представлении справочника.
        """
        return CatalogViewInfo(
            id=self.id,
            name=self.name,
            model_id=self.model_id,
            catalog_id=self.catalog_id,
        )

    async def export_file(
        self,
        path: str,
        format: DownloadFormat = DownloadFormat.XLSX,
        escape: Literal[None, "\\", '"'] = "\\",
        decimal_separator: str = ".",
        delimiter: str = ";",
        enclosure: str = '"',
        encoding: EncodingTypeExport = EncodingTypeExport.UTF_8,
        filter_boolean_cube: Optional[List[int]] = None,
        filter_formula: Optional[List[Union[str, int]]] = None,
        filter_subset: Optional[List[int]] = None,
        filter_rows: Optional[
            List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
        ] = None,
        filter_cols: Optional[
            List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
        ] = None,
    ):
        """
        Экспортирует представление справочника в доступных форматах - XLSX задан по умолчанию.

        Аргументы:
            path (str): Путь к файлу
            format (DownloadFormat): Формат файла для экспорта, доступные варианты: CSV, TXT, XLS, XLSX
            escape (str): Экранирующий символ. Значение по умолчанию - "\\"
            decimalSeparator (str): Разделитель десятичной точки. Значение по умолчанию - "."
            delimiter (str): Разделитель значений. Значение по умолчанию - ";"
            enclosure (str): Значение, которое будет использовано для экранирования строковых значений. Значение по умолчанию - "'"
            encoding (EncodingType): Кодировка для записи файла. Значение по умолчанию - "utf-8", доступные варианты:"windows-1251","WINDOWS-1251","win","WIN","utf","UTF","utf-8" ,"UTF-8"
            filter_boolean_cube (List[int]): Фильтр по булеву кубу, по умолчанию не используется.
            filter_formula (List[Union[str, int]]): список со строкой-формулой и идентификатором измерения для фильтрации данных. Значение по умолчанию - None
            filter_subset (List[int]): список с идентификаторами измерений (измерение и сам сабсет) для фильтрации данных. Значение по умолчанию - None
            filter_rows (List[Literal["HIDE", "SHOW_ONLY"], List[int]]): список с типом отображения строк и их идентификаторами для фильтрации данных. Значение по умолчанию - None
            filter_cols (List[Literal["HIDE", "SHOW_ONLY"], List[int]]): список с типом отображения столбцов и их идентификаторами для фильтрации данных. Значение по умолчанию - None

        Возвращает:
            None
        """
        from os_ws_sdk.objects.catalog import Catalog

        await Catalog.export_file(
            self,
            path=path,
            format=format,
            escape=escape,
            decimal_separator=decimal_separator,
            delimiter=delimiter,
            enclosure=enclosure,
            encoding=encoding,
            filter_boolean_cube=filter_boolean_cube,
            filter_formula=filter_formula,
            filter_subset=filter_subset,
            filter_rows=filter_rows,
            filter_cols=filter_cols,
        )

    async def export_om_file(
        self,
        path: str,
        format: DownloadFormatOM = DownloadFormatOM.OM_CSV,
        escape: Literal[None, "\\", '"'] = "\\",
        decimal_separator: str = ".",
        delimiter: str = ";",
        enclosure: str = '"',
        encoding: EncodingTypeExport = EncodingTypeExport.UTF_8,
        boolean_cube_filter_long_id: Optional[int] = None,
        filter_formula: Optional[str] = None,
    ):
        """
        Экспорт представления справочника в форматах OM_* (данные непосредственно из БД) - CSV задан по умолчанию.

        Аргументы:
            path (str): Путь к файлу.
            format (DownloadFormatOM): Формат файла для экспорта, доступны OM_CSV, OM_TXT, OM_ZIP
            escape (str): Экранирующий символ. Значение по умолчанию - "\\"
            decimal_separator (str): Разделитель десятичной точки. Значение по умолчанию - "."
            delimiter (str): Разделитель значений. Значение по умолчанию - ";"
            enclosure (str): Значение, которое будет использовано для экранирования строковых значений. Значение по умолчанию - "'"
            encoding (EncodingType): Кодировка для записи файла. Значение по умолчанию - "utf-8", доступные варианты:"windows-1251","WINDOWS-1251","win","WIN","utf","UTF","utf-8" ,"UTF-8"
            boolean_cube_filter_long_id (int): Идентификатор болеан куба для фильтрации.
            filter_formula (str): Формула для фильтрации.

        Возвращает:
            None
        """

        from os_ws_sdk.objects.catalog import Catalog

        await Catalog.export_om_file(
            self,
            path=path,
            format=format,
            escape=escape,
            decimal_separator=decimal_separator,
            delimiter=delimiter,
            enclosure=enclosure,
            encoding=encoding,
            boolean_cube_filter_long_id=boolean_cube_filter_long_id,
            filter_formula=filter_formula,
        )

    async def import_file(self, path: str) -> None:
        """
        Импортирует представление справочника в модель.

        Аргументы:
            file_path (str): Путь к файлу с данными.
        Возвращает:
            None
        """
        message_request = await self._create_import_view_message()

        # Проверяем наличие файла по указанному пути
        if not os.path.exists(path):
            raise FileNotFoundError(f"Файл {path} не найден")

        # Осуществляем запрос на импорт
        await self._connector._post_file(
            url=self.json_rpc_url, model=message_request, file=rf"{path}"
        )

    async def export_df(
            self,
            format: DownloadFormat = DownloadFormat.CSV,
            escape: Literal[None, "\\", '"'] = "\\",
            decimal_separator: str = ".",
            delimiter: str = ";",
            enclosure: str = '"',
            encoding: EncodingTypeExport = EncodingTypeExport.UTF_8,
            filter_boolean_cube: Optional[List[int]] = None,
            filter_formula: Optional[List[Union[str, int]]] = None,
            filter_subset: Optional[List[int]] = None,
            filter_rows: Optional[
                List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
            ] = None,
            filter_cols: Optional[
                List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
            ] = None,
            **kwargs,
    ):
        """
        Получает данные представления каталога в виде DataFrame Pandas.

        Аргументы:
            format (DownloadFormat): Формат файла для экспорта. Рекомендуется CSV.
            escape (str): Экранирующий символ. По умолчанию "\\"
            decimal_separator (str): Разделитель десятичной точки. По умолчанию "."
            delimiter (str): Разделитель значений. По умолчанию ";"
            enclosure (str): Символ для экранирования строк. По умолчанию '"'
            encoding (EncodingTypeExport): Кодировка. По умолчанию UTF-8
            filter_boolean_cube (List[int]): Фильтр по булеву кубу
            filter_formula (List[Union[str, int]]): Фильтр по формуле
            filter_subset (List[int]): Фильтр по подмножеству
            filter_rows: Фильтр строк
            filter_cols: Фильтр столбцов
            **kwargs: Дополнительные параметры для pd.read_csv

        Возвращает:
            DataFrame: Экземпляр класса DataFrame Pandas.
        """
        from os_ws_sdk.objects.catalog import Catalog

        # Просто делегируем методу каталога
        return await Catalog.export_df(
            self,
            format=format,
            escape=escape,
            decimal_separator=decimal_separator,
            delimiter=delimiter,
            enclosure=enclosure,
            encoding=encoding,
            filter_boolean_cube=filter_boolean_cube,
            filter_formula=filter_formula,
            filter_subset=filter_subset,
            filter_rows=filter_rows,
            filter_cols=filter_cols,
            **kwargs,
        )

    async def get_elements(self, row_count: int = 1000000, column_count: int = 10000) -> tuple:
        """Возвращает кортеж из названий колонок и элементов представления справочника.

        Аргументы:
            row_count (int): Максимальное количество строк для загрузки. По умолчанию 1000000.
            column_count (int): Максимальное количество столбцов для загрузки. По умолчанию 10000.
        """
        # Получаем view_data для представления
        view_data = await self._connector.get_view_definition(
            url=self.json_rpc_url,
            model_id=self.model_id,
            view_id=self.id,
        )

        # Создаем сообщение для получения данных
        from os_ws_sdk.components.crud_catalog_message import GetDataCatalogMessage
        message_request = GetDataCatalogMessage(
            model_id=self.model_id,
            view_data=view_data,
            row_count=row_count,
            column_count=column_count
        )

        # Получаем данные
        data = (
            (await self._connector._post(url=self.json_rpc_url, model=message_request))
            .get("result")
            .get("viewRequestResults")[0]
        )

        # Извлекаем атрибуты и элементы
        attributes = data.get("columnLabelPages")[0].get("labels")[0]
        columns_count = len(attributes)
        elements = data.get("dataPages")[0].get("cellValues")

        # Формируем список элементов
        formatted_elements = [
            elements[i: i + columns_count]
            for i in range(0, len(elements), columns_count)
        ]

        return attributes, formatted_elements