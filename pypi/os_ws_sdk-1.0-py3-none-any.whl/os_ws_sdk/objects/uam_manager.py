"""Чтение UAM (иерархического избирательного доступа) справочников."""

from __future__ import annotations

import json
import math
import re
import uuid
from dataclasses import dataclass
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import pandas as pd

from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.components.base_message import BaseMessage
from os_ws_sdk.components.change_uam_message import ChangeUamMessage


LIST_UAM_GRID_LONG_ID = 137000000034
SELECTIVE_ACCESS_RELATION_PROPERTY_LONG_ID = 4000001005

UAM_ACCESS_NONE = "none"
UAM_ACCESS_READ = "read"
UAM_ACCESS_WRITE = "write"

_UAM_NONE_LONG_ID = 202000000001
_UAM_READ_LONG_ID = 202000000002
_UAM_WRITE_LONG_ID = 202000000003

_UAM_TEXT = {
    UAM_ACCESS_NONE: "None",
    UAM_ACCESS_READ: "Read",
    UAM_ACCESS_WRITE: "Write",
}


@dataclass(frozen=True, slots=True)
class UamUserColumn:
    """Связь пользователя с колонкой UAM-таблицы."""

    user_id: Optional[int]
    user: str
    column: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "user_id": self.user_id,
            "user": self.user,
            "column": self.column,
        }


@dataclass(slots=True)
class UamGridData:
    """Таблица UAM и метаданные её пользовательских колонок."""

    dataframe: pd.DataFrame
    list_id: int
    uam_grid_id: int
    user_columns: List[UamUserColumn]


@dataclass(frozen=True, slots=True)
class UamCellState:
    """Текущее backend-состояние одной ячейки UAM."""

    current_access: str
    current_text: Optional[str]
    no_current_value: bool


class UamManager:
    """Находит динамические UAM-гриды и выгружает их полностью."""

    def __init__(
        self,
        *,
        model_id: str,
        json_rpc_url: str,
        connector: Any,
        model_definition_serial_number: Optional[int] = None,
    ) -> None:
        self.model_id = model_id
        self.json_rpc_url = json_rpc_url
        self.connector = connector
        self.model_definition_serial_number = model_definition_serial_number

    @classmethod
    def from_model(cls, model: Any) -> "UamManager":
        if model._connector is None:
            raise ValueError(
                "Model должен быть получен через Workspace.get_model(...)"
            )

        return cls(
            model_id=model.model_id,
            json_rpc_url=model.json_rpc_url,
            connector=model._connector,
            model_definition_serial_number=(
                model.model_definition_serial_number
            ),
        )

    async def get_enabled_list_ids(self) -> List[int]:
        """Возвращает ID справочников, у которых включён UAM."""
        mapping = await self.get_uam_grid_mapping()
        return list(mapping.keys())

    async def get_uam_grid_mapping(self) -> Dict[int, int]:
        """Возвращает mapping ``list longId -> dynamic UAM grid longId``."""
        message = BaseMessage(
            model_id=self.model_id,
            model_definition_serial_number=-1,
        )
        response = await self.connector._post(
            url=self.json_rpc_url,
            model=message,
        )
        model_info = self._extract_model_info(response)
        grid_infos = (
            model_info
            .get("gridsInfos", {})
            .get("gridInfo", [])
        )

        if not isinstance(grid_infos, list):
            raise WorkspaceException(
                500,
                "modelInfo.gridsInfos.gridInfo имеет некорректный формат",
            )

        pairs: List[Tuple[int, int]] = []
        for item in grid_infos:
            if not isinstance(item, dict):
                continue
            if self._normalize_optional_int(item.get("gridTypeLongId")) != (
                LIST_UAM_GRID_LONG_ID
            ):
                continue

            list_id = self._normalize_optional_int(
                item.get("contextEntityLongId")
            )
            uam_grid_id = self._normalize_optional_int(
                item.get("entityLongId")
            )
            if list_id is None or uam_grid_id is None:
                continue
            pairs.append((list_id, uam_grid_id))

        pairs.sort(key=lambda pair: pair[0])
        mapping: Dict[int, int] = {}
        for list_id, uam_grid_id in pairs:
            existing = mapping.get(list_id)
            if existing is not None and existing != uam_grid_id:
                raise WorkspaceException(
                    500,
                    "Для справочника "
                    f"{list_id} найдено несколько UAM-гридов: "
                    f"{existing} и {uam_grid_id}",
                )
            mapping[list_id] = uam_grid_id

        return mapping

    async def get_uam(
        self,
        list_id: int | str,
        *,
        row_page_size: int = 200,
        column_page_size: int = 100,
    ) -> pd.DataFrame:
        """Выгружает полную UAM-матрицу справочника.

        Строки — элементы справочника, столбцы — пользователи. Значения
        унифицированы в ``write``, ``read`` и ``none`` для WS 9.200/9.300.
        """
        normalized_list_id = self._normalize_required_int(
            list_id,
            "ID справочника",
        )
        self._validate_page_sizes(row_page_size, column_page_size)

        mapping = await self.get_uam_grid_mapping()
        uam_grid_id = mapping.get(normalized_list_id)
        if uam_grid_id is None:
            raise WorkspaceException(
                400,
                f"Для справочника id={normalized_list_id} UAM не включён",
            )

        data = await self._export_uam_grid(
            list_id=normalized_list_id,
            uam_grid_id=uam_grid_id,
            row_page_size=row_page_size,
            column_page_size=column_page_size,
        )
        return data.dataframe

    async def change_uam(
        self,
        list_id: int | str,
        item_id: int | str,
        user: Any,
        permission: Any,
        *,
        row_page_size: int = 200,
        column_page_size: int = 100,
    ) -> bool:
        """Изменяет доступ пользователя к элементу UAM-справочника.

        ``user`` можно передать как longId пользователя либо как точное
        имя/email из заголовка UAM-таблицы. ``permission`` принимает
        ``write``, ``read`` и ``none``; Python ``None`` также означает
        ``none``. Перед записью метод проверяет, что UAM включён, что элемент
        и пользователь существуют, и читает текущее backend-значение ячейки.
        """
        normalized_list_id = self._normalize_required_int(
            list_id,
            "ID справочника",
        )
        normalized_item_id = self._normalize_required_int(
            item_id,
            "ID элемента справочника",
        )
        normalized_permission = self._normalize_permission(permission)
        self._validate_page_sizes(row_page_size, column_page_size)

        mapping = await self.get_uam_grid_mapping()
        uam_grid_id = mapping.get(normalized_list_id)
        if uam_grid_id is None:
            raise WorkspaceException(
                400,
                f"Для справочника id={normalized_list_id} UAM не включён",
            )

        data = await self._export_uam_grid(
            list_id=normalized_list_id,
            uam_grid_id=uam_grid_id,
            row_page_size=row_page_size,
            column_page_size=column_page_size,
        )

        row_index = self._find_item_row_index(
            data.dataframe,
            normalized_item_id,
        )
        user_index, user_column = self._resolve_user_column(
            data.user_columns,
            user,
        )
        if user_column.user_id is None:
            raise WorkspaceException(
                400,
                f"У пользователя {user_column.user!r} отсутствует longId",
            )

        cell_result = await self._get_page(
            list_id=normalized_list_id,
            uam_grid_id=uam_grid_id,
            start_row=row_index,
            start_column=user_index,
            row_count=1,
            column_count=1,
        )
        self._validate_target_cell(
            cell_result,
            item_id=normalized_item_id,
            user_id=user_column.user_id,
        )
        cell_state = self._extract_cell_state(cell_result)

        message = ChangeUamMessage(
            model_id=self.model_id,
            model_definition_serial_number=(
                self.model_definition_serial_number
            ),
            uam_grid_id=uam_grid_id,
            list_id=normalized_list_id,
            item_id=normalized_item_id,
            user_id=user_column.user_id,
            permission_property_id=(
                SELECTIVE_ACCESS_RELATION_PROPERTY_LONG_ID
            ),
            current_text=cell_state.current_text,
            no_current_value=cell_state.no_current_value,
            new_text=_UAM_TEXT[normalized_permission],
            message_id=f"messageId_{uuid.uuid4().hex}",
        )
        response = await self.connector._post(
            url=self.json_rpc_url,
            model=message,
        )
        self._raise_submission_error(
            response,
            operation=(
                "изменение UAM-доступа для справочника "
                f"id={normalized_list_id}, элемента "
                f"id={normalized_item_id}, пользователя "
                f"id={user_column.user_id}"
            ),
        )
        return True

    async def _export_uam_grid(
        self,
        *,
        list_id: int,
        uam_grid_id: int,
        row_page_size: int,
        column_page_size: int,
    ) -> UamGridData:
        first_result = await self._get_page(
            list_id=list_id,
            uam_grid_id=uam_grid_id,
            start_row=0,
            start_column=0,
            row_count=row_page_size,
            column_count=column_page_size,
        )

        total_rows = self._non_negative_int(
            first_result.get("rowCount"),
            fallback=self._page_row_count(first_result),
        )
        total_columns = self._non_negative_int(
            first_result.get("columnCount"),
            fallback=self._page_column_count(first_result),
        )

        row_starts = list(range(0, total_rows, row_page_size)) or [0]
        column_starts = (
            list(range(0, total_columns, column_page_size)) or [0]
        )

        user_definitions: List[Tuple[Optional[int], str]] = []
        user_columns: List[UamUserColumn] = []
        row_frames: List[pd.DataFrame] = []

        for start_row in row_starts:
            row_ids: List[Any] = []
            row_labels: List[Any] = []
            horizontal_values: List[List[List[str]]] = []
            current_user_definitions: List[Tuple[Optional[int], str]] = []
            expected_page_rows: Optional[int] = None

            for start_column in column_starts:
                if start_row == 0 and start_column == 0:
                    view_result = first_result
                else:
                    view_result = await self._get_page(
                        list_id=list_id,
                        uam_grid_id=uam_grid_id,
                        start_row=start_row,
                        start_column=start_column,
                        row_count=row_page_size,
                        column_count=column_page_size,
                    )

                page = self._parse_page(view_result)
                if not row_ids:
                    row_ids = page["row_ids"]
                    row_labels = page["row_labels"]
                    expected_page_rows = len(page["values"])
                elif len(page["values"]) != expected_page_rows:
                    raise WorkspaceException(
                        500,
                        "UAM-grid вернул разное количество строк "
                        "на страницах столбцов",
                    )

                horizontal_values.append(page["values"])
                current_user_definitions.extend(page["users"])

            if not user_definitions:
                user_definitions = current_user_definitions
                unique_columns = self._make_unique_columns(
                    [name for _, name in user_definitions]
                )
                user_columns = [
                    UamUserColumn(
                        user_id=user_id,
                        user=user_name,
                        column=column_name,
                    )
                    for (user_id, user_name), column_name in zip(
                        user_definitions,
                        unique_columns,
                    )
                ]
            elif current_user_definitions != user_definitions:
                raise WorkspaceException(
                    500,
                    "Набор пользователей UAM-grid изменился между страницами",
                )

            page_row_count = expected_page_rows or 0
            merged_values: List[List[str]] = []
            for row_index in range(page_row_count):
                merged_row: List[str] = []
                for page_values in horizontal_values:
                    merged_row.extend(page_values[row_index])
                merged_values.append(merged_row)

            row_frame = pd.DataFrame(
                merged_values,
                columns=[item.column for item in user_columns],
            )
            row_frame.insert(
                0,
                "rowEntityLongId",
                row_ids
                if len(row_ids) == page_row_count
                else [None] * page_row_count,
            )
            row_frame.insert(
                1,
                "rowLabel",
                row_labels
                if len(row_labels) == page_row_count
                else [None] * page_row_count,
            )

            if page_row_count:
                row_frames.append(row_frame)
            elif total_rows == 0:
                row_frames = [row_frame]

        if row_frames:
            dataframe = pd.concat(row_frames, ignore_index=True)
        else:
            dataframe = pd.DataFrame(
                columns=[
                    "rowEntityLongId",
                    "rowLabel",
                    *[item.column for item in user_columns],
                ]
            )

        dataframe.attrs["list_id"] = list_id
        dataframe.attrs["uam_grid_id"] = uam_grid_id
        dataframe.attrs["uam_grid_type_long_id"] = LIST_UAM_GRID_LONG_ID
        dataframe.attrs["selective_access_relation_property_long_id"] = (
            SELECTIVE_ACCESS_RELATION_PROPERTY_LONG_ID
        )
        dataframe.attrs["user_columns"] = [
            item.to_dict() for item in user_columns
        ]

        return UamGridData(
            dataframe=dataframe,
            list_id=list_id,
            uam_grid_id=uam_grid_id,
            user_columns=user_columns,
        )

    @classmethod
    def _find_item_row_index(
        cls,
        dataframe: pd.DataFrame,
        item_id: int,
    ) -> int:
        if "rowEntityLongId" not in dataframe.columns:
            raise WorkspaceException(
                500,
                "UAM-grid не содержит колонку rowEntityLongId",
            )

        matches = [
            index
            for index, value in enumerate(dataframe["rowEntityLongId"].tolist())
            if cls._normalize_optional_int(value) == item_id
        ]
        if not matches:
            raise WorkspaceException(
                404,
                f"Элемент справочника с id={item_id} не найден в UAM-grid",
            )
        if len(matches) > 1:
            raise WorkspaceException(
                500,
                f"Элемент справочника с id={item_id} встречается "
                "в UAM-grid несколько раз",
            )
        return matches[0]

    @classmethod
    def _resolve_user_column(
        cls,
        user_columns: Sequence[UamUserColumn],
        user: Any,
    ) -> Tuple[int, UamUserColumn]:
        numeric_user_id = cls._normalize_optional_int(user)
        if numeric_user_id is not None:
            matches = [
                (index, column)
                for index, column in enumerate(user_columns)
                if column.user_id == numeric_user_id
            ]
            if not matches:
                raise WorkspaceException(
                    404,
                    f"Пользователь с id={numeric_user_id} "
                    "не найден в UAM-grid",
                )
            if len(matches) > 1:
                raise WorkspaceException(
                    500,
                    f"Пользователь с id={numeric_user_id} встречается "
                    "в UAM-grid несколько раз",
                )
            return matches[0]

        if user is None:
            raise WorkspaceException(
                400,
                "Пользователь не может быть пустым",
            )

        search = str(user).strip().casefold()
        if not search:
            raise WorkspaceException(
                400,
                "Пользователь не может быть пустым",
            )

        matches = [
            (index, column)
            for index, column in enumerate(user_columns)
            if search in {
                str(column.user).strip().casefold(),
                str(column.column).strip().casefold(),
            }
        ]
        if not matches:
            raise WorkspaceException(
                404,
                f"Пользователь {user!r} не найден в UAM-grid",
            )
        if len(matches) > 1:
            ids = [column.user_id for _, column in matches]
            raise WorkspaceException(
                400,
                f"Имя пользователя {user!r} неоднозначно; "
                f"найдены longId: {ids}. Передай longId пользователя.",
            )
        return matches[0]

    @classmethod
    def _validate_target_cell(
        cls,
        view_result: Mapping[str, Any],
        *,
        item_id: int,
        user_id: int,
    ) -> None:
        cls._raise_grid_error(view_result)
        row_page = cls._first_mapping(view_result.get("rowLabelPages"))
        column_page = cls._first_mapping(view_result.get("columnLabelPages"))
        row_ids = [
            cls._normalize_optional_int(value)
            for value in cls._flatten_axis(row_page.get("entityLongIds"))
        ]
        user_ids = [
            cls._normalize_optional_int(value)
            for value in cls._flatten_axis(column_page.get("entityLongIds"))
        ]
        if row_ids != [item_id]:
            raise WorkspaceException(
                500,
                "UAM-grid вернул неожиданную строку при чтении "
                f"ячейки: ожидался {item_id}, получено {row_ids}",
            )
        if user_ids != [user_id]:
            raise WorkspaceException(
                500,
                "UAM-grid вернул неожиданного пользователя при чтении "
                f"ячейки: ожидался {user_id}, получено {user_ids}",
            )

    @classmethod
    def _extract_cell_state(
        cls,
        view_result: Mapping[str, Any],
    ) -> UamCellState:
        cls._raise_grid_error(view_result)
        data_page = cls._first_mapping(view_result.get("dataPages"))
        raw_values = data_page.get("cellValues")
        raw_texts = data_page.get("cellText")
        raw_value = (
            raw_values[0]
            if isinstance(raw_values, list) and raw_values
            else None
        )
        text_value = (
            raw_texts[0]
            if isinstance(raw_texts, list) and raw_texts
            else None
        )

        no_current_value = raw_value is None and text_value in (None, "")
        if no_current_value:
            return UamCellState(
                current_access=UAM_ACCESS_NONE,
                current_text=None,
                no_current_value=True,
            )

        source_value = (
            text_value if text_value not in (None, "") else raw_value
        )
        current_access = normalize_uam_access(source_value)
        return UamCellState(
            current_access=current_access,
            current_text=_UAM_TEXT[current_access],
            no_current_value=False,
        )

    @staticmethod
    def _normalize_permission(value: Any) -> str:
        if value is None:
            return UAM_ACCESS_NONE
        if isinstance(value, bool):
            raise WorkspaceException(
                400,
                "Значение UAM-доступа должно быть write, read или none",
            )

        text = str(value).strip().casefold()
        mapping = {
            "write": UAM_ACCESS_WRITE,
            "read": UAM_ACCESS_READ,
            "none": UAM_ACCESS_NONE,
            "null": UAM_ACCESS_NONE,
            "": UAM_ACCESS_NONE,
        }
        if text in mapping:
            return mapping[text]
        raise WorkspaceException(
            400,
            "Значение UAM-доступа должно быть одним из: "
            "write, read, none",
        )

    @classmethod
    def _raise_submission_error(
        cls,
        response: Any,
        *,
        operation: str,
    ) -> None:
        if not isinstance(response, dict):
            raise WorkspaceException(
                500,
                f"Не удалось выполнить {operation}: backend вернул "
                f"ответ типа {type(response).__name__}: {response!r}",
            )

        top_error = response.get("error")
        if top_error:
            raise WorkspaceException(
                400,
                f"Не удалось выполнить {operation}: "
                f"{cls._error_to_text(top_error)}",
            )

        result = response.get("result")
        if not isinstance(result, dict):
            raise WorkspaceException(
                500,
                f"Не удалось выполнить {operation}: "
                "в ответе отсутствует result",
            )

        nested_error = cls._find_nested_error(result)
        if nested_error:
            raise WorkspaceException(
                400,
                f"Не удалось выполнить {operation}: {nested_error}",
            )

    @classmethod
    def _find_nested_error(cls, value: Any) -> Optional[str]:
        if isinstance(value, dict):
            modal_info = value.get("modalInfo")
            if isinstance(modal_info, dict) and modal_info.get("isError"):
                message = modal_info.get("message") or {}
                if isinstance(message, dict):
                    text = message.get("body") or message.get("title")
                    if text:
                        return str(text)
                trace = modal_info.get("errorTrace")
                return str(trace) if trace else cls._error_to_text(modal_info)

            error = value.get("error")
            if error:
                return cls._error_to_text(error)

            messages = value.get("messages")
            if isinstance(messages, list):
                for message in messages:
                    if isinstance(message, dict) and (
                        message.get("isError")
                        or str(message.get("type", "")).casefold() == "error"
                    ):
                        return cls._error_to_text(message)

            for nested in value.values():
                found = cls._find_nested_error(nested)
                if found:
                    return found

        elif isinstance(value, list):
            for item in value:
                found = cls._find_nested_error(item)
                if found:
                    return found
        return None

    async def _get_page(
        self,
        *,
        list_id: int,
        uam_grid_id: int,
        start_row: int,
        start_column: int,
        row_count: int,
        column_count: int,
    ) -> Dict[str, Any]:
        return await self.connector.get_system_grid_data(
            url=self.json_rpc_url,
            model_id=self.model_id,
            grid_id=uam_grid_id,
            model_definition_serial_number=(
                self.model_definition_serial_number
            ),
            context_entity_long_id=list_id,
            start_row=start_row,
            start_column=start_column,
            row_count=row_count,
            column_count=column_count,
        )

    @classmethod
    def _parse_page(cls, view_result: Mapping[str, Any]) -> Dict[str, Any]:
        cls._raise_grid_error(view_result)

        column_page = cls._first_mapping(view_result.get("columnLabelPages"))
        row_page = cls._first_mapping(view_result.get("rowLabelPages"))
        data_page = cls._first_mapping(view_result.get("dataPages"))

        user_names = [
            str(value) if value not in (None, "") else "User"
            for value in cls._flatten_axis(column_page.get("labels"))
        ]
        raw_user_ids = cls._flatten_axis(column_page.get("entityLongIds"))
        user_ids = [cls._normalize_optional_int(value) for value in raw_user_ids]

        if len(user_ids) < len(user_names):
            user_ids.extend([None] * (len(user_names) - len(user_ids)))
        elif len(user_ids) > len(user_names):
            user_ids = user_ids[: len(user_names)]

        row_ids = cls._flatten_axis(row_page.get("entityLongIds"))
        row_labels = cls._flatten_axis(row_page.get("labels"))

        column_count = len(user_names)
        if column_count == 0:
            column_count = cls._non_negative_int(
                data_page.get("columnCount"),
                fallback=0,
            )
            user_names = [f"User {index}" for index in range(column_count)]
            user_ids = [None] * column_count

        raw_values = data_page.get("cellValues")
        raw_text = data_page.get("cellText")
        flat_values = raw_values if isinstance(raw_values, list) else []
        flat_text = raw_text if isinstance(raw_text, list) else []

        row_count = cls._non_negative_int(
            data_page.get("rowCount"),
            fallback=max(len(row_ids), len(row_labels)),
        )
        if row_count == 0 and column_count:
            row_count = max(
                len(flat_values) // column_count,
                len(flat_text) // column_count,
            )

        values: List[List[str]] = []
        for row_index in range(row_count):
            row: List[str] = []
            for column_index in range(column_count):
                flat_index = row_index * column_count + column_index
                text_value = (
                    flat_text[flat_index]
                    if flat_index < len(flat_text)
                    else None
                )
                raw_value = (
                    flat_values[flat_index]
                    if flat_index < len(flat_values)
                    else None
                )
                source_value = (
                    text_value if text_value not in (None, "") else raw_value
                )
                row.append(normalize_uam_access(source_value))
            values.append(row)

        return {
            "users": list(zip(user_ids, user_names)),
            "row_ids": row_ids,
            "row_labels": row_labels,
            "values": values,
        }

    @classmethod
    def _extract_model_info(cls, response: Any) -> Dict[str, Any]:
        if not isinstance(response, dict):
            raise WorkspaceException(
                500,
                "Получение UAM: backend вернул некорректный ответ "
                f"типа {type(response).__name__}",
            )

        if response.get("error"):
            raise WorkspaceException(
                400,
                "Получение UAM: " + cls._error_to_text(response["error"]),
            )

        result = response.get("result")
        if not isinstance(result, dict):
            raise WorkspaceException(
                404,
                "Получение UAM: в ответе отсутствует result",
            )

        model_info = result.get("modelInfo")
        if not isinstance(model_info, dict):
            raise WorkspaceException(
                404,
                "Получение UAM: в ответе отсутствует result.modelInfo",
            )
        return model_info

    @staticmethod
    def _raise_grid_error(view_result: Mapping[str, Any]) -> None:
        modal_info = view_result.get("modalInfo")
        if isinstance(modal_info, dict) and modal_info.get("isError"):
            message = modal_info.get("message") or {}
            body = (
                message.get("body")
                or message.get("title")
                or modal_info.get("errorTrace")
                or "UAM-grid returned error"
            )
            raise WorkspaceException(
                400,
                f"Ошибка UAM-grid: {body}",
            )

    @staticmethod
    def _validate_page_sizes(row_count: int, column_count: int) -> None:
        if row_count <= 0 or column_count <= 0:
            raise ValueError(
                "row_page_size и column_page_size должны быть больше 0"
            )
        if row_count + column_count > 100_000:
            raise ValueError(
                "Сумма row_page_size и column_page_size не должна "
                "превышать 100000"
            )
        if row_count * column_count > 40_000:
            raise ValueError(
                "Количество ячеек страницы не должно превышать 40000"
            )

    @staticmethod
    def _first_mapping(value: Any) -> Dict[str, Any]:
        if isinstance(value, list) and value and isinstance(value[0], dict):
            return value[0]
        return {}

    @staticmethod
    def _flatten_axis(value: Any) -> List[Any]:
        if not isinstance(value, list):
            return []
        if not value:
            return []
        if len(value) == 1 and isinstance(value[0], list):
            return list(value[0])
        if all(not isinstance(item, list) for item in value):
            return list(value)

        result: List[Any] = []
        for item in value:
            if isinstance(item, list):
                result.extend(item)
            else:
                result.append(item)
        return result

    @classmethod
    def _page_row_count(cls, view_result: Mapping[str, Any]) -> int:
        data_page = cls._first_mapping(view_result.get("dataPages"))
        return cls._non_negative_int(data_page.get("rowCount"), fallback=0)

    @classmethod
    def _page_column_count(cls, view_result: Mapping[str, Any]) -> int:
        data_page = cls._first_mapping(view_result.get("dataPages"))
        return cls._non_negative_int(data_page.get("columnCount"), fallback=0)

    @staticmethod
    def _non_negative_int(value: Any, fallback: int) -> int:
        if isinstance(value, bool):
            return fallback
        if isinstance(value, int) and value >= 0:
            return value
        return fallback

    @staticmethod
    def _normalize_optional_int(value: Any) -> Optional[int]:
        if value is None or isinstance(value, bool):
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if math.isnan(value):
                return None
            return int(value) if value.is_integer() else None
        text = str(value).strip()
        if re.fullmatch(r"-?\d+(?:\.0+)?", text):
            return int(float(text))
        return None

    @classmethod
    def _normalize_required_int(cls, value: Any, name: str) -> int:
        parsed = cls._normalize_optional_int(value)
        if parsed is None:
            raise WorkspaceException(
                400,
                f"{name} должен быть целым числом",
            )
        return parsed

    @staticmethod
    def _make_unique_columns(names: Sequence[str]) -> List[str]:
        counts: Dict[str, int] = {}
        result: List[str] = []
        for raw_name in names:
            name = str(raw_name) if raw_name not in (None, "") else "User"
            count = counts.get(name, 0) + 1
            counts[name] = count
            result.append(name if count == 1 else f"{name} ({count})")
        return result

    @staticmethod
    def _error_to_text(error: Any) -> str:
        if isinstance(error, str):
            return error
        if isinstance(error, dict):
            message = error.get("message")
            data = error.get("data")
            code = error.get("code")
            parts = []
            if code is not None:
                parts.append(f"code={code}")
            if message:
                parts.append(str(message))
            if data:
                parts.append(str(data))
            if parts:
                return ": ".join(parts)
        return json.dumps(error, ensure_ascii=False, default=str)


def normalize_uam_access(value: Any) -> str:
    """Преобразует UAM-код/текст WS 9.200/9.300 в write/read/none."""
    if value is None:
        return UAM_ACCESS_NONE

    if isinstance(value, float):
        if math.isnan(value):
            return UAM_ACCESS_NONE
        if value.is_integer():
            value = int(value)

    if isinstance(value, int) and not isinstance(value, bool):
        mapping = {
            _UAM_NONE_LONG_ID: UAM_ACCESS_NONE,
            _UAM_READ_LONG_ID: UAM_ACCESS_READ,
            _UAM_WRITE_LONG_ID: UAM_ACCESS_WRITE,
        }
        if value in mapping:
            return mapping[value]

    text = str(value).strip().casefold()
    if not text or text in {
        "none",
        "null",
        "nan",
        str(_UAM_NONE_LONG_ID),
        f"{_UAM_NONE_LONG_ID}.0",
    }:
        return UAM_ACCESS_NONE
    if text in {
        "read",
        str(_UAM_READ_LONG_ID),
        f"{_UAM_READ_LONG_ID}.0",
    }:
        return UAM_ACCESS_READ
    if text in {
        "write",
        str(_UAM_WRITE_LONG_ID),
        f"{_UAM_WRITE_LONG_ID}.0",
    }:
        return UAM_ACCESS_WRITE

    raise WorkspaceException(
        500,
        f"Неизвестное значение UAM-доступа: {value!r}",
    )
