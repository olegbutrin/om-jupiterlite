import os
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Union

from dataclasses_json import dataclass_json, LetterCase, config, Exclude

from os_ws_sdk.api.endpoints import JsonRPS
from os_ws_sdk.api.v1.connector_v1 import ConnectorV1
from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.components.action_info_message import ActionInfoMessage
from os_ws_sdk.components.crud_catalog_message import (
    CreateCatalogMessage,
    DeleteCatalogMessage,
    RenameCatalogMessage,
)
from os_ws_sdk.components.export_lp_mapping_message import ExportLpMappingMessage
from os_ws_sdk.components.get_ids_multicubes_message import (
    GetIdMulticubeByNameMessage,
)
from os_ws_sdk.components.import_lp_mapping_message import ImportLpMappingMessage
from os_ws_sdk.components.position import Position
from os_ws_sdk.components.recalc_model_message import ReCalcModelMessage
from os_ws_sdk.components.run_script_message import RunScriptMessage

from os_ws_sdk.components.scripts_history_filter import (
    ScriptRunType,
    ScriptStatus,
    TimeValue,
    TimestampValue,
    build_scripts_history_filter,
)

from os_ws_sdk.components.offline_mode_model_message import OfflineModeModelMessage, OnlineModeModelMessage

from os_ws_sdk.dto.model_info import ModelInfo
from os_ws_sdk.objects.base_object import BaseObject
from os_ws_sdk.objects.catalog import Catalog
from os_ws_sdk.objects.catalog_view import CatalogView
from os_ws_sdk.objects.multicube import Multicube


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class Model(BaseObject):
    model_name: str
    cell_count: int
    memory: int
    model_id: str
    viewed_at: Optional[int]
    tag_long_ids: List[int]
    workspace_folder_long_id: int
    auto_calc: bool
    last_sync_date: int
    created_at: int
    updated_at: int
    is_offline: bool
    serial: int
    is_multi_threaded_storage_communication: bool
    storage_version: str
    storage_build_executable: str
    is_set_storage_profiler: bool
    is_private: bool
    owner: Optional[Any]
    storage_read_mode: str
    macros_storage_read_mode: str
    backup_storage_read_mode: str
    storage_write_mode: str
    model_version: str
    restore_mode: bool
    is_in_queue_on_restore: bool
    model_definition_serial_number: int = 0
    _connector: Optional[ConnectorV1] = field(
        metadata=config(exclude=Exclude.ALWAYS), default=None, repr=False
    )

    def info(self) -> ModelInfo:
        """Получает информацию о модели."""
        return ModelInfo(
            model_name=self.model_name,
            cell_count=self.cell_count,
            memory=self.memory,
            model_id=self.model_id,
            model_definition_serial_number=self.model_definition_serial_number,
            is_offline=self.is_offline
        )

    @property
    def json_rpc_url(self) -> str:
        """
        Свойство, возвращающее URL для выполнения HTTP-запросов через /jsonrpc.

        Возвращает:
            str: URL для выполнения HTTP-запросов.
        """
        return str(self.base_url_safe / JsonRPS.JSONRPC.value.lstrip("/"))

    async def get_multicubes(self) -> List[Multicube]:
        """
        Получает список мультикубов модели.

        Аргументы:
            model_id (str): Идентификатор модели.

        Возвращает:
            dict - словарь мультикубов модели.
        """
        multicubes = await self._connector.get_multicubes(
            url=self.json_rpc_url, model_id=self.model_id
        )
        return [
            Multicube(
                name=name,
                id=id,
                model_id=self.model_id,
                base_url=str(self.base_url_safe),
                _connector=self._connector,
            )
            for name, id in zip(
                multicubes.get("entityIds", [[]])[0],
                multicubes.get("entityLongIds", [[]])[0],
            )
        ]

    async def get_multicube(self, id: int) -> Multicube | None:
        """
        Получаем информацию о мультикубе.

        Аргументы:
            id (str): id мультикуба

        Возвращает:
            Multicube: информация о мультикубе
        """
        multicubes = await self.get_multicubes()
        return next((multicube for multicube in multicubes if multicube.id == id), None)

    async def get_multicube_by_name(self, name: str) -> Multicube | None:
        """
        Получаем информацию о мультикубе.

        Аргументы:
            name (str): Имя мультикуба

        Возвращает:
            Multicube: информация о мультикубе
        """
        multicubes = await self.get_multicubes()
        return next(
            (multicube for multicube in multicubes if multicube.name == name), None
        )

    async def get_backup_list(self):
        """
        Выгружает системный grid со списком резервных копий модели.

        Используемый grid longId: 137000000030.

        Возвращает:
            pandas.DataFrame: все резервные копии модели.
        """
        from os_ws_sdk.objects.system_grid_exporter import GridTypeIdentifiers

        return await self._export_system_grid(GridTypeIdentifiers.BACKUPS_GRID)

    async def get_backup_info(self, id: int | str):
        """
        Получает строку системного grid для одной резервной копии.

        Поиск поддерживает как полный longId из колонки ``Идентификатор``,
        так и отображаемый номер вида ``#261047``.

        Аргументы:
            id: идентификатор резервной копии.

        Возвращает:
            pandas.DataFrame | None: DataFrame из одной строки или None,
            если резервная копия не найдена.
        """
        backups = await self.get_backup_list()
        return self._get_system_grid_row_by_id(
            backups,
            id,
            id_columns=(
                "rowEntityLongId",
                "rowLabel",
                "backupId",
                "Backup ID",
                "Backup Id",
                "Идентификатор",
                "Identifier",
                "ID",
                "Id",
                "id",
            ),
        )

    async def get_backup(self, id: int | str) -> bytes:
        """Скачивает резервную копию модели по её item ID.

        Endpoint Optimacros::

            /admin/models/model/{modelId}/backups/items/item/{id}/download/

        Аргументы:
            id: номер резервной копии, например ``227`` или ``"#227"``.

        Возвращает:
            bytes: бинарное содержимое файла резервной копии.

        Исключения:
            WorkspaceException: некорректный ID, HTTP-ошибка, пустой файл
            или ошибка подключения.
        """
        if isinstance(id, bool):
            raise WorkspaceException(
                400,
                "ID резервной копии должен быть положительным целым числом",
            )

        value = str(id).strip()
        if value.startswith("#"):
            value = value[1:].strip()

        if not value.isdigit() or int(value) <= 0:
            raise WorkspaceException(
                400,
                "ID резервной копии должен быть положительным целым числом",
            )

        backup_id = int(value)
        url = str(
            self.base_url_safe
            / "admin"
            / "models"
            / "model"
            / self.model_id
            / "backups"
            / "items"
            / "item"
            / str(backup_id)
            / "download"
        ) + "/"

        return await self._connector.download_backup(url=url)

    async def get_model_user_list(self):
        """
        Выгружает системный grid с пользователями модели.

        Используемый grid longId: 137000000027. Метод не зависит от названия
        колонки ролей, поэтому работает и до WS 9.300 с одной ролью, и начиная
        с WS 9.300 с мультиролевой моделью.

        Возвращает:
            pandas.DataFrame: все пользователи модели.
        """
        from os_ws_sdk.objects.system_grid_exporter import GridTypeIdentifiers

        return await self._export_system_grid(GridTypeIdentifiers.MODEL_USERS_GRID)

    async def get_model_user_info(self, id: int | str):
        """
        Получает строку системного grid для одного пользователя модели.

        В качестве id можно передать email/login пользователя либо longId,
        если он присутствует в выгруженном grid.

        Аргументы:
            id: идентификатор, email или login пользователя.

        Возвращает:
            pandas.DataFrame | None: DataFrame из одной строки или None,
            если пользователь не найден.
        """
        users = await self.get_model_user_list()
        return self._get_system_grid_row_by_id(
            users,
            id,
            id_columns=self._USER_GRID_ID_COLUMNS,
        )

    async def get_ws_user_list(self):
        """
        Выгружает системный grid с пользователями workspace.

        Используемый grid longId: 137000000028.

        Возвращает:
            pandas.DataFrame: все пользователи workspace.
        """
        from os_ws_sdk.objects.system_grid_exporter import GridTypeIdentifiers

        return await self._export_system_grid(GridTypeIdentifiers.WORKSPACE_USERS_GRID)

    async def get_ws_user_info(self, id: int | str):
        """
        Получает строку системного grid для одного пользователя workspace.

        В качестве id можно передать email/login пользователя либо longId,
        если он присутствует в выгруженном grid.

        Аргументы:
            id: идентификатор, email или login пользователя.

        Возвращает:
            pandas.DataFrame | None: DataFrame из одной строки или None,
            если пользователь не найден.
        """
        users = await self.get_ws_user_list()
        return self._get_system_grid_row_by_id(
            users,
            id,
            id_columns=self._USER_GRID_ID_COLUMNS,
        )

    async def get_multicube_permissions(self, id: Optional[int | str] = None):
        """Выгружает матрицу доступов к мультикубам (grid 137000000019).

        Строки — мультикубы, столбцы — роли. Значения доступа
        нормализованы в ``write``, ``read`` и ``none``. Если ``id`` указан,
        возвращаются только строки с соответствующим ``rowEntityLongId``.
        """
        from os_ws_sdk.objects.permission_grid_exporter import (
            MULTICUBE_PERMISSIONS_GRID_LONG_ID,
        )

        return await self._get_permission_grid(
            MULTICUBE_PERMISSIONS_GRID_LONG_ID,
            object_id=id,
        )

    async def get_version_permissions(self, id: Optional[int | str] = None):
        """Выгружает матрицу доступов к версиям (grid 137000000015)."""
        from os_ws_sdk.objects.permission_grid_exporter import (
            VERSION_PERMISSIONS_GRID_LONG_ID,
        )

        return await self._get_permission_grid(
            VERSION_PERMISSIONS_GRID_LONG_ID,
            object_id=id,
        )

    async def get_list_permissions(self, id: Optional[int | str] = None):
        """Выгружает матрицу доступов к справочникам (grid 137000000012)."""
        from os_ws_sdk.objects.permission_grid_exporter import (
            LIST_PERMISSIONS_GRID_LONG_ID,
        )

        return await self._get_permission_grid(
            LIST_PERMISSIONS_GRID_LONG_ID,
            object_id=id,
        )

    async def get_macro_permissions(self, id: Optional[int | str] = None):
        """Выгружает матрицу доступов к макросам (grid 137000000045)."""
        from os_ws_sdk.objects.permission_grid_exporter import (
            MACRO_PERMISSIONS_GRID_LONG_ID,
        )

        return await self._get_permission_grid(
            MACRO_PERMISSIONS_GRID_LONG_ID,
            object_id=id,
        )

    async def get_macros_permissions(self, id: Optional[int | str] = None):
        """Алиас ``get_macro_permissions`` для множественного числа."""
        return await self.get_macro_permissions(id=id)

    async def change_list_permission(
        self,
        list_id: int | str,
        role_id: int | str,
        permission: str,
    ) -> bool:
        """Изменяет доступ роли к справочнику.

        ``permission``: ``write``, ``read`` или ``none``. Перед отправкой
        текущий доступ читается из grid ``137000000012`` и передаётся в
        ``currentText``. Ошибки backend возвращаются как WorkspaceException.
        """
        from os_ws_sdk.objects.permission_change_manager import (
            PermissionChangeManager,
        )

        manager = PermissionChangeManager.from_model(self)
        return await manager.change_list_permission(
            list_id, role_id, permission
        )

    async def change_multicube_permission(
        self,
        multicube_id: int | str,
        role_id: int | str,
        permission: str,
    ) -> bool:
        """Изменяет доступ роли к мультикубу.

        ``permission``: ``write``, ``read`` или ``none``.
        """
        from os_ws_sdk.objects.permission_change_manager import (
            PermissionChangeManager,
        )

        manager = PermissionChangeManager.from_model(self)
        return await manager.change_multicube_permission(
            multicube_id, role_id, permission
        )

    async def change_version_permission(
        self,
        version_id: int | str,
        role_id: int | str,
        permission: str,
    ) -> bool:
        """Изменяет доступ роли к версии.

        ``permission``: ``write``, ``read`` или ``none``.
        """
        from os_ws_sdk.objects.permission_change_manager import (
            PermissionChangeManager,
        )

        manager = PermissionChangeManager.from_model(self)
        return await manager.change_version_permission(
            version_id, role_id, permission
        )

    async def change_macros_permission(
        self,
        macro_id: int | str,
        role_id: int | str,
        permission: Union[str, bool],
    ) -> bool:
        """Изменяет двоичный доступ роли к макросу/скрипту.

        В DP-91 поле ``4000001001`` принимает ``true``/``false``. Поэтому
        ``read`` и ``write`` включают доступ, а ``none`` выключает его.
        Также можно передать Python ``True`` или ``False``.
        """
        from os_ws_sdk.objects.permission_change_manager import (
            PermissionChangeManager,
        )

        manager = PermissionChangeManager.from_model(self)
        return await manager.change_macros_permission(
            macro_id, role_id, permission
        )

    async def change_macro_permission(
        self,
        macro_id: int | str,
        role_id: int | str,
        permission: Union[str, bool],
    ) -> bool:
        """Алиас для ``change_macros_permission``."""
        return await self.change_macros_permission(
            macro_id, role_id, permission
        )

    async def change_mscros_permission(
        self,
        macro_id: int | str,
        role_id: int | str,
        permission: Union[str, bool],
    ) -> bool:
        """Алиас с опечаткой из постановки DP-91."""
        return await self.change_macros_permission(
            macro_id, role_id, permission
        )

    async def get_user_permissions(self, *, ignore_missing_roles: bool = True,):
        """Связывает пользователей модели с правами каждой назначенной роли.

        Для WS 9.300 поддерживается мультиролевая модель: для каждой пары
        ``пользователь × роль × объект`` возвращается отдельная строка.

        Возвращает:
            pandas.DataFrame с колонками ``user``, ``object_type``,
            ``object_id``, ``access_type`` и ``role``.
        """
        from os_ws_sdk.objects.permission_grid_exporter import (
            build_user_permissions_dataframe,
        )

        users = await self.get_model_user_list()
        permission_grids = {
            "multicube": await self.get_multicube_permissions(),
            "list": await self.get_list_permissions(),
            "version": await self.get_version_permissions(),
            "macros": await self.get_macro_permissions(),
        }

        return build_user_permissions_dataframe(
            users,
            permission_grids,
            ignore_missing_roles=ignore_missing_roles,
        )

    async def get_userpermisions(self, *, ignore_missing_roles: bool = True,):
        return await self.get_user_permissions(ignore_missing_roles=ignore_missing_roles,)

    async def _get_permission_grid(
        self,
        grid_id: int,
        *,
        object_id: Optional[int | str] = None,
    ):
        from os_ws_sdk.objects.permission_grid_exporter import (
            PermissionGridExporter,
            filter_permission_dataframe,
        )

        exporter = PermissionGridExporter.from_model(self)
        permission_grid = await exporter.export(grid_id)
        return filter_permission_dataframe(
            permission_grid.dataframe,
            object_id,
        )

    async def get_list_uam(self) -> List[int]:
        """Возвращает ID справочников, у которых включён UAM.

        Список строится по ``result.modelInfo.gridsInfos.gridInfo``:
        выбираются записи с ``gridTypeLongId == 137000000034``, а ID
        справочника берётся из ``contextEntityLongId``.
        """
        from os_ws_sdk.objects.uam_manager import UamManager

        manager = UamManager.from_model(self)
        return await manager.get_enabled_list_ids()

    async def get_uam(self, id: int | str):
        """Выгружает UAM-таблицу справочника.

        Перед чтением проверяет, что UAM включён. Динамический longId грида
        определяется из ``modelInfo``. Строки результата — элементы
        справочника, столбцы — пользователи, значения — ``write``, ``read``
        или ``none``. Поддерживаются WS 9.200 и WS 9.300.

        Аргументы:
            id: longId справочника.

        Возвращает:
            pandas.DataFrame: полная матрица UAM с пагинацией по строкам
            и пользователям.

        Исключения:
            WorkspaceException: если UAM не включён либо backend вернул
            ошибку.
        """
        from os_ws_sdk.objects.uam_manager import UamManager

        manager = UamManager.from_model(self)
        return await manager.get_uam(id)

    async def change_uam(
        self,
        list_id: int | str,
        item_id: int | str,
        user: Any,
        permission: Any,
    ) -> bool:
        """Изменяет UAM-доступ пользователя к элементу справочника.

        Аргументы:
            list_id: longId справочника.
            item_id: longId элемента справочника.
            user: longId пользователя либо точное имя/email из UAM-грида.
            permission: ``write``, ``read`` или ``none``. Python ``None``
                также означает отсутствие доступа.

        Перед записью метод проверяет, что UAM включён, находит динамический
        UAM-grid, проверяет элемент и пользователя и читает текущее значение
        ячейки. Backend-ошибки возвращаются через ``WorkspaceException``.
        """
        from os_ws_sdk.objects.uam_manager import UamManager

        manager = UamManager.from_model(self)
        return await manager.change_uam(
            list_id,
            item_id,
            user,
            permission,
        )

    async def get_formula(self, id: int | str) -> str:
        """Возвращает текст формулы куба по его longId."""
        from os_ws_sdk.objects.cube_formula_manager import CubeFormulaManager

        manager = CubeFormulaManager.from_model(self)
        return await manager.get_formula(id)

    async def change_formula(
            self,
            id: int | str,
            formula: str,
    ) -> int:
        """Изменяет формулу куба по его longId.

        Пользователь передаёт только:
        - id куба;
        - новый текст формулы.

        Остальные данные SDK определяет автоматически.

        Возвращает:
            1 — формула изменена;
            0 — такая формула уже была установлена.
        """
        from os_ws_sdk.objects.cube_formula_manager import CubeFormulaManager

        manager = CubeFormulaManager.from_model(self)
        return await manager.change_formula(
            identifier=id,
            formula=formula,
        )

    async def get_script_list(self) -> List[int]:
        """
        Возвращает список ID скриптов модели.

        Используется системный grid ``137000000049`` с обязательным
        контекстом ``31000000010``.

        Возвращает:
            List[int]: ID скриптов из колонки ``Id`` в порядке грида.
        """
        from os_ws_sdk.objects.system_grid_exporter import (
            ACTION_SCRIPTS_CONTEXT_LONG_ID,
            ACTION_SCRIPTS_GRID_LONG_ID,
        )

        scripts = await self._export_system_grid(
            ACTION_SCRIPTS_GRID_LONG_ID,
            context_entity_long_id=ACTION_SCRIPTS_CONTEXT_LONG_ID,
        )

        id_column = self._find_dataframe_column(
            scripts,
            ["Id", "ID", "Identifier", "Идентификатор"],
        )
        if id_column is None:
            raise WorkspaceException(
                404,
                "В grid списка скриптов не найдена колонка Id. "
                f"Доступные колонки: {list(scripts.columns)}",
            )

        result: List[int] = []
        seen = set()

        for value in scripts[id_column].tolist():
            normalized = self._normalize_long_id(value)
            if not normalized or not normalized.lstrip("-").isdigit():
                continue

            script_id = int(normalized)
            if script_id in seen:
                continue

            seen.add(script_id)
            result.append(script_id)

        return result

    async def get_script_info(self, id: int | str):
        """
        Возвращает строку свойств скрипта по его ID.

        Аргументы:
            id: longId скрипта.

        Возвращает:
            pandas.DataFrame | None: одна строка grid либо ``None``,
            если скрипт не найден.
        """
        from os_ws_sdk.objects.system_grid_exporter import (
            ACTION_SCRIPTS_CONTEXT_LONG_ID,
            ACTION_SCRIPTS_GRID_LONG_ID,
        )

        scripts = await self._export_system_grid(
            ACTION_SCRIPTS_GRID_LONG_ID,
            context_entity_long_id=ACTION_SCRIPTS_CONTEXT_LONG_ID,
        )

        return self._get_system_grid_row_by_id(
            scripts,
            id,
            id_columns=(
                "Id",
                "ID",
                "Identifier",
                "Идентификатор",
                "rowEntityLongId",
                "rowLabel",
            ),
        )

    async def get_script_history(
        self,
        *,
        identifiers: Optional[Iterable[int]] = None,
        date_from: Optional[TimestampValue] = None,
        date_to: Optional[TimestampValue] = None,
        elapsed_time: Optional[Union[int, float]] = None,
        request_id: Optional[str] = None,
        run_type: Optional[Union[int, ScriptRunType]] = None,
        show_archive: Optional[bool] = None,
        status: Optional[Union[int, ScriptStatus]] = None,
        time_from: Optional[TimeValue] = None,
        time_to: Optional[TimeValue] = None,
        user: Optional[str] = None,
    ):
        """
        Выгружает историю запусков скриптов из grid ``137000000065``.

        Если ``date_from`` не указан, выгружается история за последние
        24 часа. Остальные неуказанные фильтры не ограничивают результат.
        ``date_from`` и ``date_to`` принимают Unix timestamp в секундах
        либо ``datetime``.

        ``status``:
            NONE=0, WAIT_IN_QUEUE=1, IN_PROGRESS=2, SUCCESS=3,
            FAILED=4, ABORTED=5.

        ``run_type``:
            INTERFACE=0, SCHEDULER=1, API=2.

        Возвращает:
            pandas.DataFrame: строки истории запусков.
        """
        from os_ws_sdk.objects.system_grid_exporter import (
            SCRIPTS_HISTORY_GRID_LONG_ID,
        )

        return await self._get_scripts_history_grid(
            SCRIPTS_HISTORY_GRID_LONG_ID,
            identifiers=identifiers,
            date_from=date_from,
            date_to=date_to,
            elapsed_time=elapsed_time,
            request_id=request_id,
            run_type=run_type,
            show_archive=show_archive,
            status=status,
            time_from=time_from,
            time_to=time_to,
            user=user,
        )

    async def get_script_chain_history(
        self,
        *,
        identifiers: Optional[Iterable[int]] = None,
        date_from: Optional[TimestampValue] = None,
        date_to: Optional[TimestampValue] = None,
        elapsed_time: Optional[Union[int, float]] = None,
        request_id: Optional[str] = None,
        run_type: Optional[Union[int, ScriptRunType]] = None,
        show_archive: Optional[bool] = None,
        status: Optional[Union[int, ScriptStatus]] = None,
        time_from: Optional[TimeValue] = None,
        time_to: Optional[TimeValue] = None,
        user: Optional[str] = None,
    ):
        """
        Выгружает историю цепочек скриптов из grid ``137000000066``.

        Набор фильтров совпадает с ``get_script_history``. Если
        ``date_from`` не указан, используется период последних 24 часов.

        Возвращает:
            pandas.DataFrame: строки истории цепочек скриптов.
        """
        from os_ws_sdk.objects.system_grid_exporter import (
            SCRIPTS_CHAIN_HISTORY_GRID_LONG_ID,
        )

        return await self._get_scripts_history_grid(
            SCRIPTS_CHAIN_HISTORY_GRID_LONG_ID,
            identifiers=identifiers,
            date_from=date_from,
            date_to=date_to,
            elapsed_time=elapsed_time,
            request_id=request_id,
            run_type=run_type,
            show_archive=show_archive,
            status=status,
            time_from=time_from,
            time_to=time_to,
            user=user,
        )

    async def _get_scripts_history_grid(
            self,
            grid_id,
            *,
            date_from=None,
            date_to=None,
            elapsed_time=None,
            identifiers=None,
            request_id=None,
            run_type=None,
            show_archive=None,
            status=None,
            time_from=None,
            time_to=None,
            user=None,
    ):
        history_filter = build_scripts_history_filter(
            date_from=date_from,
            date_to=date_to,
            elapsed_time=elapsed_time,
            identifiers=identifiers,
            request_id=request_id,
            run_type=run_type,
            show_archive=show_archive,
            status=status,
            time_from=time_from,
            time_to=time_to,
            user=user,
        )

        return await self._export_system_grid(
            grid_id,
            filter_type=history_filter["type"],
            filter_params=history_filter["params"],
        )

    _USER_GRID_ID_COLUMNS = (
        "rowEntityLongId",
        "rowLabel",
        "userId",
        "User ID",
        "User Id",
        "Идентификатор",
        "Identifier",
        "Email",
        "E-mail",
        "Пользователь",
        "User",
        "Login",
        "Логин",
        "ID",
        "Id",
        "id",
    )

    async def _export_system_grid(self, grid_type, **kwargs):
        """Выгружает один системный grid модели в pandas.DataFrame."""
        from os_ws_sdk.objects.system_grid_exporter import SystemGridExporter

        exporter = SystemGridExporter.from_model(self)
        return await exporter.export_df(grid_type, **kwargs)

    @staticmethod
    def _get_system_grid_row_by_id(dataframe, item_id, id_columns):
        """
        Фильтрует системный grid по идентификатору и возвращает одну строку.

        Сначала проверяются колонки идентификатора, затем безымянные колонки
        CSV и первая колонка grid. Если схема конкретной версии WS отличается,
        выполняется точный поиск по оставшимся колонкам.
        """
        if dataframe is None or dataframe.empty:
            return None

        wanted_id = Model._normalize_system_grid_identifier(item_id)
        if not wanted_id:
            return None

        normalized_columns = {
            str(column).strip().casefold(): column for column in dataframe.columns
        }
        ordered_columns = []

        for candidate in id_columns:
            column = normalized_columns.get(str(candidate).strip().casefold())
            if column is not None and column not in ordered_columns:
                ordered_columns.append(column)

        for column in dataframe.columns:
            if str(column).strip().casefold().startswith("unnamed:"):
                if column not in ordered_columns:
                    ordered_columns.append(column)

        first_column = dataframe.columns[0]
        if first_column not in ordered_columns:
            ordered_columns.append(first_column)

        remaining_columns = [
            column for column in dataframe.columns if column not in ordered_columns
        ]

        for columns in (ordered_columns, remaining_columns):
            if not columns:
                continue

            mask = None
            for column in columns:
                column_mask = dataframe[column].map(
                    Model._normalize_system_grid_identifier
                ) == wanted_id
                mask = column_mask if mask is None else mask | column_mask

            matched = dataframe.loc[mask]
            if not matched.empty:
                return matched.iloc[[0]].reset_index(drop=True)

        return None

    @staticmethod
    def _normalize_system_grid_identifier(value) -> str:
        """Нормализует int/float/str идентификаторы системных grid."""
        import math

        if value is None:
            return ""
        try:
            if isinstance(value, float) and math.isnan(value):
                return ""
        except TypeError:
            pass

        if isinstance(value, float) and value.is_integer():
            value = int(value)

        text = str(value).strip()
        if text.startswith("#"):
            text = text[1:].strip()
        if text.endswith(".0") and text[:-2].isdigit():
            text = text[:-2]
        return text.casefold()

    async def get_dashboard_multicube_links(
        self,
        dashboard_ids: Optional[List[int]] = None,
        request_delay: float = 0.5,
        ignore_errors: bool = True,
    ):
        """
        Возвращает pandas.DataFrame со связями dashboard -> multicube.

        Это основной вариант первого метода из ТЗ. Метод может работать
        полностью самостоятельно:

        - если dashboard_ids не переданы, сначала выгружает системный grid
          дашбордов 137000000022 и пытается найти dashboard longId;
        - затем по каждому dashboard_id вызывает GET_DASHBOARD_DEFINITION;
        - из definitionJsonString достает только виджеты с type == "cube";
        - собирает общий pandas.DataFrame со связями.

        Почему не используется напрямую CSV-export grid 137000000080:
        на некоторых стендах object references в CSV не раскрываются в реальные
        значения: Referenced Objects приходит как заглушка, а View Id пустой.

        Аргументы:
            dashboard_ids: необязательный список longId дашбордов. Если None,
                список будет получен из системного grid дашбордов.
            request_delay: пауза между запросами в секундах, чтобы не ловить
                timeout/semaphore errors на WS.
            ignore_errors: если True, ошибка по одному дашборду не остановит
                сбор остальных связей.

        Возвращает:
            pandas.DataFrame с колонками:
            dashboardId, optionId, objectIdentifier, type, name,
            multicubeId, gridId, savedViewId, positionX, positionY,
            positionW, positionH.
        """
        import asyncio

        if dashboard_ids is None:
            dashboard_ids = await self._get_dashboard_ids_from_system_grid()

        rows: List[Dict] = []

        for dashboard_id in dashboard_ids:
            try:
                rows.extend(await self._get_dashboard_multicubes_items(dashboard_id))
            except Exception:
                if not ignore_errors:
                    raise

            if request_delay:
                await asyncio.sleep(request_delay)

        return self._dashboard_multicubes_to_dataframe(rows)

    async def _get_dashboard_ids_from_system_grid(self) -> List[int]:
        """Получает dashboard longId из системного grid дашбордов 137000000022."""
        import re

        from os_ws_sdk.objects.system_grid_exporter import (
            GridTypeIdentifiers,
            SystemGridExporter,
        )

        exporter = SystemGridExporter.from_model(self)
        dashboards_df = await exporter.export_df(GridTypeIdentifiers.DASHBOARDS_GRID)

        dashboard_ids: List[int] = []
        seen = set()

        def add_candidate(value) -> None:
            if value is None:
                return

            text = str(value)
            for match in re.findall(r"\b115\d{9}\b", text):
                dashboard_id = int(match)
                if dashboard_id not in seen:
                    dashboard_ids.append(dashboard_id)
                    seen.add(dashboard_id)

        # Сначала смотрим названия колонок: иногда id может быть в заголовке.
        for column in dashboards_df.columns:
            add_candidate(column)

        # Затем все значения ячеек: это устойчивее к разным названиям колонок.
        for value in dashboards_df.to_numpy().ravel():
            add_candidate(value)

        if not dashboard_ids:
            raise WorkspaceException(
                404,
                "Не удалось автоматически найти dashboard longId в системном "
                "grid 137000000022. Передайте dashboard_ids явно.",
            )

        return dashboard_ids

    async def export_dashboard_multicube_links_grid(self, **read_csv_kwargs):
        """
        Выгружает исходный системный grid 137000000080 как CSV/DataFrame.

        Оставлено для диагностики. На проверенном стенде этот экспорт не подходит
        для результата первого метода, потому что object references не раскрываются
        в значения.
        """
        from os_ws_sdk.objects.system_grid_exporter import (
            GridTypeIdentifiers,
            SystemGridExporter,
        )

        exporter = SystemGridExporter.from_model(self)
        return await exporter.export_df(
            GridTypeIdentifiers.DASHBOARD_MULTICUBES_GRID,
            **read_csv_kwargs,
        )

    async def get_dashboard_multicubes(self, dashboard_id: int):
        """
        Возвращает pandas.DataFrame с мультикубами, размещенными на конкретном дашборде.

        Это второй метод из ТЗ. Запрос выполняется через системный action
        GET_DASHBOARD_DEFINITION. В результат попадают только виджеты
        с type == "cube". CSV метод не создает: при необходимости пользователь
        сам вызывает df.to_csv(...).

        Возвращает:
            pandas.DataFrame с колонками:
            dashboardId, optionId, objectIdentifier, type, name,
            multicubeId, gridId, savedViewId, positionX, positionY,
            positionW, positionH.
        """
        items = await self._get_dashboard_multicubes_items(dashboard_id)
        return self._dashboard_multicubes_to_dataframe(items)

    async def _get_dashboard_multicubes_items(self, dashboard_id: int) -> List[Dict]:
        """Возвращает внутренний список cube-виджетов дашборда для сборки DataFrame."""
        definition = await self._connector.get_dashboard_definition(
            url=self.json_rpc_url,
            model_id=self.model_id,
            dashboard_id=dashboard_id,
            model_definition_serial_number=self.model_definition_serial_number,
        )
        return self._parse_dashboard_multicubes(
            definition=definition,
            dashboard_id=dashboard_id,
        )

    @staticmethod
    def _dashboard_multicubes_to_dataframe(items: List[Dict]):
        """Преобразует внутренний список cube-виджетов в стабильный pandas.DataFrame."""
        import pandas as pd

        columns = [
            "dashboardId",
            "optionId",
            "objectIdentifier",
            "type",
            "name",
            "multicubeId",
            "gridId",
            "savedViewId",
            "positionX",
            "positionY",
            "positionW",
            "positionH",
        ]

        rows = []
        for item in items:
            position = item.get("position") or {}
            rows.append(
                {
                    "dashboardId": item.get("dashboardId"),
                    "optionId": item.get("optionId"),
                    "objectIdentifier": item.get("objectIdentifier"),
                    "type": item.get("type"),
                    "name": item.get("name"),
                    "multicubeId": item.get("multicubeId"),
                    "gridId": item.get("gridId"),
                    "savedViewId": item.get("savedViewId"),
                    "positionX": position.get("x"),
                    "positionY": position.get("y"),
                    "positionW": position.get("w"),
                    "positionH": position.get("h"),
                }
            )

        return pd.DataFrame(rows, columns=columns)

    @staticmethod
    def _parse_dashboard_multicubes(
        definition: Dict,
        dashboard_id: Optional[int] = None,
    ) -> List[Dict]:
        """Извлекает cube-виджеты из JSON definition дашборда.

        В разных версиях WS cube-виджет может быть помечен как {"type": "cube"},
        а может приходить без type, но с признаками виджета: gridId,
        viewDefinition/staticContextIdentifiers, params, position. Поэтому парсер
        ищет не только type == "cube", но и такие структуры.
        """

        def is_cube_option(value: Dict) -> bool:
            if not isinstance(value, dict):
                return False

            # По ТЗ нужны именно мультикубы, поэтому chart/button/textarea
            # не должны попадать в результат, даже если у chart есть gridId
            # и viewDefinition.
            return value.get("type") == "cube"

        def walk(value):
            if isinstance(value, dict):
                if is_cube_option(value):
                    yield value
                for nested_value in value.values():
                    yield from walk(nested_value)
            elif isinstance(value, list):
                for item in value:
                    yield from walk(item)

        result: List[Dict] = []
        seen = set()
        for option in walk(definition):
            view_definition = option.get("viewDefinition") or {}
            params = option.get("params") or {}

            static_context_identifiers = view_definition.get(
                "staticContextIdentifiers",
                [],
            )

            static_context_identifier = (
                static_context_identifiers[0]
                if static_context_identifiers
                else None
            )

            multicube_id = (
                    option.get("multicubeId")
                    or option.get("multicubeLongId")
                    or static_context_identifier
            )

            grid_id = (
                    option.get("gridId")
                    or option.get("gridLongId")
            )

            saved_view_id = (
                    option.get("savedViewId")
                    or option.get("savedViewLongId")
                    or view_definition.get("savedViewId")
                    or view_definition.get("savedViewLongId")
                    or params.get("savedViewId")
                    or params.get("selectedView")
            )

            option_key = (
                option.get("objectIdentifier"),
                option.get("id"),
                grid_id,
                multicube_id,
                saved_view_id,
            )

            if option_key in seen:
                continue

            seen.add(option_key)

            result.append(
                {
                    "dashboardId": dashboard_id,
                    "optionId": option.get("id"),
                    "objectIdentifier": option.get("objectIdentifier"),
                    "type": option.get("type"),
                    "name": params.get("name") or option.get("name"),
                    "multicubeId": multicube_id,
                    "gridId": grid_id,
                    "savedViewId": saved_view_id,
                    "staticContextIdentifiers": static_context_identifiers,
                    "position": option.get("position"),
                    "params": params,
                    "viewDefinition": view_definition,
                    "rawOption": option,
                }
            )
        return result


    async def get_optimizer_requests_grid(
        self,
        entity_default_view_entity_long_id: Optional[int] = None,
        start_row: int = 0,
        start_column: int = 0,
        row_count: int = 1000,
        column_count: int = 20,
    ):
        """
        Возвращает pandas.DataFrame с системной таблицей optimizer requests.

        Запрос выполняется через viewRequest с key="OPTIMIZER_REQUESTS_TABLES".
        Метод CSV не создает: при необходимости пользователь сам вызывает
        df.to_csv(...).

        Аргументы:
            entity_default_view_entity_long_id: optional viewReference из WS.
                Если конкретный стенд требует viewReference, передайте сюда значение
                entityDefaultViewEntityLongId из отладочного запроса.
            start_row/start_column/row_count/column_count: параметры страницы
                данных таблицы.

        Возвращает:
            pandas.DataFrame с колонками из системной таблицы. Если WS вернул
            row labels / row entity longIds, они добавляются в колонки
            requestName и optimizerRequestId.
        """
        view_result = await self._connector.get_optimizer_requests_table(
            url=self.json_rpc_url,
            model_id=self.model_id,
            entity_default_view_entity_long_id=entity_default_view_entity_long_id,
            model_definition_serial_number=self.model_definition_serial_number,
            start_row=start_row,
            start_column=start_column,
            row_count=row_count,
            column_count=column_count,
        )
        return self._view_request_result_to_dataframe(
            view_result,
            row_label_column="requestName",
            row_id_column="optimizerRequestId",
        )

    async def get_optimizer_requests(
        self,
        entity_default_view_entity_long_id: Optional[int] = None,
        start_row: int = 0,
        start_column: int = 0,
        row_count: int = 1000,
        column_count: int = 20,
    ):
        """Alias для get_optimizer_requests_grid(...)."""
        return await self.get_optimizer_requests_grid(
            entity_default_view_entity_long_id=entity_default_view_entity_long_id,
            start_row=start_row,
            start_column=start_column,
            row_count=row_count,
            column_count=column_count,
        )

    async def get_optimizer_request_fields(
        self,
        optimizer_request_id: int,
        entity_default_view_entity_long_id: Optional[int] = None,
        start_row: int = 0,
        row_count: int = 1000,
        column_count: int = 20,
    ):
        """
        Возвращает pandas.DataFrame с текстами Цели/Переменные/Ограничения
        для одного optimizer request.

        Результат — DataFrame из одной строки с колонками:
        optimizerRequestId, requestName, goals, variables, constraints.
        """
        import pandas as pd

        requests_df = await self.get_optimizer_requests_grid(
            entity_default_view_entity_long_id=entity_default_view_entity_long_id,
            start_row=start_row,
            row_count=row_count,
            column_count=column_count,
        )

        id_column = self._find_dataframe_column(
            requests_df,
            [
                "optimizerRequestId",
                "Идентификатор",
                "Identifier",
                "ID",
                "Id",
                "id",
            ],
        )
        if id_column is None:
            raise WorkspaceException(
                404,
                "В таблице optimizer requests не найдена колонка с идентификатором. "
                f"Доступные колонки: {list(requests_df.columns)}",
            )

        wanted_id = self._normalize_long_id(optimizer_request_id)
        mask = requests_df[id_column].map(self._normalize_long_id) == wanted_id
        matched = requests_df.loc[mask]
        if matched.empty:
            raise WorkspaceException(
                404,
                f"Optimizer request с id={optimizer_request_id} не найден",
            )

        row = matched.iloc[0]
        request_name_column = self._find_dataframe_column(
            requests_df,
            [
                "requestName",
                "Название",
                "Наименование",
                "Name",
                "Имя",
                "Unnamed: 0",
            ],
        )
        goals_column = self._find_dataframe_column(
            requests_df,
            ["Цели", "Цель", "Goals", "Goal", "Objectives", "Objective"],
        )
        variables_column = self._find_dataframe_column(
            requests_df,
            ["Переменные", "Переменная", "Variables", "Variable"],
        )
        constraints_column = self._find_dataframe_column(
            requests_df,
            [
                "Ограничения",
                "Ограничение",
                "Constraints",
                "Constraint",
                "Restrictions",
                "Restriction",
            ],
        )

        missing = []
        if goals_column is None:
            missing.append("Цели")
        if variables_column is None:
            missing.append("Переменные")
        if constraints_column is None:
            missing.append("Ограничения")
        if missing:
            raise WorkspaceException(
                404,
                "В таблице optimizer requests не найдены колонки: "
                + ", ".join(missing)
                + f". Доступные колонки: {list(requests_df.columns)}",
            )

        result = [
            {
                "optimizerRequestId": optimizer_request_id,
                "requestName": self._cell_to_text(row.get(request_name_column))
                if request_name_column
                else None,
                "goals": self._cell_to_text(row.get(goals_column)),
                "variables": self._cell_to_text(row.get(variables_column)),
                "constraints": self._cell_to_text(row.get(constraints_column)),
            }
        ]
        return pd.DataFrame(
            result,
            columns=[
                "optimizerRequestId",
                "requestName",
                "goals",
                "variables",
                "constraints",
            ],
        )

    @staticmethod
    def _view_request_result_to_dataframe(
        view_result: Dict,
        row_label_column: str = "rowLabel",
        row_id_column: str = "rowEntityLongId",
    ):
        """Преобразует стандартный viewRequestResult WS в pandas.DataFrame."""
        import pandas as pd

        modal_info = view_result.get("modalInfo") if isinstance(view_result, dict) else None
        if isinstance(modal_info, dict) and modal_info.get("isError"):
            message = modal_info.get("message") or {}
            body = (
                message.get("body")
                or message.get("title")
                or "System grid returned error"
            )
            raise WorkspaceException(
                400,
                f"Ошибка системного grid: {body}",
            )

        def ensure_list(value):
            return value if isinstance(value, list) else []

        def normalize_labels(labels):
            labels = ensure_list(labels)
            if not labels:
                return []
            if all(not isinstance(item, list) for item in labels):
                return labels
            if len(labels) == 1 and isinstance(labels[0], list):
                return labels[0]

            rows = [row for row in labels if isinstance(row, list)]
            if not rows:
                return []
            max_len = max(len(row) for row in rows)
            result = []
            for index in range(max_len):
                parts = []
                for row in rows:
                    if index < len(row):
                        value = row[index]
                        if value not in (None, ""):
                            parts.append(str(value))
                result.append(" / ".join(parts) if parts else f"Column {index}")
            return result

        def first_page_value(pages, key):
            pages = ensure_list(pages)
            if not pages or not isinstance(pages[0], dict):
                return []
            return pages[0].get(key, [])

        column_labels = normalize_labels(
            first_page_value(view_result.get("columnLabelPages"), "labels")
        )
        row_labels = normalize_labels(
            first_page_value(view_result.get("rowLabelPages"), "labels")
        )
        row_entity_long_ids = normalize_labels(
            first_page_value(view_result.get("rowLabelPages"), "entityLongIds")
        )

        data_pages = ensure_list(view_result.get("dataPages"))
        cell_values = []
        if data_pages and isinstance(data_pages[0], dict):
            cell_values = data_pages[0].get("cellValues", [])

        if cell_values and all(isinstance(row, list) for row in cell_values):
            rows = cell_values
        else:
            column_count = len(column_labels)
            if column_count == 0:
                column_count = view_result.get("columnCount") or 0
            if column_count == 0:
                raise WorkspaceException(
                    404,
                    "Не удалось определить колонки системного grid",
                )
            rows = [
                cell_values[index : index + column_count]
                for index in range(0, len(cell_values), column_count)
            ]

        if not column_labels and rows:
            column_labels = [f"Column {index}" for index in range(len(rows[0]))]

        # Подрезаем последнюю неполную строку, если WS вернул хвост пагинации.
        rows = [row for row in rows if len(row) == len(column_labels)]

        columns = list(column_labels)
        prepared_rows = [list(row) for row in rows]

        if row_labels and len(row_labels) == len(prepared_rows):
            columns.insert(0, row_label_column)
            for index, row in enumerate(prepared_rows):
                row.insert(0, row_labels[index])

        if row_entity_long_ids and len(row_entity_long_ids) == len(prepared_rows):
            columns.insert(0, row_id_column)
            for index, row in enumerate(prepared_rows):
                row.insert(0, row_entity_long_ids[index])

        return pd.DataFrame(prepared_rows, columns=Model._make_unique_columns(columns))

    @staticmethod
    def _make_unique_columns(columns: List) -> List[str]:
        """Делает имена колонок уникальными и строковыми."""
        result = []
        seen = {}
        for index, column in enumerate(columns):
            name = str(column) if column not in (None, "") else f"Column {index}"
            if name in seen:
                seen[name] += 1
                name = f"{name}_{seen[name]}"
            else:
                seen[name] = 0
            result.append(name)
        return result

    @staticmethod
    def _find_dataframe_column(df, candidates: List[str]) -> Optional[str]:
        """Ищет колонку по точному совпадению, затем по вхождению без учета регистра."""
        normalized = {str(column).strip().lower(): column for column in df.columns}
        for candidate in candidates:
            found = normalized.get(candidate.strip().lower())
            if found is not None:
                return found

        for candidate in candidates:
            needle = candidate.strip().lower()
            for column in df.columns:
                if needle and needle in str(column).strip().lower():
                    return column
        return None

    @staticmethod
    def _normalize_long_id(value) -> str:
        """Нормализует longId из int/float/str в строку без .0."""
        import math
        import re

        if value is None:
            return ""
        try:
            if isinstance(value, float) and math.isnan(value):
                return ""
        except TypeError:
            pass

        if isinstance(value, float) and value.is_integer():
            return str(int(value))
        text = str(value).strip()
        if text.endswith(".0") and text[:-2].isdigit():
            return text[:-2]
        match = re.search(r"\d{6,}", text)
        return match.group(0) if match else text

    @staticmethod
    def _cell_to_text(value) -> Optional[str]:
        """Приводит значение ячейки к тексту, сохраняя dict/list как JSON."""
        import json
        import math

        if value is None:
            return None
        try:
            if isinstance(value, float) and math.isnan(value):
                return None
        except TypeError:
            pass
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False)
        return str(value)

    async def get_id_multicube_by_name(self, name: str) -> int:
        """
        Возвращает id мультикуба по его имени, при наличии, иначе возникает ошибка.
        Аргументы:
            name (str): Имя мультикуба

        Возвращает:
            Int: id мультикуба.
        """
        message_request = GetIdMulticubeByNameMessage(model_id=self.model_id, name=name)
        response = await self._connector._post(
            url=self.json_rpc_url, model=message_request
        )
        data = (
            response.get("result")
            .get("etlActionResults")
            .get("rules")[0]
            .get("params")[0]
        )
        if data.get("error"):
            raise WorkspaceException(404, data.get("error"))
        return data.get("value")

    async def get_catalogs(
        self, start: int = 0, count: int = -1, filters: Optional[list] = None
    ) -> List[Catalog]:
        """
        Получает список справочников модели.

        Возвращает:
            List: Список справочников модели.
        """
        data = await self._connector.get_catalogs(
            url=self.json_rpc_url,
            model_id=self.model_id,
            start=start,
            count=count,
            filters=filters,
        )
        ids = data.get("hierarchiesLabelPage", {}).get("entityLongIds", [[]])[0]
        names = data.get("hierarchiesLabelPage", {}).get("entityIds", [[]])[0]
        infos = data.get("hierarchyInfos", [{}])
        return [
            Catalog(
                name=name,
                id=id,
                model_id=self.model_id,
                base_url=str(self.base_url_safe),
                _connector=self._connector,
                **info,
            )
            for name, id, info in zip(names, ids, infos)
        ]

    async def get_catalog(self, id: int) -> Catalog:
        """
        Получаем объект справочника по его id.

        Аргументы:
            id (str): id справочника

        Возвращает:
            Catalog: объект справочника
        """
        catalog = await self.get_catalogs(filters=[id])
        if catalog:
            return catalog[0]
        raise WorkspaceException(404, f"Каталог с id={id} не найден")

    async def get_catalog_by_name(self, name: str) -> Catalog:
        """
        Получаем объект справочника по его имени.

        Аргументы:
            name (str): Имя справочника

        Возвращает:
            Catalog: объект справочника
        """
        catalog = await self.get_catalogs(filters=[name])
        if catalog:
            return catalog[0]
        raise WorkspaceException(404, f"Каталог с name={name} не найден")

    async def create_catalogs(
        self,
        names: Optional[List[str]] = None,
        count: int = 1,
        position: Position = Position.END,
        relative_to: Optional[str] = None,
    ) -> None:
        """
        Создает новый справочник в модели.
        Аргументы:
            names (List[str]): Список с именами новых справочников. Если не указано, будет сгенерировано автоматически.
            count (int): Количество создаваемых справочников. По умолчанию 1. Указывается если не переданы names.
            position (Position): Позиция для вставки справочника. По умолчанию Position.END.
            relative_to (str): Имя справочника, относительно которого будет вставлен новый справочник.
        Возвращает:
            None
        """

        message_request = CreateCatalogMessage(
            model_id=self.model_id,
            names=names,
            count=count,
            position=position.value,
            relative_to=relative_to,
        )
        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def delete_catalogs(self, ids: List[int]) -> None:
        """
        Удаляет несколько справочников в модели.

        Аргументы:
            ids (List[int]): Список id справочников для удаления.

        Возвращает:
            None
        """

        # Проверим наличие справочников, если нет хотя бы одного - возникнет исключение (так же работает и API)
        async def async_gen(ids):
            for id in ids:
                yield id

        [await self.get_catalog(id) async for id in async_gen(ids)]

        message_request = DeleteCatalogMessage(model_id=self.model_id, ids=ids)
        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def rename_catalogs(self, names: List[str], ids: List[int]) -> None:
        """
        Переименовывает несколько справочников в модели.
        Аргументы:
            names (List[str]): Список новых имен справочников
            ids (List[int]): Список id справочников для переименования

        Возвращает:
            None
        """
        message_request = RenameCatalogMessage(
            model_id=self.model_id, names=names, ids=ids
        )
        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def action_info(self, action_id: int) -> dict:
        """
        Возвращает информацию о сохраненном в модели действии, например об оптимизационном запросе.

        Аргументы:
            action_id (int): Идентификатор действия.

        Возвращает:
            dict: Информация о действии.
        """
        message_request = ActionInfoMessage(model_id=self.model_id, action_id=action_id)
        response = await self._connector._post(
            url=self.json_rpc_url, model=message_request
        )
        return response.get("result", {}).get("systemActionResults", [{}])[0]

    async def export_lp_mapping(
        self,
        optimization_query_id: int,
        path: str,
    ):
        """
        Экспортирует оптимизационную модель в формат LP.
            Аргументы:
                optimization_query_id (int): Идентификатор оптимизационной модели.
                path (str): Путь для сохранения файла
        """

        # Создаем экземпляр сообщения-запроса
        message_request = ExportLpMappingMessage(
            model_id=self.model_id,
            optimization_query_id=optimization_query_id,
        )
        lp_hash = await self._connector.get_lp_hash(
            url=self.json_rpc_url, export_lp_message=message_request
        )
        # Получаем информацию об оптимизационном запросе для формирования имени файла
        action_info = await self.action_info(action_id=optimization_query_id)
        filename = f'{action_info.get("name")}.zip'
        file_path = os.path.join(path, filename)
        await self._connector.download_file_data(
            url=str(self.base_url_safe / "download" / lp_hash),
            file_path=file_path,
        )
        return filename

    async def import_solution_mapping(self, path_file: str) -> None:
        """
        Импортирует решение оптимизиционного запроса (LP) в модель.

        Аргументы:
            path_file (str): Путь к файлу решения оптимизиционного запроса (LP). Файл в формате zip,
            внутри два файла - файл с расширением .map для обратного mappinga и файл csv, в котором
            хранится решение оптимизиционного запроса.

        """
        # Создаем экземпляр сообщения-запроса
        message_request = ImportLpMappingMessage(
            model_id=self.model_id,
            model_definition_serial_number=self.model_definition_serial_number,
        )

        # Выполняем запрос
        response = await self._connector._post_file(
            url=self.json_rpc_url, model=message_request, file=path_file
        )
        # Получаем результат запроса
        result = response.get("result", {}).get("systemActionResults", [{}])[0]

        # Если результат успешный, возвращаем его, иначе вызываем ошибку
        if result.get("success"):
            return result
        raise WorkspaceException(404, "Ошибка импорта решения оптимизационного запроса")

    async def run_script(self, script_id: int) -> str:
        """
        Запускает сохраненный в модели скрипт.

        Аргументы:
            script_id (int): Идентификатор скрипта в модели.
        Возвращает:
            str: Результат-сообщение выполнения скрипта, выводимы системой.
        """

        # Создаем экземпляр сообщения-запроса
        message_request = RunScriptMessage(model_id=self.model_id, script_id=script_id)
        response = await self._connector._post(
            url=self.json_rpc_url, model=message_request
        )
        result = response.get("result", {}).get("systemActionResults", [{}])[0][
            "output"
        ]
        return result
    async def get_catalog_views(
        self, catalog_id: int, start: int = 0, count: int = -1
    ) -> List[CatalogView]:
        """
        Получает список представлений справочника.

        Аргументы:
            catalog_id (int): Идентификатор справочника
            start (int): Начальная позиция для вывода
            count (int): Количество выводимых представлений

        Возвращает:
            List[CatalogView]: Список представлений справочника
        """
        catalog = await self.get_catalog(catalog_id)
        return await catalog.get_views(start=start, count=count)

    async def get_catalog_view_by_name(
        self, catalog_id: int, view_name: str
    ) -> CatalogView:
        """
        Получает представление справочника по имени.

        Аргументы:
            catalog_id (int): Идентификатор справочника
            view_name (str): Имя представления

        Возвращает:
            CatalogView: Представление справочника
        """
        catalog = await self.get_catalog(catalog_id)
        return await catalog.get_view_by_name(view_name)

    async def recalculate(self) -> bool:
        """Пересчитать модель.

        Raises:
            ValueError: Ошибка в случае неправильных параметров.

        Returns:
            bool: True если успешно, иначе False.
        """
        message_request = ReCalcModelMessage(model_id=self.model_id)
        # TODO: в post добавить проверку что пришёл json и что не вернулась ошибка с modalInfo["isError"]
        response = await self._connector._post(
            url=self.json_rpc_url, model=message_request
        )
        if (result := response.get("result", {}).get("systemActionResults", [{}])[0]):
            return result["actionId"]== "RECALCULATE_MODEL"
        else:
            raise ValueError("Неправльные параметры для пересчёта.", result.get("modalInfo",{}).get("message", "Error"))
        
    async def stop(self) -> bool:
        """Остановить модель (offline).

        Raises:
            ValueError: В случае ошибки.

        Returns:
            bool: True если модель была онлайн а стала офлайн. False если была офлайн и осталась офлайн.
        """

        message_request = OfflineModeModelMessage(model_id=self.model_id)
        response = await self._connector._post(
            url=self.json_rpc_url, model=message_request
        )
        if (result := response.get("result", {}).get("systemActionResults", [{}])[0]) and result.get("actionId", None) == 'SET_MODEL_OFFLINE_MODE':
            self.is_offline = True
            return result.get("status", False)
        else:
            raise ValueError("Неправльные параметры для остановки.", result.get("modalInfo",{}).get("message", "Error"))      
    
    async def start(self) -> bool:
        """Включить модель (online).

        """
        message_request = OnlineModeModelMessage(model_id=self.model_id)
        response = await self._connector._post(
            url=self.json_rpc_url, model=message_request
        )
        if (result := response.get("result", {}).get("systemActionResults", [{}])[0]):
            self.is_offline = False
            return result["status"]
        else:
            raise ValueError("Неправльные параметры для запуска.", result.get("modalInfo",{}).get("message", "Error"))
        
    async def backup(self):
        """Сделать бэкап модели.
        """

        """
        **Для бэкапа**: 
        "systemActions": [{
                "actionId": "BACKUP_MODEL_TO_HISTORY",
                "params": {
                    "modelId": "e83cdbb7a0ccece896e5fc6a5ecf1397"
                }
            }]
            
        Бэкап в оффлайне не надо делать !
        """
        
    async def restore(self):
        """Восстановить из бэкапа.
        """

        """
        **Для бэкапа**: 
        Чтобы на последний бэкап ресторнуть, можно через админку: 

        /admin/api/v1/models/model/e83cdbb7a0ccece896e5fc6a5ecf1397

        Параметры: 
        action: restoreLastModelBackup

        Если есть id бэкапа, тогда можно через системный экшн:
        "systemActions": [{
                "actionId": "RESTORE_STORY_POINT",
                "params": {
                    "modelId": "e83cdbb7a0ccece896e5fc6a5ecf1397",
                    "historyLongId": {id бэкапа}
                }
            }]
        historyLongId будет в ответе при создании бэкапа

        Можно делать когда модель в онлайне или офлайне.
        """
