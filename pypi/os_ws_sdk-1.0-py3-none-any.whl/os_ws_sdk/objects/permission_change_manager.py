"""Changing permissions in Optimacros role matrices."""

from __future__ import annotations

import json
import math
import re
import uuid
from dataclasses import dataclass
from typing import Any, Dict, Optional, Union

from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.components.change_permission_message import (
    ChangePermissionMessage,
)
from os_ws_sdk.objects.permission_grid_exporter import (
    ACCESS_NONE,
    ACCESS_READ,
    ACCESS_WRITE,
    LIST_PERMISSIONS_GRID_LONG_ID,
    MACRO_PERMISSIONS_GRID_LONG_ID,
    MULTICUBE_PERMISSIONS_GRID_LONG_ID,
    VERSION_PERMISSIONS_GRID_LONG_ID,
    PermissionGridData,
    PermissionGridExporter,
    filter_permission_dataframe,
)


MODEL_ROLE_ACCESS_LEVEL_PROPERTY_LONG_ID = 4000001000
MODEL_ROLE_ACTION_ACCESS_PROPERTY_LONG_ID = 4000001001

ROLES_MODULES_KEY = "ROLES_MODULES"
ROLES_ACTIONS_KEY = "ROLES_ACTIONS"

_MODULE_TEXT = {
    ACCESS_NONE: "",
    ACCESS_READ: "Read",
    ACCESS_WRITE: "Write",
}


@dataclass(slots=True)
class PermissionChangeManager:
    """Reads the current cell and submits a permission change."""

    model_id: str
    json_rpc_url: str
    connector: Any
    model_definition_serial_number: Optional[int] = None

    @classmethod
    def from_model(cls, model: Any) -> "PermissionChangeManager":
        if model._connector is None:
            raise WorkspaceException(
                500,
                "Model не содержит connector. Получи модель через Workspace.",
            )

        return cls(
            model_id=model.model_id,
            json_rpc_url=model.json_rpc_url,
            connector=model._connector,
            model_definition_serial_number=(
                model.model_definition_serial_number
            ),
        )

    async def change_list_permission(
        self,
        list_id: Union[int, str],
        role_id: Union[int, str],
        permission: Any,
    ) -> bool:
        return await self._change_module_permission(
            grid_id=LIST_PERMISSIONS_GRID_LONG_ID,
            object_name="справочник",
            object_id=list_id,
            role_id=role_id,
            permission=permission,
        )

    async def change_multicube_permission(
        self,
        multicube_id: Union[int, str],
        role_id: Union[int, str],
        permission: Any,
    ) -> bool:
        return await self._change_module_permission(
            grid_id=MULTICUBE_PERMISSIONS_GRID_LONG_ID,
            object_name="мультикуб",
            object_id=multicube_id,
            role_id=role_id,
            permission=permission,
        )

    async def change_version_permission(
        self,
        version_id: Union[int, str],
        role_id: Union[int, str],
        permission: Any,
    ) -> bool:
        return await self._change_module_permission(
            grid_id=VERSION_PERMISSIONS_GRID_LONG_ID,
            object_name="версию",
            object_id=version_id,
            role_id=role_id,
            permission=permission,
        )

    async def change_macros_permission(
        self,
        macro_id: Union[int, str],
        role_id: Union[int, str],
        permission: Any,
    ) -> bool:
        """Changes the boolean action permission for a script/macro.

        ``MODEL_ROLE_ACTION_ACCESS_PROPERTY_LONG_ID`` is boolean. Therefore
        ``read``, ``write`` and ``true`` all mean enabled; ``none`` and
        ``false`` mean disabled. This follows the DP-91 submission contract
        where ``newText`` is ``true``/``false``.
        """
        normalized_object_id = self._normalize_long_id(
            macro_id,
            "ID макроса",
        )
        normalized_role_id = self._normalize_long_id(
            role_id,
            "ID роли",
        )
        enabled = self._normalize_action_permission(permission)

        grid_data = await self._export_permission_grid(
            MACRO_PERMISSIONS_GRID_LONG_ID
        )
        current_access = self._get_current_access(
            grid_data,
            object_id=normalized_object_id,
            role_id=normalized_role_id,
            object_name="макрос",
        )

        current_text = (
            "false" if current_access == ACCESS_NONE else "true"
        )
        new_text = "true" if enabled else "false"

        return await self._submit(
            grid_id=MACRO_PERMISSIONS_GRID_LONG_ID,
            property_id=MODEL_ROLE_ACTION_ACCESS_PROPERTY_LONG_ID,
            object_id=normalized_object_id,
            role_id=normalized_role_id,
            current_text=current_text,
            new_text=new_text,
            key=ROLES_ACTIONS_KEY,
            operation=(
                "изменение доступа к макросу "
                f"id={normalized_object_id} для роли "
                f"id={normalized_role_id}"
            ),
        )

    async def _change_module_permission(
        self,
        *,
        grid_id: int,
        object_name: str,
        object_id: Union[int, str],
        role_id: Union[int, str],
        permission: Any,
    ) -> bool:
        normalized_object_id = self._normalize_long_id(
            object_id,
            f"ID объекта ({object_name})",
        )
        normalized_role_id = self._normalize_long_id(
            role_id,
            "ID роли",
        )
        normalized_permission = self._normalize_module_permission(permission)

        grid_data = await self._export_permission_grid(grid_id)
        current_access = self._get_current_access(
            grid_data,
            object_id=normalized_object_id,
            role_id=normalized_role_id,
            object_name=object_name,
        )

        return await self._submit(
            grid_id=grid_id,
            property_id=MODEL_ROLE_ACCESS_LEVEL_PROPERTY_LONG_ID,
            object_id=normalized_object_id,
            role_id=normalized_role_id,
            current_text=_MODULE_TEXT[current_access],
            new_text=_MODULE_TEXT[normalized_permission],
            key=ROLES_MODULES_KEY,
            operation=(
                f"изменение доступа к объекту ({object_name}) "
                f"id={normalized_object_id} для роли "
                f"id={normalized_role_id}"
            ),
        )

    async def _export_permission_grid(
        self,
        grid_id: int,
    ) -> PermissionGridData:
        exporter = PermissionGridExporter(
            model_id=self.model_id,
            base_url=self.json_rpc_url.removesuffix("/jsonrpc"),
            connector=self.connector,
            model_definition_serial_number=(
                self.model_definition_serial_number
            ),
        )
        return await exporter.export(grid_id)

    @staticmethod
    def _get_current_access(
        grid_data: PermissionGridData,
        *,
        object_id: int,
        role_id: int,
        object_name: str,
    ) -> str:
        object_rows = filter_permission_dataframe(
            grid_data.dataframe,
            object_id,
        )
        if object_rows.empty:
            raise WorkspaceException(
                404,
                f"Объект ({object_name}) с id={object_id} "
                "не найден в матрице доступов",
            )

        role_column = next(
            (
                role.column
                for role in grid_data.role_columns
                if role.role_id == role_id
            ),
            None,
        )
        if role_column is None:
            raise WorkspaceException(
                404,
                f"Роль с id={role_id} не найдена в матрице доступов",
            )

        current_access = str(object_rows.iloc[0][role_column]).strip().casefold()
        if current_access not in {ACCESS_NONE, ACCESS_READ, ACCESS_WRITE}:
            raise WorkspaceException(
                500,
                "Матрица доступов вернула неизвестное текущее значение: "
                f"{current_access!r}",
            )
        return current_access

    async def _submit(
        self,
        *,
        grid_id: int,
        property_id: int,
        object_id: int,
        role_id: int,
        current_text: str,
        new_text: str,
        key: str,
        operation: str,
    ) -> bool:
        message = ChangePermissionMessage(
            model_id=self.model_id,
            model_definition_serial_number=(
                self.model_definition_serial_number
            ),
            grid_id=grid_id,
            permission_property_id=property_id,
            object_id=object_id,
            role_id=role_id,
            current_text=current_text,
            new_text=new_text,
            submission_key=key,
            message_id=f"messageId_{uuid.uuid4().hex}",
        )

        response = await self.connector._post(
            url=self.json_rpc_url,
            model=message,
        )
        self._raise_response_error(response, operation)
        return True

    @staticmethod
    def _normalize_module_permission(value: Any) -> str:
        if value is None:
            return ACCESS_NONE

        text = str(value).strip().casefold()
        mapping = {
            "none": ACCESS_NONE,
            "null": ACCESS_NONE,
            "": ACCESS_NONE,
            "read": ACCESS_READ,
            "write": ACCESS_WRITE,
        }
        if text in mapping:
            return mapping[text]

        raise WorkspaceException(
            400,
            "permission должен быть одним из: write, read, none",
        )

    @staticmethod
    def _normalize_action_permission(value: Any) -> bool:
        if isinstance(value, bool):
            return value
        if value is None:
            return False

        text = str(value).strip().casefold()
        if text in {"true", "1", "read", "write"}:
            return True
        if text in {"false", "0", "", "null", ""}:
            return False

        raise WorkspaceException(
            400,
            "permission для макроса должен быть одним из: "
            "true, false, write, read, none",
        )

    @staticmethod
    def _normalize_long_id(value: Any, name: str) -> int:
        if value is None or isinstance(value, bool):
            raise WorkspaceException(400, f"{name} не может быть пустым")

        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if math.isnan(value) or not value.is_integer():
                raise WorkspaceException(400, f"{name} должен быть целым")
            return int(value)

        text = str(value).strip()
        if not re.fullmatch(r"-?\d+(?:\.0+)?", text):
            raise WorkspaceException(400, f"{name} должен быть целым")
        return int(float(text))

    @classmethod
    def _raise_response_error(
        cls,
        response: Any,
        operation: str,
    ) -> None:
        if not isinstance(response, dict):
            raise WorkspaceException(
                500,
                f"Не удалось выполнить {operation}: backend вернул "
                f"ответ типа {type(response).__name__}",
            )

        top_error = response.get("error")
        if top_error:
            raise WorkspaceException(
                400,
                f"Не удалось выполнить {operation}: "
                f"{cls._value_to_text(top_error)}",
            )

        result = response.get("result")
        if not isinstance(result, dict):
            raise WorkspaceException(
                500,
                f"Не удалось выполнить {operation}: "
                "в ответе отсутствует result",
            )

        nested_error = cls._find_nested_error(result)
        if nested_error:
            raise WorkspaceException(
                400,
                f"Не удалось выполнить {operation}: {nested_error}",
            )

    @classmethod
    def _find_nested_error(cls, value: Any) -> Optional[str]:
        if isinstance(value, dict):
            modal_info = value.get("modalInfo")
            if isinstance(modal_info, dict) and modal_info.get("isError"):
                message = modal_info.get("message") or {}
                if isinstance(message, dict):
                    text = message.get("body") or message.get("title")
                    if text:
                        return str(text)
                return cls._value_to_text(modal_info)

            error = value.get("error")
            if error:
                return cls._value_to_text(error)

            messages = value.get("messages")
            if isinstance(messages, list):
                for message in messages:
                    if isinstance(message, dict) and (
                        message.get("isError")
                        or str(message.get("type", "")).casefold()
                        == "error"
                    ):
                        return cls._value_to_text(message)

            for nested_value in value.values():
                found = cls._find_nested_error(nested_value)
                if found:
                    return found

        elif isinstance(value, list):
            for item in value:
                found = cls._find_nested_error(item)
                if found:
                    return found

        return None

    @staticmethod
    def _value_to_text(value: Any) -> str:
        if isinstance(value, str):
            return value
        try:
            return json.dumps(value, ensure_ascii=False, default=str)
        except (TypeError, ValueError):
            return str(value)
