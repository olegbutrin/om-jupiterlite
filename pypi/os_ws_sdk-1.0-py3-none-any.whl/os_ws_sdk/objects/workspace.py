from dataclasses import dataclass
from typing import List

from dataclasses_json import dataclass_json

from os_ws_sdk.api.v1.connector_v1 import ConnectorV1
from os_ws_sdk.api.endpoints import JsonRPS
from os_ws_sdk.common.exceptions import ModelNotFoundError
from os_ws_sdk.objects.base_object import BaseObject
from os_ws_sdk.objects.model import Model
from os_ws_sdk.dto.ws_info import WsInfo


@dataclass_json
@dataclass
class Workspace(BaseObject):
    """
    Класс Workspace - рабочее пространство.

    Атрибуты:
        _connector (Connector): Объект класса Connector для выполнения HTTP-запросов.
    """

    def __init__(self, base_url: str, connector: ConnectorV1) -> None:
        """
        Инициализирует объект класса Workspace.

        Аргументы:
            base_url (str): Базовый URL для выполнения HTTP-запросов.
            connector (Connector): Объект класса Connector для выполнения HTTP-запросов.
        """
        self._connector = connector
        self.base_url = base_url

    @property
    def _json_rpc_url(self) -> str:
        """
        Свойство, возвращающее URL для выполнения HTTP-запросов через /jsonrpc.

        Возвращает:
            str: URL для выполнения HTTP-запросов.
        """
        return str(self.base_url_safe / JsonRPS.JSONRPC.value.lstrip("/"))

    async def info(self) -> WsInfo:
        """
        Возвращает:
            : Информация о рабочем пространстве.
        """
        workspace_info_dict = await self._connector.get_ws_info(url=self._json_rpc_url)
        return WsInfo.from_dict(workspace_info_dict)

    async def get_models(self) -> List[Model]:
        """
        Получает список моделей рабочего пространства.

        Возвращает:
            List[Model]: Список моделей рабочего пространства.
        """
        models_dict = await self._connector.get_models(url=self._json_rpc_url)
        models = []
        for model in models_dict:
            model.update(
                base_url=str(self.base_url_safe), _connector=self._connector
            )
            models.append(Model.from_dict(model))
        return models

    async def get_model(self, id: str) -> Model:
        """
        Получает информацию о модели.

        Аргументы:
            model_id (str): Идентификатор модели.

        Возвращает:
            Model: Информация о модели.

        Исключения:
            ModelNotFoundError: Если модель не найдена.
        """
        models = [model for model in await self.get_models() if model.model_id == id]
        if len(models) == 1:
            return models[0]
        else:
            raise ModelNotFoundError(id)


    async def get_model_by_name(self, name: str) -> Model:
        """
        Получает информацию о модели.

        Аргументы:
            model_id (str): Идентификатор модели.

        Возвращает:
            Model: Информация о модели.
        """
        # models = [model for model in await self.get_models() if model.model_name == name]
        # if len(models) == 1:
        #     return models[0]
        # else:
        #     raise ModelNotFoundError(id)

        models = await self.get_models()
        return next((model for model in models if model.model_name == name), None)
