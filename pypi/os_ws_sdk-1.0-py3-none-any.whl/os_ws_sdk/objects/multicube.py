import asyncio
import io
import os
import re
from dataclasses import dataclass, field
from typing import Optional, Literal, List, Union, Any

import pandas as pd
from dataclasses_json import dataclass_json, LetterCase, Exclude, config

from os_ws_sdk.api.endpoints import JsonRPS
from os_ws_sdk.api.v1.connector_v1 import ConnectorV1
from os_ws_sdk.components.change_cell_message import ChangeCellValueMessage
from os_ws_sdk.components.clear_multicube_message import ClearMulticubeMessage
from os_ws_sdk.components.download_format import (
    DownloadFormat,
    DownloadFormatOM,
)
from os_ws_sdk.components.encoding_type import EncodingTypeExport
from os_ws_sdk.components.export_view_message import (
    ExportViewMessage,
    ExportViewOmMessage,
)
from os_ws_sdk.components.import_view_message import (
    ImportViewMessage,
    ImportViewOmMessage,
)
from os_ws_sdk.components.multicube_to_multicube_message import (
    MulticubeToMulticubeMessage,
)
from os_ws_sdk.dto.multicube_info import MulticubeInfo
from os_ws_sdk.objects.base_object import BaseObject
from os_ws_sdk.objects.view import View


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class Multicube(BaseObject):
    name: str
    id: int
    model_id: str
    _connector: Optional[ConnectorV1] = field(
        metadata=config(exclude=Exclude.ALWAYS), default=None
    )

    async def _create_export_view_message(
        self,
        **kwargs,
    ) -> ExportViewMessage:
        """Создает экземпляр класса ExportViewMessage с параметрами экспорта представления мультикуба

        Аргументы:
            **kwargs: Параметры для экспорта представления.

        Возвращает:
            ExportViewMessage: Экземпляр класса ExportViewMessage с параметрами экспорта представления мультикуба.
        """

        # Получаем данные для viewDefinition
        view_data = await self._connector.get_view_definition(
            url=self.json_rpc_url,
            model_id=self.model_id,
            view_id=self.id,
            filter_boolean_cube=kwargs.get("filter_boolean_cube"),
            filter_formula=kwargs.get("filter_formula"),
            filter_subset=kwargs.get("filter_subset"),
            filter_rows=kwargs.get("filter_rows"),
            filter_cols=kwargs.get("filter_cols"),
        )
        kwargs.update(model_id=self.model_id, view_data=view_data, file_name=self.name)
        message_request = ExportViewMessage(**kwargs)
        return message_request

    async def _create_export_view_om_message(
        self,
        **kwargs,
    ) -> ExportViewOmMessage:
        """
        Аргументы:
            **kwargs: Параметры для экспорта представления.

        Возвращает:
            ExportViewOmMessage: Экземпляр класса ExportViewOmMessage с параметрами экспорта представления мультикуба.
        """

        view_data = await self._connector.get_view_definition(
            url=self.json_rpc_url,
            model_id=self.model_id,
            view_id=self.id,
            om_format=True,
        )
        kwargs.update(model_id=self.model_id, view_data=view_data, file_name=self.name)
        message_request = ExportViewOmMessage(**kwargs)
        return message_request

    async def _create_import_view_message(self) -> ImportViewMessage:
        """Создает и возвращает экземпляр класса сообщения запроса ImportViewMessage для импорта представления."""

        message_request = ImportViewMessage(
            model_id=self.model_id, module_long_id=self.id, key=self.id
        )
        return message_request

    async def _create_import_view_om_message(self) -> ImportViewOmMessage:
        """Создает и возвращает экземпляр класса сообщения запроса ImportViewOmMessage для импорта представления."""

        message_request = ImportViewOmMessage(
            model_id=self.model_id, namespace_identifier=self.id
        )
        return message_request

    @property
    def json_rpc_url(self) -> str:
        """
        Свойство, возвращающее URL для выполнения HTTP-запросов через /jsonrpc.

        Возвращает:
            str: URL для выполнения HTTP-запросов.
        """
        return str(self.base_url_safe / JsonRPS.JSONRPC.value.lstrip("/"))

    async def info(self):
        return MulticubeInfo(
            name=self.name,
            id=self.id,
            model_id=self.model_id,
        )

    async def export_file(
        self,
        path: str,
        format: DownloadFormat = DownloadFormat.CSV,
        escape: Literal[None, "\\", '"'] = "\\",
        decimal_separator: str = ".",
        delimiter: str = ";",
        enclosure: str = '"',
        encoding: EncodingTypeExport = EncodingTypeExport.UTF_8,
        filter_boolean_cube: Optional[List[int]] = None,
        filter_formula: Optional[List[Union[str, int]]] = None,
        filter_subset: Optional[List[int]] = None,
        filter_rows: Optional[
            List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
        ] = None,
        filter_cols: Optional[
            List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
        ] = None,
    ):
        """
        Экспортирует представление мультикуба в доступных форматах - CSV задан по умолчанию.

        Аргументы:
            path (str): Путь к файлу
            format (DownloadFormat): Формат файла для экспорта, доступные варианты: CSV, TXT, XLS, XLSX
            escape (str): Экранирующий символ. Значение по умолчанию - "\\"
            decimal_separator (str): Разделитель десятичной точки. Значение по умолчанию - "."
            delimiter (str): Разделитель значений. Значение по умолчанию - ";"
            enclosure (str): Значение, которое будет использовано для экранирования строковых значений. Значение по умолчанию - "'"
            encoding (EncodingType): Кодировка для записи файла. Значение по умолчанию - "utf-8", доступные варианты:"windows-1251","WINDOWS-1251","win","WIN","utf","UTF","utf-8" ,"UTF-8"
            boolean_cube_filter (List[int]): список с идентификаторами булева куба и измерения для фильтрации данных. Значение по умолчанию - None
            filter_formula (List[Union[str, int]]): список со строкой-формулой и идентификатором измерения для фильтрации данных. Значение по умолчанию - None
            filter_subset (List[int]): список с идентификаторами измерений (измерение и сам сабсет) для фильтрации данных. Значение по умолчанию - None
            filter_rows (List[Literal["HIDE", "SHOW_ONLY"], List[int]]): список с типом отображения строк и их идентификаторами для фильтрации данных. Значение по умолчанию - None
            filter_cols (List[Literal["HIDE", "SHOW_ONLY"], List[int]]): список с типом отображения столбцов и их идентификаторами для фильтрации данных. Значение по умолчанию - None

        Возвращает:
            None
        """

        # Формируем объект-сообщения с параметрами для экспорта представления
        message_request = await self._create_export_view_message(
            format=format,
            escape=escape,
            decimal_separator=decimal_separator,
            delimiter=delimiter,
            enclosure=enclosure,
            encoding=encoding,
            filter_boolean_cube=filter_boolean_cube,
            filter_formula=filter_formula,
            filter_subset=filter_subset,
            filter_rows=filter_rows,
            filter_cols=filter_cols,
        )

        # Осуществляем запрос на скачивание данных для экспорта и получаем идентификатор для скачивания данных
        view_hash = await self._connector.get_view_hash(
            url=self.json_rpc_url, export_view_message=message_request
        )
        file_name = re.sub(r'[<>:"/\\|?*{}#]', "_", self.name)
        file_path = os.path.join(path, f"{file_name}.{format.value}")
        await self._connector.download_file_data(
            url=str(self.base_url_safe / "download" / view_hash),
            file_path=file_path,
        )

    async def export_om_file(
        self,
        path: str,
        format: DownloadFormatOM = DownloadFormatOM.OM_CSV,
        escape: Literal[None, "\\", '"'] = "\\",
        decimal_separator: str = ".",
        delimiter: str = ";",
        enclosure: str = '"',
        encoding: EncodingTypeExport = EncodingTypeExport.UTF_8,
        boolean_cube_filter_long_id: Optional[int] = None,
        filter_formula: Optional[str] = None,
    ):
        """
        "Экспорт мультикуба в форматах OM_* (данные непосредственно из БД) - CSV задан по умолчанию.

        Аргументы:
            path (str): Путь к файлу.
            format (DownloadFormatOM): Формат файла для экспорта, доступны OM_CSV, OM_TXT, OM_ZIP
            escape (str): Экранирующий символ. Значение по умолчанию - "\\"
            decimal_separator (str): Разделитель десятичной точки. Значение по умолчанию - "."
            delimiter (str): Разделитель значений. Значение по умолчанию - ";"
            enclosure (str): Значение, которое будет использовано для экранирования строковых значений. Значение по умолчанию - "'"
            encoding (EncodingType): Кодировка для записи файла. Значение по умолчанию - "utf-8", доступные варианты:"windows-1251","WINDOWS-1251","win","WIN","utf","UTF","utf-8" ,"UTF-8"
            boolean_cube_filter_long_id (int): Идентификатор болеан куба для фильтрации.
            filter_formula (str): Формула в формате ОМ для фильтрации.

        Возвращает:
            None
        """

        # Формируем основу объекта-сообщения с параметрами для экспорта представления
        message_request = await self._create_export_view_om_message(
            format=format,
            escape=escape,
            decimal_separator=decimal_separator,
            delimiter=delimiter,
            enclosure=enclosure,
            encoding=encoding,
            boolean_cube_filter_long_id=boolean_cube_filter_long_id,
            filter_formula=filter_formula,
        )
        # Осуществляем запрос на скачивание данных для экспорта
        view_hash = await self._connector.get_view_hash(
            url=self.json_rpc_url, export_view_message=message_request
        )
        
        file_name = re.sub(r'[<>:"/\\|?*{}#]', "_", self.name)
        file_path = os.path.join(path, f"{file_name}.{format.value}")
        await self._connector.download_file_data(
            url=str(self.base_url_safe / "download" / view_hash),
            file_path=file_path,
        )

    async def get_views(self, start=0, count=-1) -> List[View]:
        """Метод для получения списка сохраненных представлений мультикуба."""
        data = await self._connector.get_views(
            url=self.json_rpc_url, model_id=self.model_id, start=start, count=count
        )

        views = [
            View(
                name=name,
                id=id,
                model_id=self.model_id,
                multicube_id=self.id,
                base_url=str(self.base_url_safe),
                _connector=self._connector,
            )
            for name, id, parent_id in zip(
                data.get("viewsLabelPage", {}).get("entityIds", [[]])[0],
                data.get("viewsLabelPage", {}).get("entityLongIds", [[]])[0],
                data.get("viewsInfos", []),
            )
            if self.id == parent_id.get("contextEntityLongId", None)
        ]

        return views

    async def get_view_by_name(self, view_name: str) -> View:
        """Метод для получения представления мультикуба по его имени."""
        views = await self.get_views()
        return next((view for view in views if view.name == view_name), None)

    async def export_views(self, path: str) -> None:
        """
        Экспортирует все представления мультикуба с параметрами по умолчанию.

        Аргументы:
            path (str): Путь к файлу
        Возвращает:
            None
        """
        views = await self.get_views()
        # Создаем список корутин для экспорта каждого представления
        coroutines = [view.export_file(path) for view in views]
        # Запускаем все корутины одновременно
        await asyncio.gather(*coroutines)

    async def import_file(self, path: str) -> None:
        """
        Импортирует представление мультикуба в модель.

        Аргументы:
            path (str): Путь к файлу с данными.
        Возвращает:
            None
        """
        message_request = await self._create_import_view_message()
        # Проверяем наличие файла по указанному пути
        if not os.path.exists(path):
            raise FileNotFoundError(f"Файл {path} не найден")

        # Осуществляем запрос
        await self._connector._post_file(
            url=self.json_rpc_url, model=message_request, file=rf"{path}"
        )

    async def import_om_file(self, path: str) -> None:
        """
        Импортирует представление мультикуба в модель в форматах ОМ.

        Аргументы:
            path (str): Путь к файлу с данными.
        Возвращает:
            None
        """

        message_request = await self._create_import_view_om_message()

        if not os.path.exists(path):
            raise FileNotFoundError(f"Файл {path} не найден")

        # Осуществляем запрос
        await self._connector._post_file(
            url=self.json_rpc_url, model=message_request, file=rf"{path}"
        )

    async def export_df(
        self,
        filter_boolean_cube: Optional[List[int]] = None,
        filter_formula: Optional[List[Union[str, int]]] = None,
        filter_subset: Optional[List[int]] = None,
        filter_rows: Optional[
            List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
        ] = None,
        filter_cols: Optional[
            List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
        ] = None,
        **kwargs,
    ):
        """Получаем данные мультикуба в виде DataFrame Pandas.

        Аргументы:
            boolean_cube_filter (List[int]): список с идентификаторами булева куба и измерения для фильтрации данных. Значение по умолчанию - None
            filter_formula (List[Union[str, int]]): список со строкой-формулой и идентификатором измерения для фильтрации данных. Значение по умолчанию - None
            filter_subset (List[int]): список с идентификаторами измерений (измерение и сам сабсет) для фильтрации данных. Значение по умолчанию - None
            filter_rows (List[Literal["HIDE", "SHOW_ONLY"], List[int]]): список с типом отображения строк и их идентификаторами для фильтрации данных. Значение по умолчанию - None
            filter_cols (List[Literal["HIDE", "SHOW_ONLY"], List[int]]): список с типом отображения столбцов и их идентификаторами для фильтрации данных. Значение по умолчанию - None
            kwargs: Параметры для функции pd.read_csv
        Возвращает:
            DataFrame: Экземпляр класса DataFrame Pandas.
        """

        # Формируем объект-сообщения с параметрами для экспорта представления
        message_request = await self._create_export_view_message(
            filter_boolean_cube=filter_boolean_cube,
            filter_formula=filter_formula,
            filter_subset=filter_subset,
            filter_rows=filter_rows,
            filter_cols=filter_cols,
        )
        # Осуществляем запрос на скачивание данных для экспорта и получаем идентификатор для скачивания данных
        view_hash = await self._connector.get_view_hash(
            url=self.json_rpc_url, export_view_message=message_request
        )
        data = await self._connector.download_dataframe(
            url=str(self.base_url_safe / "download" / view_hash)
        )

        df = pd.read_csv(io.BytesIO(data), skiprows=2, **kwargs)
        return df

    async def clear(self) -> None:
        """Метод для очистки мультикуба."""

        message_request = ClearMulticubeMessage(
            model_id=self.model_id, multicube_id=self.id
        )
        await self._connector._post(self.json_rpc_url, message_request)

    async def change_cell_value(
        self, value: Any, cube_id: int, dimension_id: int
    ) -> None:
        """
        Метод для изменения значения ячейки в мультикубе.

        Аргументы:
            value (Any): Новое значение ячейки.
            cube_id (int): Идентификатор куба.
            dimension_id (int): Идентификатор измерения.

        Возвращает:
            None
        """

        message_request = ChangeCellValueMessage(
            model_id=self.model_id,
            value=value,
            multicube_id=self.id,
            cube_id=cube_id,
            dimension_id=dimension_id,
        )

        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def export_to_multicube(self, destination_mc_id: int) -> None:
        """
        Экспортирует данные из текущего мультикуба в другой мультикуб.

        Аргументы:
            destination_mc_id (int): Идентификатор мультикуба, в который нужно экспортировать данные.

        Возвращает:
            None
        """

        message_request = MulticubeToMulticubeMessage(
            model_id=self.model_id,
            multicube_id=self.id,
            destination_mc_id=destination_mc_id,
        )
        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def import_from_multicube(self, source_mc_id: int) -> None:
        """
        Импортирует данные в текущий мультикуб из другого мультикуба.

        Аргументы:
            source_mc_id (int): Идентификатор мультикуба, из которого нужно импортировать данные.

        Возвращает:
            None
        """

        message_request = MulticubeToMulticubeMessage(
            model_id=self.model_id,
            multicube_id=source_mc_id,
            destination_mc_id=self.id,
        )
        await self._connector._post(url=self.json_rpc_url, model=message_request)
