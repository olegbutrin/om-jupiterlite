import json
from dataclasses import dataclass, field
from typing import Optional

from dataclasses_json import dataclass_json, LetterCase, Exclude, config
from yarl import URL


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass(kw_only=True)
class BaseObject:
    base_url: Optional[str] = field(
        metadata=config(exclude=Exclude.ALWAYS), default=None, repr=False
    )

    def __str__(self):
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @property
    def base_url_safe(self) -> URL:
        """Безопасный URL"""
        return URL(self.base_url or "")
