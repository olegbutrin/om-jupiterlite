"""
Универсальная выгрузка системных grid-view Optimacros/WS в pandas.DataFrame.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Dict, Iterable, Optional, Union

import pandas as pd

from os_ws_sdk.api.endpoints import JsonRPS
from os_ws_sdk.api.v1.connector_v1 import ConnectorV1
from os_ws_sdk.objects.model import Model


LOG_GRID_LONG_ID = 137000000030
USERS_FROM_MODEL_GRID_LONG_ID = 137000000027
USERS_FROM_WORKSPACE_GRID_LONG_ID = 137000000028

ACTION_SCRIPTS_GRID_LONG_ID = 137000000049
ACTION_SCRIPTS_CONTEXT_LONG_ID = 31000000010
SCRIPTS_HISTORY_GRID_LONG_ID = 137000000065
SCRIPTS_CHAIN_HISTORY_GRID_LONG_ID = 137000000066


class GridTypeIdentifiers(IntEnum):
    """Системные grid-view ID, которые можно выгружать без доп. контекста."""

    MULTICUBES_GRID = 137000000002
    FOLDERS_GRID = 137000000003
    CUBES_GRID = 137000000004
    VERSIONS_GRID = 137000000013
    VERSIONS_SUBSETS_GRID = 137000000014
    DASHBOARDS_GRID = 137000000022
    CONTEXT_TABLES_GRID = 137000000024
    MODEL_USERS_GRID = USERS_FROM_MODEL_GRID_LONG_ID
    WORKSPACE_USERS_GRID = USERS_FROM_WORKSPACE_GRID_LONG_ID
    BACKUPS_GRID = LOG_GRID_LONG_ID
    LIST_PROPERTIES_GRID = 137000000032
    TIME_DAYS_SUBSETS_GRID = 137000000040
    TIME_WEEKS_SUBSETS_GRID = 137000000041
    TIME_MONTHS_SUBSETS_GRID = 137000000042
    TIME_PERIODS_SUBSETS_GRID = 137000000043
    TIME_YEARS_SUBSETS_GRID = 137000000044
    DASHBOARD_MULTICUBES_GRID = 137000000080


DEFAULT_GRID_TYPES: tuple[GridTypeIdentifiers, ...] = tuple(GridTypeIdentifiers)
GridType = Union[int, GridTypeIdentifiers]


@dataclass(slots=True)
class SystemGrid:
    """Один системный grid-view, который можно получить в DataFrame."""

    name: str
    id: int
    model_id: str
    base_url: str
    connector: ConnectorV1
    model_definition_serial_number: Optional[int] = None

    @property
    def json_rpc_url(self) -> str:
        return f"{self.base_url.rstrip('/')}{JsonRPS.JSONRPC.value}"

    async def export_df(
        self,
        *,
        context_entity_long_id: Optional[int] = None,
        filter_type: Optional[str] = None,
        filter_params: Optional[dict] = None,
        start_row: int = 0,
        start_column: int = 0,
        row_count: int = 1_000,
        column_count: int = 40,
        **_,
    ) -> pd.DataFrame:
        """Читает системный grid постранично."""

        if row_count <= 0:
            raise ValueError("row_count должен быть больше 0")

        if column_count <= 0:
            raise ValueError("column_count должен быть больше 0")

        if row_count + column_count > 100_000:
            raise ValueError(
                "Сумма row_count и column_count не должна превышать 100000"
            )

        if row_count * column_count > 40_000:
            raise ValueError(
                "Количество запрашиваемых ячеек не должно превышать 40000"
            )

        frames = []
        empty_frame: Optional[pd.DataFrame] = None
        current_start_row = start_row

        while True:
            view_result = await self.connector.get_system_grid_data(
                url=self.json_rpc_url,
                model_id=self.model_id,
                grid_id=self.id,
                model_definition_serial_number=(
                    self.model_definition_serial_number
                ),
                context_entity_long_id=context_entity_long_id,
                filter_type=filter_type,
                filter_params=filter_params,
                start_row=current_start_row,
                start_column=start_column,
                row_count=row_count,
                column_count=column_count,
            )

            frame = Model._view_request_result_to_dataframe(view_result)

            if frame.empty:
                if not frames:
                    empty_frame = frame
                break

            frames.append(frame)

            received_row_count = len(frame)
            if received_row_count < row_count:
                break

            current_start_row += received_row_count

            total_row_count = view_result.get("rowCount")
            if isinstance(total_row_count, int):
                if current_start_row >= total_row_count:
                    break

        if not frames:
            return empty_frame if empty_frame is not None else pd.DataFrame()

        return pd.concat(frames, ignore_index=True)


@dataclass(slots=True)
class SystemGridExporter:
    """Фасад: принимает grid ID / enum и возвращает DataFrame."""

    model_id: str
    base_url: str
    connector: ConnectorV1
    model_definition_serial_number: Optional[int] = None

    @classmethod
    def from_model(cls, model: Model) -> "SystemGridExporter":
        if model.base_url is None or model._connector is None:
            raise ValueError(
                "Model должен быть получен через Workspace.get_model(...)"
            )

        return cls(
            model_id=model.model_id,
            base_url=model.base_url,
            connector=model._connector,
            model_definition_serial_number=(
                model.model_definition_serial_number
            ),
        )

    @staticmethod
    def _grid_name_and_id(grid_type: GridType) -> tuple[str, int]:
        grid_id = int(grid_type)
        try:
            enum_value = GridTypeIdentifiers(grid_id)
            return enum_value.name, grid_id
        except ValueError:
            return f"GRID_{grid_id}", grid_id

    def grid(self, grid_type: GridType) -> SystemGrid:
        name, grid_id = self._grid_name_and_id(grid_type)

        return SystemGrid(
            name=name,
            id=grid_id,
            model_id=self.model_id,
            base_url=self.base_url,
            connector=self.connector,
            model_definition_serial_number=(
                self.model_definition_serial_number
            ),
        )

    async def export_df(self, grid_type: GridType, **kwargs) -> pd.DataFrame:
        """Выгрузить один grid по enum или числовому ID."""
        return await self.grid(grid_type).export_df(**kwargs)

    async def export_many(
        self,
        grid_types: Iterable[GridType] = DEFAULT_GRID_TYPES,
        **kwargs,
    ) -> Dict[str, pd.DataFrame]:
        """Выгрузить несколько grid-view в словарь DataFrame."""
        result: Dict[str, pd.DataFrame] = {}
        for grid_type in grid_types:
            grid = self.grid(grid_type)
            result[grid.name] = await grid.export_df(**kwargs)
        return result

    async def export_many_as_one_df(
        self,
        grid_types: Iterable[GridType] = DEFAULT_GRID_TYPES,
        **kwargs,
    ) -> pd.DataFrame:
        """Выгрузить grid-view и объединить их в один DataFrame."""
        frames = []
        for grid_type in grid_types:
            grid = self.grid(grid_type)
            df = await grid.export_df(**kwargs)
            df.insert(0, "_grid_id", grid.id)
            df.insert(0, "_grid_name", grid.name)
            frames.append(df)

        return (
            pd.concat(frames, ignore_index=True, sort=False)
            if frames
            else pd.DataFrame()
        )
