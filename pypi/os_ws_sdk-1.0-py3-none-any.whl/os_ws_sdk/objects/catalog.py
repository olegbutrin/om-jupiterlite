"""Модуль с классом для Справочника и работы с ним."""

import asyncio
import io
import os
import re
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Literal, Union

import pandas as pd
from dataclasses_json import (
    dataclass_json,
    LetterCase,
    Exclude,
    config,
    Undefined,
    CatchAll,
)

from os_ws_sdk.api.endpoints import JsonRPS
from os_ws_sdk.api.v1.connector_v1 import ConnectorV1
from os_ws_sdk.components.crud_catalog_message import (
    DeleteCatalogMessage,
    CreateCatalogMessage,
    AddElementsMessage,
    RenameCatalogMessage,
    DeleteElementsMessage,
    ClearCatalogMessage,
    GetDataCatalogMessage,
    ImportCatalogMessage,
    ImportFileMessage,
)
from os_ws_sdk.components.download_format import DownloadFormat, DownloadFormatOM
from os_ws_sdk.components.encoding_type import EncodingTypeImport, EncodingTypeExport
from os_ws_sdk.components.export_view_message import (
    ExportViewMessage,
    ExportViewOmMessage,
)
from os_ws_sdk.components.import_view_message import ImportViewMessage
from os_ws_sdk.components.position import Position
from os_ws_sdk.dto.catalog_info import CatalogInfo
from os_ws_sdk.objects.base_object import BaseObject
from os_ws_sdk.objects.catalog_view import CatalogView
from os_ws_sdk.objects.multicube import Multicube


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class Catalog(BaseObject):
    name: str
    id: int
    model_id: str
    unknown_things: CatchAll
    _connector: Optional[ConnectorV1] = field(
        metadata=config(exclude=Exclude.ALWAYS), default=None, repr=False
    )

    @property
    def json_rpc_url(self) -> str:
        """
        Свойство, возвращающее URL для выполнения HTTP-запросов через /jsonrpc.

        Возвращает:
            str: URL для выполнения HTTP-запросов.
        """
        return str(self.base_url_safe / JsonRPS.JSONRPC.value.lstrip("/"))

    async def info(self) -> CatalogInfo:
        """Получает информацию о справочнике."""
        return CatalogInfo(
            name=self.name,
            id=self.id,
            model_id=self.model_id,
        )

    async def _get_type_index(self):
        """Метод для получения индекса справочника, нужен для добавления (удаления) элементов в справочник."""
        data = await self._connector.get_entity_types(
            url=self.json_rpc_url, model_id=self.model_id
        )
        self_index = data.get("hierarchyEntityLongIds").index(self.id)
        type_index = data.get("entityTypeIndices")[self_index]
        return type_index

    async def _create_export_view_message(
        self,
        **kwargs,
    ) -> ExportViewMessage:
        """Создает и возвращает экземпляр класса ExportViewMessage с параметрами экспорта представления справочника."""

        # Получаем данные для viewDefinition
        view_data = await self._connector.get_view_definition(
            url=self.json_rpc_url,
            model_id=self.model_id,
            view_id=self.id,
            filter_boolean_cube=kwargs.get("filter_boolean_cube"),
            filter_formula=kwargs.get("filter_formula"),
            filter_subset=kwargs.get("filter_subset"),
            filter_rows=kwargs.get("filter_rows"),
            filter_cols=kwargs.get("filter_cols"),
        )
        kwargs.update(model_id=self.model_id, view_data=view_data, file_name=self.name)
        message_request = ExportViewMessage(**kwargs)
        return message_request

    async def _create_export_view_om_message(
        self,
        **kwargs,
    ) -> ExportViewOmMessage:
        """
        Создает и возвращает экземпляр класса ExportViewOmMessage
        с параметрами экспорта представления справочника в OM форматах.
        """

        view_data = await self._connector.get_view_definition(
            url=self.json_rpc_url,
            model_id=self.model_id,
            view_id=self.id,
            om_format=True,
        )
        kwargs.update(model_id=self.model_id, view_data=view_data, file_name=self.name)
        message_request = ExportViewOmMessage(**kwargs)
        return message_request

    async def _create_import_view_message(self) -> ImportViewMessage:
        """Создает и возвращает экземпляр класса сообщения запроса ImportViewMessage для импорта представления справочника."""

        message_request = ImportViewMessage(
            model_id=self.model_id, module_long_id=self.id, key=self.id
        )
        return message_request

    async def create(
        self,
        model_id: str,
        names: Optional[List[str]] = None,
        count: int = 1,
        position: Position = Position.END,
        relative_to: Optional[str] = None,
    ) -> None:
        """
        Создает справочники в модели.

        Аргументы:
            model_id (str): Идентификатор модели справочника
            names (List[str]): Список с именами новых справочников. Если не указано, будет сгенерировано автоматически
            count (int): Количество создаваемых справочников. По умолчанию 1. Указывается если не переданы names
            position (Position): Позиция для вставки справочника. По умолчанию "End"
            relative_to (str): Имя справочника, относительно которого будет вставлен новый справочник

        Возвращает:
            None
        """

        message_request = CreateCatalogMessage(
            model_id=model_id,
            names=names,
            count=count,
            position=position.value,
            relative_to=relative_to,
        )

        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def delete(self) -> None:
        """
        Удаляет справочник.

        Возвращает:
            None
        """
        message_request = DeleteCatalogMessage(model_id=self.model_id, ids=[self.id])
        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def add_elements(
        self,
        names: Optional[List[str]] = None,
        count: int = 1,
        position: Position = Position.END,
        relative_to: Optional[str] = None,
    ) -> None:
        """
        Добавляет элементы в справочник.

        Аргументы:
            names (List[str]): Список с именами новых элементов. Если не указано, будет сгенерировано автоматически
            count (int): Количество создаваемых элементов. По умолчанию 1. Указывается если не переданы names
            position (Position): Позиция для вставки элемента. По умолчанию "End"
            relative_to (str): Имя элемента, относительно которого будет вставлен новый

        Возвращает:
            None
        """

        type_index = await self._get_type_index()
        message_request = AddElementsMessage(
            model_id=self.model_id,
            catalog_id=self.id,
            names=names,
            count=count,
            position=position.value,
            relative_to=relative_to,
            type_index=type_index,
        )

        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def delete_elements(
        self, ids: Optional[List[int]] = None, names: Optional[List[str]] = None
    ) -> None:
        """
        Удаляет элементы из справочника. Можно передать список с идентификаторами элементов или список с именами элементов.

        Аргументы:
            ids (List[int]): Список с идентификаторами элементов для удаления
            names (List[str]): Список с именами элементов для удаления.

        Возвращает:
            None
        """

        type_index = await self._get_type_index()
        message_request = DeleteElementsMessage(
            model_id=self.model_id,
            type_index=type_index,
            catalog_id=self.id,
            ids=ids,
            names=names,
        )

        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def rename(self, names: List[str]) -> None:
        """
        Переименовывает справочник.

        Аргументы:
            names (List[str]): Список с новым именем справочника.

        Возвращает:
            None
        """

        message_request = RenameCatalogMessage(
            model_id=self.model_id, catalog_id=self.id, names=names
        )

        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def rename_elements(self, names: List[str], elements_ids: List[int]) -> None:
        """
        Переименовывает элементы справочника.

        Аргументы:
            names (List[str]): Список с новыми именами элементов справочника
            elements_ids (List[int]): Список с идентификаторами элементов справочника, которые нужно переименовать

        Возвращает:
            None
        """

        message_request = RenameCatalogMessage(
            model_id=self.model_id,
            catalog_id=self.id,
            names=names,
            ids=elements_ids,
        )
        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def clear(self) -> None:
        """
        Удаляет все элементы справочника.
        Возвращает:
            None
        """

        message_request = ClearCatalogMessage(
            model_id=self.model_id, catalog_id=self.id
        )
        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def get_elements(self, row_count: int = 1000000, column_count: int = 10000) -> Tuple[List, List[List]]:
        """Возвращает кортеж из названий колонок и элементов справочника.

        Аргументы:
            row_count (int): Максимальное количество строк для загрузки. По умолчанию 1000000.
            column_count (int): Максимальное количество столбцов для загрузки. По умолчанию 10000.
        """
        view_data = await self._connector.get_view_definition(
            url=self.json_rpc_url, model_id=self.model_id, view_id=self.id
        )
        message_request = GetDataCatalogMessage(
            model_id=self.model_id,
            view_data=view_data,
            row_count=row_count,
            column_count=column_count
        )
        data = (
            (await self._connector._post(url=self.json_rpc_url, model=message_request))
            .get("result")
            .get("viewRequestResults")[0]
        )
        attributes = data.get("columnLabelPages")[0].get("labels")[0]
        columns_count = len(attributes)
        elements = data.get("dataPages")[0].get("cellValues")

        return attributes, [
            elements[i: i + columns_count]
            for i in range(0, len(elements), columns_count)
        ]

    async def get_views(self, start: int = 0, count: int = -1) -> List[CatalogView]:
        """Метод для получения списка сохраненных представлений справочника."""
        data = await self._connector.get_views(
            url=self.json_rpc_url, model_id=self.model_id, start=start, count=count
        )

        views = [
            CatalogView(
                name=name,
                id=id,
                model_id=self.model_id,
                catalog_id=self.id,
                base_url=str(self.base_url_safe),
                _connector=self._connector,
            )
            for name, id, parent_id in zip(
                data.get("viewsLabelPage", {}).get("entityIds", [[]])[0],
                data.get("viewsLabelPage", {}).get("entityLongIds", [[]])[0],
                data.get("viewsInfos", []),
            )
            if self.id == parent_id.get("contextEntityLongId", None)
        ]

        return views

    async def get_view_by_name(self, view_name: str) -> CatalogView:
        """Метод для получения представления справочника по его имени."""
        views = await self.get_views()
        return next((view for view in views if view.name == view_name), None)

    async def export_views(self, path: str) -> None:
        """
        Экспортирует все представления справочника с параметрами по умолчанию.

        Аргументы:
            path (str): Путь к файлу
        Возвращает:
            None
        """
        views = await self.get_views()
        # Создаем список корутин для экспорта каждого представления
        coroutines = [view.export_file(path) for view in views]
        # Запускаем все корутины одновременно
        await asyncio.gather(*coroutines)

    async def import_catalog(self, source_catalog_id: int) -> None:
        """
        Импортирует данные из другого справочника в текущий справочник.
        Аргументы:
            source_catalog_id (int): Идентификатор справочника источника

        Возвращает:
            None
        """

        message_request = ImportCatalogMessage(
            model_id=self.model_id, source_id=source_catalog_id, destination_id=self.id
        )
        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def import_file(
        self, path: str, encoding: EncodingTypeImport = EncodingTypeImport.AUTO
    ) -> None:
        """
        Импортирует данные из файла в текущий справочник.

        Аргументы:
            path (str): Путь к файлу с данными
            encoding (EncodingTypeImport): Кодировка файла. По умолчанию "AUTO"
        Возвращает:
            None
        """
        if not os.path.exists(path):
            raise FileNotFoundError(f"Файл {path} не найден")
        message_request = ImportFileMessage(
            model_id=self.model_id, hierarchy_long_id=self.id, encoding=encoding
        )
        await self._connector._post_file(
            url=self.json_rpc_url, model=message_request, file=rf"{path}"
        )

    async def export_catalog(self, destination_catalog_id: int) -> None:
        """
        Экспортирует данные текущего справочника в другой справочник.
        Аргументы:
            destination_catalog_id (int): Идентификатор справочника приемника

        Возвращает:
            None
        """

        message_request = ImportCatalogMessage(
            model_id=self.model_id,
            source_id=self.id,
            destination_id=destination_catalog_id,
        )
        await self._connector._post(url=self.json_rpc_url, model=message_request)

    async def export_file(
        self,
        path: str,
        format: DownloadFormat = DownloadFormat.XLSX,
        escape: Literal[None, "\\", '"'] = "\\",
        decimal_separator: str = ".",
        delimiter: str = ";",
        enclosure: str = '"',
        encoding: EncodingTypeExport = EncodingTypeExport.UTF_8,
        filter_boolean_cube: Optional[List[int]] = None,
        filter_formula: Optional[List[Union[str, int]]] = None,
        filter_subset: Optional[List[int]] = None,
        filter_rows: Optional[
            List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
        ] = None,
        filter_cols: Optional[
            List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
        ] = None,
    ):
        """
        Экспортирует справочник в файл.

        Аргументы:
            path (str): Путь для сохранения файла
            format (DownloadFormat): Формат файла для экспорта, доступные варианты: CSV, TXT, XLS, XLSX
            escape (str): Экранирующий символ. Значение по умолчанию - "\\"
            decimal_separator (str): Разделитель десятичной точки. Значение по умолчанию - "."
            delimiter (str): Разделитель значений. Значение по умолчанию - ";"
            enclosure (str): Значение, которое будет использовано для экранирования строковых значений. Значение по умолчанию - "'"
            encoding (EncodingType): Кодировка для записи файла. Значение по умолчанию - "utf-8", доступные варианты:"windows-1251","WINDOWS-1251","win","WIN","utf","UTF","utf-8" ,"UTF-8"
            filter_boolean_cube (List[int]): Фильтр по булеву кубу, по умолчанию не используется.
            filter_formula (List[Union[str, int]]): список со строкой-формулой и идентификатором измерения для фильтрации данных. Значение по умолчанию - None
            filter_subset (List[int]): список с идентификаторами измерений (измерение и сам сабсет) для фильтрации данных. Значение по умолчанию - None
            filter_rows (List[Literal["HIDE", "SHOW_ONLY"], List[int]]): список с типом отображения строк и их идентификаторами для фильтрации данных. Значение по умолчанию - None
            filter_cols (List[Literal["HIDE", "SHOW_ONLY"], List[int]]): список с типом отображения столбцов и их идентификаторами для фильтрации данных. Значение по умолчанию - None

        Возвращает:
            None
        """

        # Формируем объект-сообщения с параметрами для экспорта представления
        message_request = await self._create_export_view_message(
            format=format,
            escape=escape,
            decimal_separator=decimal_separator,
            delimiter=delimiter,
            enclosure=enclosure,
            encoding=encoding,
            filter_boolean_cube=filter_boolean_cube,
            filter_formula=filter_formula,
            filter_subset=filter_subset,
            filter_rows=filter_rows,
            filter_cols=filter_cols,
        )

        # Осуществляем запрос на скачивание данных для экспорта и получаем идентификатор для скачивания данных
        view_hash = await self._connector.get_view_hash(
            url=self.json_rpc_url, export_view_message=message_request
        )
        file_name = re.sub(r'[<>:"/\\|?*{}#]', "_", self.name)
        file_path = os.path.join(path, f"{file_name}.{format.value}")
        await self._connector.download_file_data(
            url=str(self.base_url_safe / "download" / view_hash),
            file_path=file_path,
        )

    async def export_om_file(
        self,
        path: str,
        format: DownloadFormatOM = DownloadFormatOM.OM_CSV,
        escape: Literal[None, "\\", '"'] = "\\",
        decimal_separator: str = ".",
        delimiter: str = ";",
        enclosure: str = '"',
        encoding: EncodingTypeExport = EncodingTypeExport.UTF_8,
        boolean_cube_filter_long_id: Optional[int] = None,
        filter_formula: Optional[str] = None,
    ):
        """
        Экспорт справочника в форматах OM_* (данные непосредственно из БД) - CSV задан по умолчанию.

        Аргументы:
            path (str): Путь к файлу.
            format (DownloadFormatOM): Формат файла для экспорта, доступны OM_CSV, OM_TXT, OM_ZIP
            escape (str): Экранирующий символ. Значение по умолчанию - "\\"
            decimal_separator (str): Разделитель десятичной точки. Значение по умолчанию - "."
            delimiter (str): Разделитель значений. Значение по умолчанию - ";"
            enclosure (str): Значение, которое будет использовано для экранирования строковых значений. Значение по умолчанию - "'"
            encoding (EncodingType): Кодировка для записи файла. Значение по умолчанию - "utf-8", доступные варианты:"windows-1251","WINDOWS-1251","win","WIN","utf","UTF","utf-8" ,"UTF-8"
            boolean_cube_filter_long_id (int): Идентификатор болеан куба для фильтрации.
            filter_formula (str): Формула в формате ОМ для фильтрации.

        Возвращает:
            None
        """

        # Формируем основу объекта-сообщения с параметрами для экспорта представления
        message_request = await self._create_export_view_om_message(
            format=format,
            escape=escape,
            decimal_separator=decimal_separator,
            delimiter=delimiter,
            enclosure=enclosure,
            encoding=encoding,
            boolean_cube_filter_long_id=boolean_cube_filter_long_id,
            filter_formula=filter_formula,
        )
        # Осуществляем запрос на скачивание данных для экспорта
        view_hash = await self._connector.get_view_hash(
            url=self.json_rpc_url, export_view_message=message_request
        )

        file_name = re.sub(r'[<>:"/\\|?*{}#]', "_", self.name)
        file_path = os.path.join(path, f"{file_name}.{format.value}")
        await self._connector.download_file_data(
            url=str(self.base_url_safe / "download" / view_hash),
            file_path=file_path,
        )

    async def export_df(
            self,
            format: DownloadFormat = DownloadFormat.CSV,
            escape: Literal[None, "\\", '"'] = "\\",
            decimal_separator: str = ".",
            delimiter: str = ";",
            enclosure: str = '"',
            encoding: EncodingTypeExport = EncodingTypeExport.UTF_8,
            filter_boolean_cube: Optional[List[int]] = None,
            filter_formula: Optional[List[Union[str, int]]] = None,
            filter_subset: Optional[List[int]] = None,
            filter_rows: Optional[
                List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
            ] = None,
            filter_cols: Optional[
                List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]
            ] = None,
            **kwargs,
    ):
        """
        Получает данные каталога в виде DataFrame Pandas через систему экспорта.

        Аргументы:
            format (DownloadFormat): Формат файла для экспорта. Рекомендуется CSV.
            escape (str): Экранирующий символ. По умолчанию "\\"
            decimal_separator (str): Разделитель десятичной точки. По умолчанию "."
            delimiter (str): Разделитель значений. По умолчанию ";"
            enclosure (str): Символ для экранирования строк. По умолчанию '"'
            encoding (EncodingTypeExport): Кодировка. По умолчанию UTF-8
            filter_boolean_cube (List[int]): Фильтр по булеву кубу
            filter_formula (List[Union[str, int]]): Фильтр по формуле
            filter_subset (List[int]): Фильтр по подмножеству
            filter_rows: Фильтр строк
            filter_cols: Фильтр столбцов
            **kwargs: Дополнительные параметры для pd.read_csv

        Возвращает:
            DataFrame: Экземпляр класса DataFrame Pandas.
        """
        import io

        # Убеждаемся, что encoding - это Enum (на случай если передали строку)
        if isinstance(encoding, str):
            encoding = EncodingTypeExport(encoding)

        # Формируем объект-сообщения с параметрами для экспорта представления
        message_request = await self._create_export_view_message(
            format=format,
            escape=escape,
            decimal_separator=decimal_separator,
            delimiter=delimiter,
            enclosure=enclosure,
            encoding=encoding,
            filter_boolean_cube=filter_boolean_cube,
            filter_formula=filter_formula,
            filter_subset=filter_subset,
            filter_rows=filter_rows,
            filter_cols=filter_cols,
        )

        # Осуществляем запрос на скачивание данных для экспорта и получаем идентификатор
        view_hash = await self._connector.get_view_hash(
            url=self.json_rpc_url, export_view_message=message_request
        )

        # Скачиваем данные в память
        data = await self._connector.download_dataframe(
            url=str(self.base_url_safe / "download" / view_hash)
        )

        # Парсим CSV в DataFrame
        # skiprows=0 (Сейчас нет необходимости пропускать строки, это для справочников)
        df = pd.read_csv(
            io.BytesIO(data),
            skiprows=0,
            delimiter=delimiter,
            encoding=encoding.value,
            **kwargs
        )
        return df