"""Модуль с логгером"""

import logging
import os

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# log_path = os.path.join(os.path.dirname(__file__), "..", "logs", "connector.log")
# fh = logging.FileHandler(log_path, encoding="utf-8")
# fh.setLevel(logging.ERROR)

# formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
# fh.setFormatter(formatter)
#
# logger.addHandler(fh)
