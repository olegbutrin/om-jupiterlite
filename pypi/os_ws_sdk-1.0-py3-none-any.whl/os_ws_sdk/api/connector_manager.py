from os_ws_sdk.api.connector import Connector
from os_ws_sdk.api.v1.connector_v1 import ConnectorV1
from os_ws_sdk.api.ws_version import WsVersion


class ConnectorManager:

    @classmethod
    def create(cls, version: WsVersion, token: str) -> ConnectorV1:
        match version:
            case version.VERSION_9_200:
                return ConnectorV1(token=token)

            case _:
                raise NotImplementedError("Unknown version")
