import enum


class WsVersion(enum.Enum):

    VERSION_9_200 = "9.200"
