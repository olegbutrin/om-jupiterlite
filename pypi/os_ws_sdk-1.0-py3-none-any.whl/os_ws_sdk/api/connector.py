import json

import mimetypes
import re
from abc import ABC
from typing import Any

import aiofiles
import aiohttp

from os_ws_sdk.api.header import Header
from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.components.export_lp_mapping_message import ExportLpMappingMessage
from os_ws_sdk.components.export_view_message import ExportViewMessage
from os_ws_sdk.logging_sdk.logger import logger


class Connector(ABC):

    def __init__(self, token: str):
        self.__token = token
        self.__timeout = 60 * 1000
        self.__chunk_size = 5_242_880
        self.__headers = Header(cookie=f"token={self.__token}").to_dict()

    async def get_ws_info(self, url: str) -> dict:
        raise NotImplementedError

    async def get_models(self, url: str) -> dict:
        raise NotImplementedError

    async def get_model(self, url: str, model_id: str) -> dict:
        raise NotImplementedError

    async def get_multicubes(self, url: str, model_id: str) -> dict:
        raise NotImplementedError

    async def get_catalogs(
        self, url: str, model_id: str, start: int, count: int, filters: list
    ) -> dict:
        raise NotImplementedError

    async def download_milticube_data(self, url: str, file_name: str) -> None:
        raise NotImplementedError

    async def download_backup(self, url: str) -> bytes:
        """Скачивает файл резервной копии и возвращает его содержимое."""
        raise NotImplementedError

    async def get_view_hash(
        self, url: str, export_view_message: ExportViewMessage
    ) -> dict:
        raise NotImplementedError

    async def get_lp_hash(
        self, url: str, export_lp_message: ExportLpMappingMessage
    ) -> str:
        raise NotImplementedError

    async def get_lp_hash(
            self,
            url: str,
            export_lp_message: ExportLpMappingMessage,
    ) -> str:
        raise NotImplementedError

    async def get_system_grid_data(
            self,
            url: str,
            model_id: str,
            grid_id: int,
            model_definition_serial_number: int | None = None,
            context_entity_long_id: int | None = None,
            filter_type: str | None = None,
            filter_params: dict | None = None,
            start_row: int = 0,
            start_column: int = 0,
            row_count: int = 1_000,
            column_count: int = 40,
    ) -> dict:
        raise NotImplementedError

    async def get_views(self, url: str, model_id: str, start: int, count: int) -> dict:
        raise NotImplementedError

    async def get_view_definition(self, url: str, model_id: str, view_id: int) -> str:
        raise NotImplementedError

    async def get_entity_types(self, url: str, model_id: str) -> dict:
        raise NotImplementedError

    async def get_dashboard_definition(
        self,
        url: str,
        model_id: str,
        dashboard_id: int,
        model_definition_serial_number: int | None = None,
    ) -> dict:
        raise NotImplementedError

    async def get_optimizer_requests_table(
        self,
        url: str,
        model_id: str,
        entity_default_view_entity_long_id: int | None = None,
        model_definition_serial_number: int | None = None,
        start_row: int = 0,
        start_column: int = 0,
        row_count: int = 1000,
        column_count: int = 20,
    ) -> dict:
        raise NotImplementedError

    async def _post(self, url: str, model: Any):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url=url,
                    data=model.to_json(),
                    timeout=self.__timeout,
                    headers=self.__headers,
                    ssl=False,
                ) as response:
                    return await response.json()
        except Exception as e:
            logger.error(f"Возникла ошибка при отправке данных: {e}")
            return json.dumps({})

    async def _post_file(self, url: str, model: Any, file: str):
        try:
            async with aiohttp.ClientSession() as session:
                data = aiohttp.MultipartWriter("form-data")
                filename = re.split(r"[\\/]", file)[-1]
                with open(file, "rb") as f:
                    part = data.append(f.read())
                    part.set_content_disposition(
                        "form-data", name="file", filename=filename
                    )
                    part.headers["Content-Type"] = (
                        mimetypes.guess_type(filename)[0] or "application/octet-stream"
                    )
                params = {"json": model.to_json()}
                async with session.post(
                    url=url,
                    data=data,
                    timeout=self.__timeout,
                    headers=self.__headers,
                    params=params,
                    ssl=False,
                ) as response:
                    return await response.json()
        except Exception as e:
            logger.error(f"Возникла ошибка при подключении: {e}")
            return json.dumps({})

    async def _get(self, url: str):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url=url,
                    timeout=self.__timeout,
                    headers=self.__headers,
                    ssl=False,
                ) as response:
                    return await response.json()
        except Exception as e:
            logger.error(f"Возникла ошибка при получении данных: {e}")
            return json.dumps({})

    async def _get_file(self, url: str, file_path: str):
        try:
            async with aiofiles.open(file=file_path, mode="wb") as file:
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        url,
                        headers=self.__headers,
                        timeout=self.__timeout * 100,
                        ssl=False,
                    ) as response:
                        chunk = await response.content.read(self.__chunk_size)
                        while chunk:
                            await file.write(chunk)
                            chunk = await response.content.read(self.__chunk_size)
        except Exception as e:
            logger.error(f"Возникла ошибка при скачивании: {e}")
            return json.dumps({})

    async def _get_data(self, url: str) -> bytes:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers=self.__headers,
                    timeout=self.__timeout * 100,
                    ssl=False,
                ) as response:
                    data = await response.read()
                    return data

        except Exception as e:
            logger.error(f"Возникла ошибка при скачивании: {e}")
            return json.dumps({})

    async def _get_binary_checked(self, url: str) -> bytes:
        """Получает бинарные данные, не скрывая HTTP и сетевые ошибки."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url=url,
                    headers=self.__headers,
                    timeout=self.__timeout * 100,
                    ssl=False,
                    allow_redirects=True,
                ) as response:
                    data = await response.read()

                    if response.status >= 400:
                        body = data.decode(
                            response.charset or "utf-8",
                            errors="replace",
                        ).strip()
                        details = f": {body[:2000]}" if body else ""
                        raise WorkspaceException(
                            response.status,
                            "Не удалось скачать резервную копию: "
                            f"HTTP {response.status} {response.reason}"
                            f"{details}",
                        )

                    if not data:
                        raise WorkspaceException(
                            502,
                            "Optimacros вернул пустой файл резервной копии",
                        )

                    return data

        except WorkspaceException:
            raise
        except Exception as error:
            logger.error(
                f"Возникла ошибка при скачивании резервной копии: {error}"
            )
            raise WorkspaceException(
                500,
                "Не удалось скачать резервную копию: "
                f"{error}",
            ) from error
