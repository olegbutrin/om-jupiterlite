import json
from typing import Optional, List, Union, Literal

from os_ws_sdk.api.connector import Connector
from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.components.base_message import BaseMessage
from os_ws_sdk.components.export_lp_mapping_message import ExportLpMappingMessage
from os_ws_sdk.components.export_view_message import (
    ExportViewMessage,
    ExportViewOmMessage,
)
from os_ws_sdk.components.crud_catalog_message import GetCatalogMessage
from os_ws_sdk.components.get_saved_views_message import GetSavedViewsMessage
from os_ws_sdk.components.get_dashboard_definition_message import (
    GetDashboardDefinitionMessage,
)
from os_ws_sdk.components.get_optimizer_requests_tables_message import (
    GetOptimizerRequestsTablesMessage,
)
from os_ws_sdk.components.get_view_definition_message import GetViewDefinitionMessage
from os_ws_sdk.components.get_system_grid_data_message import (
    GetSystemGridDataMessage,
)


class ConnectorV1(Connector):

    def __init__(self, token: str):
        super().__init__(token)

    async def _create_saved_view_message(
        self, model_id: str, start: int, count: int
    ) -> GetSavedViewsMessage:
        """Создание сообщения запроса на получение списка сохраненных представлений."""
        message_request = GetSavedViewsMessage(model_id=model_id)

        # Передаем в сообщение-запрос start и count - количество выводимых представлений с указанной позиции
        message_request.system_actions[0]["params"]["start"] = start
        message_request.system_actions[0]["params"]["count"] = count

        return message_request

    async def get_ws_info(self, url: str) -> dict | WorkspaceException:
        message_request = BaseMessage()
        response = await self._post(url=url, model=message_request)
        workspace_info = response.get("result", {}).get("workspaceInfo", [])
        if workspace_info:
            return response.get("result", {}).get("workspaceInfo", {})
        raise WorkspaceException(401, "Неверный токен")

    async def get_models(self, url: str) -> dict:
        message_request = BaseMessage(fetch_all_model_summaries=True)
        response = await self._post(url=url, model=message_request)
        return (
            response.get("result", {})
            .get("workspaceInfo", {})
            .get("modelSummaries", [{}])
        )

    async def get_model(self, url: str, model_id: str) -> dict:
        message_request = BaseMessage(
            model_id=model_id, model_definition_serial_number=-1
        )
        response = await self._post(url=url, model=message_request)

        model = (
            response.get("result", {})
            .get("workspaceInfo", {})
            .get("modelSummaries", [{}])[0]
        )
        model_definition_serial_number = (
            response.get("result", {})
            .get("modelInfo", {})
            .get("modelDefinitionSerialNumber", 0)
        )
        # Добавляем атрибут modelDefinitionSerialNumber, нужен будет в других запросах
        if model_definition_serial_number:
            model["modelDefinitionSerialNumber"] = model_definition_serial_number
        return model

    async def get_multicubes(self, url: str, model_id: str) -> dict:
        message_request = BaseMessage(
            model_id=model_id, system_actions=[{"actionId": "GET_MODULES_FROM_MODEL"}]
        )
        response = await self._post(url=url, model=message_request)
        return (
            response.get("result", {})
            .get("systemActionResults", [{}])[0]
            .get("modulesLabelPage", {})
        )

    async def get_catalogs(
        self, url: str, model_id: str, start: int, count: int, filters: list
    ) -> dict:
        message_request = GetCatalogMessage(
            model_id=model_id,
            start=start,
            count=count,
            filters=filters,
        )
        response = await self._post(url=url, model=message_request)
        return response.get("result", {}).get("systemActionResults", [{}])[0]

    async def download_file_data(self, url: str, file_path: str) -> None:
        await self._get_file(url=url, file_path=file_path)

    async def download_backup(self, url: str) -> bytes:
        """Скачивает резервную копию с проверкой ответа backend."""
        return await self._get_binary_checked(url=url)

    async def download_dataframe(self, url: str) -> bytes:
        return await self._get_data(url=url)

    async def get_view_hash(
        self, url: str, export_view_message: ExportViewMessage | ExportViewOmMessage
    ) -> str:
        response = await self._post(url=url, model=export_view_message)
        view_hash = (
            response.get("result", {}).get("systemActionResults", [{}])[0].get("hash")
        )
        # Получаем идентификатор данных для дальнейшего скачивания
        if not view_hash:
            raise WorkspaceException(
                404, "Ошибка, не удалось получить идентификатор файла"
            )
        return view_hash

    async def get_lp_hash(
        self, url: str, export_lp_message: ExportLpMappingMessage
    ) -> str:
        response = await self._post(url=url, model=export_lp_message)
        lp_hash = (
            response.get("result", {})
            .get("systemActionResults", [{}])[0]
            .get("linearModelExportFileId")
        )
        if not lp_hash:
            raise WorkspaceException(
                404, "Ошибка, не удалось получить идентификатор для скачивания LP файла"
            )
        return lp_hash

    async def get_system_grid_data(
            self,
            url: str,
            model_id: str,
            grid_id: int,
            model_definition_serial_number: Optional[int] = None,
            context_entity_long_id: Optional[int] = None,
            filter_type: Optional[str] = None,
            filter_params: Optional[dict] = None,
            start_row: int = 0,
            start_column: int = 0,
            row_count: int = 1_000,
            column_count: int = 40,
    ) -> dict:
        """Возвращает raw viewRequestResult системного grid."""

        filter_dimension_identifier = None

        if filter_type is not None:
            metadata_message = GetSystemGridDataMessage(
                model_id=model_id,
                model_definition_serial_number=model_definition_serial_number,
                entity_default_view_entity_long_id=grid_id,
                context_entity_long_id=context_entity_long_id,
                start_row=0,
                start_column=0,
                row_count=1,
                column_count=1,
            )

            metadata_response = await self._post(
                url=url,
                model=metadata_message,
            )

            metadata_results = (
                metadata_response
                .get("result", {})
                .get("viewRequestResults", [])
            )

            if not metadata_results:
                raise WorkspaceException(
                    404,
                    f"Не удалось получить metadata grid {grid_id}",
                )

            try:
                filter_dimension_identifier = (
                    metadata_results[0]
                    ["viewDefinition"]
                    ["rowAxisSpecification"]
                    ["axisDefinition"]
                    ["dimensionIdentifier"]
                )
            except (KeyError, TypeError, IndexError) as error:
                raise WorkspaceException(
                    500,
                    f"Не удалось определить row dimension grid {grid_id}",
                ) from error

        message_request = GetSystemGridDataMessage(
            model_id=model_id,
            model_definition_serial_number=(
                model_definition_serial_number
            ),
            entity_default_view_entity_long_id=grid_id,
            context_entity_long_id=context_entity_long_id,
            filter_type=filter_type,
            filter_params=filter_params,
            start_row=start_row,
            start_column=start_column,
            row_count=row_count,
            column_count=column_count,
            filter_dimension_identifier=filter_dimension_identifier,
        )

        response = await self._post(
            url=url,
            model=message_request,
        )

        if not isinstance(response, dict):
            raise WorkspaceException(
                500,
                "Некорректный ответ при получении данных системного grid",
            )

        view_results = (
            response
            .get("result", {})
            .get("viewRequestResults", [])
        )

        if not view_results:
            raise WorkspaceException(
                404,
                (
                    "Не удалось получить viewRequestResults "
                    f"системного grid {grid_id}"
                ),
            )

        return view_results[0]

    async def get_views(self, url: str, model_id: str, start: int, count: int) -> dict:
        message_request = await self._create_saved_view_message(
            model_id=model_id, start=start, count=count
        )
        response = await self._post(url=url, model=message_request)
        return response.get("result", {}).get("systemActionResults", [{}])[0]

    async def get_view_definition(
        self,
        url: str,
        model_id: str,
        view_id: int,
        filter_boolean_cube: Optional[List[int]] = None,
        filter_formula: Optional[List[Union[str, int]]] = None,
        filter_subset: Optional[List[int]] = None,
        filter_rows: Optional[
            List[Union[Literal["HIDE", "SHOWS_ONLY"], List[int]]]
        ] = None,
        filter_cols: Optional[
            List[Union[Literal["HIDE", "SHOWS_ONLY"], List[int]]]
        ] = None,
        om_format: bool = False,
    ) -> dict:

        message_request = GetViewDefinitionMessage(
            model_id=model_id,
            view_id=view_id,
            filter_boolean_cube=filter_boolean_cube,
            filter_formula=filter_formula,
            filter_subset=filter_subset,
            filter_rows=filter_rows,
            filter_cols=filter_cols,
            om_format=om_format,
        )

        response = await self._post(url=url, model=message_request)
        return (
            response.get("result", {})
            .get("viewRequestResults", [{}])[0]
            .get("viewDefinition")
        )

    async def get_entity_types(self, url: str, model_id: str) -> dict:
        message_request = BaseMessage(model_id=model_id)
        response = await self._post(url=url, model=message_request)
        return response.get("result", {}).get("entityTypeList", {})

    async def get_dashboard_definition(
        self,
        url: str,
        model_id: str,
        dashboard_id: int,
        model_definition_serial_number: Optional[int] = None,
    ) -> dict:
        """Возвращает распарсенный definitionJsonString дашборда."""
        message_request = GetDashboardDefinitionMessage(
            model_id=model_id,
            dashboard_id=dashboard_id,
            model_definition_serial_number=model_definition_serial_number,
        )
        response = await self._post(url=url, model=message_request)
        if not isinstance(response, dict):
            raise WorkspaceException(
                500,
                f"Некорректный ответ GET_DASHBOARD_DEFINITION для дашборда id={dashboard_id}",
            )

        action_results = response.get("result", {}).get("systemActionResults", [])
        if not action_results:
            raise WorkspaceException(
                404,
                f"Не удалось получить definition дашборда с id={dashboard_id}",
            )

        result = next(
            (
                item
                for item in action_results
                if item.get("actionId") == "GET_DASHBOARD_DEFINITION"
            ),
            action_results[0],
        )
        definition_json_string = result.get("definitionJsonString")
        if isinstance(definition_json_string, dict):
            return definition_json_string
        if not definition_json_string:
            raise WorkspaceException(
                404,
                f"В ответе GET_DASHBOARD_DEFINITION нет definitionJsonString для дашборда id={dashboard_id}",
            )

        try:
            return json.loads(definition_json_string)
        except json.JSONDecodeError as error:
            raise WorkspaceException(
                500,
                f"Не удалось разобрать definitionJsonString дашборда id={dashboard_id}: {error}",
            )

    async def get_optimizer_requests_table(
        self,
        url: str,
        model_id: str,
        entity_default_view_entity_long_id: Optional[int] = None,
        model_definition_serial_number: Optional[int] = None,
        start_row: int = 0,
        start_column: int = 0,
        row_count: int = 1000,
        column_count: int = 20,
    ) -> dict:
        """Возвращает raw viewRequestResult таблицы OPTIMIZER_REQUESTS_TABLES."""
        message_request = GetOptimizerRequestsTablesMessage(
            model_id=model_id,
            entity_default_view_entity_long_id=entity_default_view_entity_long_id,
            model_definition_serial_number=model_definition_serial_number,
            start_row=start_row,
            start_column=start_column,
            row_count=row_count,
            column_count=column_count,
        )
        response = await self._post(url=url, model=message_request)
        if not isinstance(response, dict):
            raise WorkspaceException(
                500,
                "Некорректный ответ OPTIMIZER_REQUESTS_TABLES",
            )

        view_results = response.get("result", {}).get("viewRequestResults", [])
        if not view_results:
            raise WorkspaceException(
                404,
                "Не удалось получить viewRequestResults для OPTIMIZER_REQUESTS_TABLES",
            )
        return view_results[0]
