from enum import Enum


class Endpoints(Enum):
    """Класс Endpoints с конечными точками для обращения к API."""


class JsonRPS(Endpoints):
    """Класс JsonRPS с единой конечной для обращения к API."""

    JSONRPC = "/jsonrpc"
