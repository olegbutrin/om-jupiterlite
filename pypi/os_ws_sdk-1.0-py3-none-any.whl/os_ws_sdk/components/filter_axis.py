"""Модуль для создания классов сообщений-параметров для фильтрации строк и колонок мультикуба."""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Literal

from dataclasses_json import (
    dataclass_json,
    LetterCase,
    Undefined,
    config,
    Exclude,
    CatchAll,
)

from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class FilterAxis(BaseObject):
    """Класс FilterAxis для создания сообщения-параметра для настройки отображаемых осей."""

    modifier: Literal["HIDE", "SHOW_ONLY"]
    axis_ids: Optional[List[int]] = field(metadata=config(exclude=Exclude.ALWAYS))
    axis: Literal["ROWS", "COLUMNS"]
    type: Literal["AXIS_SELECTION_CHANGE"] = "AXIS_SELECTION_CHANGE"
    independent: List[Dict[str, List[int]]] = field(default=list)
    params: Optional[CatchAll] = None

    def __post_init__(self):
        self.independent = [{"type": "ITEMS", "parameters": self.axis_ids}]


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class FilterRows(FilterAxis):
    """
    Класс FilterRows для создания сообщения-параметра для настройки отображаемых строк.

    Аргументы:
        modifier (Literal["HIDE", "SHOW_ONLY"]): Способ фильтрации строк.
        axis_ids (Optional[List[int]]): Список идентификаторов строк для фильтрации.
    """

    axis: Literal["ROWS"] = "ROWS"


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class FilterCols(FilterAxis):
    """
    Класс FilterCols для создания сообщения-параметра для настройки отображаемых столбцов.

    Аргументы:
        modifier (Literal["HIDE", "SHOW_ONLY"]): Способ фильтрации столбцов.
        axis_ids (Optional[List[int]]): Список идентификаторов столбцов для фильтрации.
    """

    axis: Literal["COLUMNS"] = "COLUMNS"
