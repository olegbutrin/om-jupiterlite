from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import dataclass_json, LetterCase, Undefined, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ReCalcModelMessage(BaseMessage):
    """Класс сообщение-параметры для пересчёта модели."""

    system_actions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "RECALCULATE_MODEL",
            }
        ]
