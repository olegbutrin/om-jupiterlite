from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

from dataclasses_json import dataclass_json, LetterCase, Undefined, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage

exclude = config(exclude=Exclude.ALWAYS)


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ChangeCellValueMessage(BaseMessage):
    """Класс сообщение-параметры для очистки значения ячейки в мультикубе."""

    value: Any = field(metadata=exclude, default=None)
    multicube_id: Optional[int] = field(metadata=exclude, default=None)
    cube_id: Optional[int] = field(metadata=exclude, default=None)
    dimension_id: Optional[int] = field(metadata=exclude, default=None)
    submissions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.submissions = [
            {
                "entityLongId": self.multicube_id,
                "key": self.multicube_id,
                "cellChanges": [
                    {
                        "entityLongIds": [
                            self.multicube_id,
                            self.cube_id,
                            self.dimension_id,
                        ],
                        "newValue": f"{self.value}",
                    }
                ],
            }
        ]
