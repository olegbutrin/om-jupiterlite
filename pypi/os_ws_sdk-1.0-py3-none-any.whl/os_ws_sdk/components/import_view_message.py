from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import dataclass_json, LetterCase, Undefined, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ImportViewMessage(BaseMessage):
    """Сообщение-параметры для импорта представления."""

    system_actions: List[Dict] = field(default_factory=list)
    module_long_id: int = field(metadata=config(exclude=Exclude.ALWAYS), default=0)
    key: int = field(metadata=config(exclude=Exclude.ALWAYS), default=0)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "IMPORT_FILE_IN_COMMON",
                "params": {
                    "importTypeLongId": 131000000000,  # Какое-то постоянное значение, Саша не знает подробностей
                    "moduleLongId": self.module_long_id,
                    "key": self.key,
                    "encoding": "auto",  # допустимые значения: auto, AUTO, win, WINDOWS-1251, utf,UTF-8
                    "decimalSeparator": ".",
                    "saveAsAction": False,
                    "modelId": self.model_id,
                },
            }
        ]


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ImportViewOmMessage(BaseMessage):
    """Сообщение-параметры для импорта в ОМ формате."""

    system_actions: List[Dict] = field(default_factory=list)
    namespace_identifier: int = field(
        metadata=config(exclude=Exclude.ALWAYS), default=0
    )

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "IMPORT_STORAGE_VIEW",
                "params": {
                    "namespaceIdentifier": self.namespace_identifier,
                    "delimiter": ";",
                    "decimalSeparator": ".",
                    "encoding": "utf",
                },
            }
        ]
