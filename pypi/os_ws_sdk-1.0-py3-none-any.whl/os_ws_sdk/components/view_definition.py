from dataclasses import dataclass

from dataclasses_json import dataclass_json, LetterCase, Undefined, CatchAll

# from os_ws_sdk.components.axis_specification import AxisSpecification
# from os_ws_sdk.components.bar_configure_stub import BarConfigureStub
# from os_ws_sdk.components.flexible_view_stub import FlexibleViewStub
# from os_ws_sdk.components.postpone_edit_mode_stub import PostponeEditModeStub
# from os_ws_sdk.components.sizes import DefaultCellSizes
from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ViewDefinition(BaseObject):
    unknown_things: CatchAll
    # view_context_identifiers: Union[List[int], Dict[str, str]] = field(
    #     default_factory=list
    # )
    # static_context_identifiers: List[int] = field(default_factory=list)
    # page_axis_specifications: List[AxisSpecification] = field(default_factory=list)
    # current_page_identifiers: List[int] = field(default_factory=list)
    # column_axis_specification: AxisSpecification = None
    # row_axis_specification: AxisSpecification = None
    # flexible_view: Optional[FlexibleViewStub] = None
    # sizes: Optional[DefaultCellSizes] = None
    # bar_configure: Optional[BarConfigureStub] = None
    # # exportSettings: Optional[Any] = None  # Поле является устаревшим
    # # export: Optional[Any] = None  # Поле является устаревшим
    # postpone_edit_mode: Optional[PostponeEditModeStub] = None
    # include_properties: List[Any] = field(default_factory=list)
    # exclude_properties: List[Any] = field(default_factory=list)
    # model_filters: List[int | str] = field(default_factory=list)
    # entity_default_view_entity_long_id: int = 0
    # hidden_dimensions: Optional[Any] = None
