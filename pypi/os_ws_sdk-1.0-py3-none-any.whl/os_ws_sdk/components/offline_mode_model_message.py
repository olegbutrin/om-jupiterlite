from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import dataclass_json, LetterCase, Undefined, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class BaseOfflineModeModelMessage(BaseMessage):
    """Базовый класс сообщение-параметры для остановки/запуска модели."""

    system_actions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "SET_MODEL_OFFLINE_MODE",
                # "status":	"online"
                "params":
                {"modelId": self.model_id}
            }
        ]
        self.model_id = None

@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class OfflineModeModelMessage(BaseOfflineModeModelMessage):
    """Класс сообщение-параметры для остановки модели."""

    def __post_init__(self):
            super().__post_init__()
            self.system_actions[0]["params"]["status"]="on"

@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class OnlineModeModelMessage(BaseOfflineModeModelMessage):
    """Класс сообщение-параметры для включения модели."""

    def __post_init__(self):
            super().__post_init__()
            self.system_actions[0]["params"]["status"]="off"

