from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import dataclass_json, LetterCase, Undefined, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class MulticubeToMulticubeMessage(BaseMessage):
    """Класс сообщение-параметры для экспорта-импорта из одного мультикуба в другой."""

    multicube_id: int = field(metadata=config(exclude=Exclude.ALWAYS), default=None)
    destination_mc_id: int = field(
        metadata=config(exclude=Exclude.ALWAYS), default=None
    )
    system_actions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "IMPORT_MODULE_FROM_MODEL",
                "params": {
                    "destinationModuleLongId": self.destination_mc_id,
                    "saveAsAction": False,
                    "omitEmptyRows": False,
                    "omitSummaryRows": True,
                    "sourceModelId": self.model_id,
                    "sourceModuleLongId": self.multicube_id,
                },
            }
        ]
