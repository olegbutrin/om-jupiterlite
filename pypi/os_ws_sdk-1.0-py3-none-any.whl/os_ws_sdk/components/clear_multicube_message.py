from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import dataclass_json, LetterCase, Undefined, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ClearMulticubeMessage(BaseMessage):
    """Класс сообщение-параметры для очистки мультикуба."""

    view_requests: List[Dict] = field(default_factory=lambda: [{"viewDefinition": {}}])
    multicube_id: int = field(metadata=config(exclude=Exclude.ALWAYS), default=1)
    submissions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.submissions = [
            {
                "key": "MODULES",
                "cellChanges": [
                    {
                        "noCurrentValue": True,
                        "entityLongIds": [self.multicube_id, 4000000381],
                        "newValue": "true",
                    }
                ],
            }
        ]
