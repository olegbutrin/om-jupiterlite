from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import dataclass_json, LetterCase, Undefined, Exclude, config

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ExportLpMappingMessage(BaseMessage):
    """Класс сообщение-параметры для экспорта оптимизационной задачи в формат LP."""

    optimization_query_id: int = field(
        metadata=config(exclude=Exclude.ALWAYS), default=1
    )
    system_actions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "SAVED_ACTION_RUN",
                "params": {
                    "savedActionLongId": self.optimization_query_id,
                    "options": {"exportLinearModel": True, "timeoutInMinutes": 5},
                },
            }
        ]
