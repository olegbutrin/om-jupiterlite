from dataclasses import dataclass, field
from typing import Dict, List, Optional

from dataclasses_json import (
    Exclude,
    LetterCase,
    Undefined,
    config,
    dataclass_json,
)

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(
    letter_case=LetterCase.CAMEL,
    undefined=Undefined.INCLUDE,
)
@dataclass
class GetSystemGridDataMessage(BaseMessage):
    """Сообщение для чтения данных системного grid."""

    entity_default_view_entity_long_id: int = field(
        default=0,
        metadata=config(exclude=Exclude.ALWAYS),
    )

    context_entity_long_id: Optional[int] = field(
        default=None,
        metadata=config(exclude=Exclude.ALWAYS),
    )

    filter_type: Optional[str] = field(
        default=None,
        metadata=config(exclude=Exclude.ALWAYS),
    )

    filter_params: Optional[Dict] = field(
        default=None,
        metadata=config(exclude=Exclude.ALWAYS),
    )

    start_row: int = field(
        default=0,
        metadata=config(exclude=Exclude.ALWAYS),
    )

    start_column: int = field(
        default=0,
        metadata=config(exclude=Exclude.ALWAYS),
    )

    row_count: int = field(
        default=1_000,
        metadata=config(exclude=Exclude.ALWAYS),
    )

    column_count: int = field(
        default=40,
        metadata=config(exclude=Exclude.ALWAYS),
    )

    filter_dimension_identifier: Optional[int] = field(
        default=None,
        metadata=config(exclude=Exclude.ALWAYS),
    )

    view_requests: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        view_reference = {
            "entityDefaultViewEntityLongId": (
                self.entity_default_view_entity_long_id
            ),
        }

        if self.context_entity_long_id is not None:
            view_reference["contextEntityLongId"] = (
                self.context_entity_long_id
            )

        self.view_requests = [
            {
                "viewReference": view_reference,
                "dataPageRequests": [
                    {
                        "startRow": self.start_row,
                        "startColumn": self.start_column,
                        "rowCount": self.row_count,
                        "columnCount": self.column_count,
                    }
                ],
                "rowLabelPageRequests": [
                    {
                        "start": self.start_row,
                        "count": self.row_count,
                    }
                ],
                "columnLabelPageRequests": [
                    {
                        "start": self.start_column,
                        "count": self.column_count,
                    }
                ],
            }
        ]

        if self.filter_type is not None:
            if self.filter_dimension_identifier is None:
                raise ValueError(
                    "Для DIMENSION_CUSTOM_FILTER не определён "
                    "filter_dimension_identifier"
                )

            filter_payload = {
                "type": self.filter_type,
                "params": self.filter_params or {},
            }

            self.view_requests[0]["key"] = self.filter_type
            self.view_requests[0]["viewChanges"] = [
                {
                    "type": "DIMENSION_CUSTOM_FILTER",
                    "dimensionIdentifier": self.filter_dimension_identifier,
                    "dimensionCustomFilter": {
                        "filter": filter_payload,
                    },
                }
            ]