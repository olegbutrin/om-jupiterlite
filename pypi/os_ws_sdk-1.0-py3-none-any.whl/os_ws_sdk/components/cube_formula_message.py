from dataclasses import dataclass, field
from typing import Dict, List, Union
from uuid import uuid4

from dataclasses_json import Exclude, LetterCase, config, dataclass_json

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class GetCubesInfoMessage(BaseMessage):
    """JSON-RPC сообщение для системного action ``GET_CUBES_INFO``."""

    start: int = field(
        metadata=config(exclude=Exclude.ALWAYS),
        default=0,
    )
    count: int = field(
        metadata=config(exclude=Exclude.ALWAYS),
        default=100,
    )
    system_actions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "GET_CUBES_INFO",
                "params": {
                    "start": self.start,
                    "count": self.count,
                },
            }
        ]


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class ChangeCubeFormulaMessage(BaseMessage):
    """Меняет Formula-property line item через обычный cellInput submission."""

    grid_id: int = field(
        metadata=config(exclude=Exclude.ALWAYS),
        default=0,
    )
    multicube_id: int = field(
        metadata=config(exclude=Exclude.ALWAYS),
        default=0,
    )
    cube_id: Union[int, str] = field(
        metadata=config(exclude=Exclude.ALWAYS),
        default=0,
    )
    formula_property_id: int = field(
        metadata=config(exclude=Exclude.ALWAYS),
        default=4000000009,
    )
    current_formula: str = field(
        metadata=config(exclude=Exclude.ALWAYS),
        default="",
    )
    new_formula: str = field(
        metadata=config(exclude=Exclude.ALWAYS),
        default="",
    )
    submissions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.submissions = [
            {
                "entityLongId": self.multicube_id,
                "key": self.multicube_id,
                "messageId": f"messageId_{uuid4().hex}",
                "specialActionMessage": "cellInput",
                "cellChanges": [
                    {
                        "asText": True,
                        "noCurrentValue": False,
                        "entityLongIds": [
                            self.grid_id,
                            self.multicube_id,
                            self.cube_id,
                            self.formula_property_id,
                        ],
                        "currentText": self.current_formula,
                        "newText": self.new_formula,
                    }
                ],
            }
        ]
