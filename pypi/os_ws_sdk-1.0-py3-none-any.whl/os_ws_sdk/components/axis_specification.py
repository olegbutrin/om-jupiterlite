from dataclasses import dataclass
from dataclasses_json import dataclass_json, LetterCase
from typing import Optional, Union

from os_ws_sdk.components.cross_product_specification import (
    CrossProductSpecification,
)
from os_ws_sdk.components.full_dimension_specification import (
    FullDimensionSpecification,
)
from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class AxisSpecification(BaseObject):
    axis_definition: Union[FullDimensionSpecification, CrossProductSpecification]
    axis_definition_identifier: Optional[int]
