from dataclasses import dataclass, field
from typing import List, Dict, Optional, Union, Literal

from dataclasses_json import dataclass_json, LetterCase, Undefined, Exclude, config

from os_ws_sdk.components.base_message import BaseMessage
from os_ws_sdk.components.filter_axis import FilterCols, FilterRows

exclude_field = config(exclude=Exclude.ALWAYS)
filter_axis = Optional[List[Union[Literal["HIDE", "SHOW_ONLY"], List[int]]]]


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class GetViewDefinitionMessage(BaseMessage):
    """Сообщение-параметры для получения информации о viewDefinition мультикуба (view)."""

    view_id: int = field(metadata=exclude_field, default=1)
    view_requests: List[Dict] = field(default_factory=list)
    filter_boolean_cube: Optional[List[int]] = field(
        metadata=exclude_field, default=None
    )
    om_format: bool = field(metadata=exclude_field, default=False)
    filter_formula: Optional[List[Union[str, int]]] = field(
        metadata=exclude_field, default=None
    )
    filter_subset: Optional[List[int]] = field(metadata=exclude_field, default=None)
    filter_rows: filter_axis = field(metadata=exclude_field, default=None)
    filter_cols: filter_axis = field(metadata=exclude_field, default=None)

    def __post_init__(self):
        self.view_requests = [
            {
                "viewReference": {"entityDefaultViewEntityLongId": self.view_id},
                "viewChanges": [],
            }
        ]
        if not self.filter_boolean_cube is None and not self.om_format:
            self.view_requests[0]["viewChanges"].append(
                {
                    "type": "FILTER_BY_BOOLEAN_CUBE",
                    "dimensionIdentifier": self.filter_boolean_cube[1],
                    "cubeEntityLongId": self.filter_boolean_cube[0],
                }
            )
        if not self.filter_formula is None and not self.om_format:
            self.view_requests[0]["viewChanges"].append(
                {
                    "type": "FILTER_BY_FORMULA",
                    "dimensionIdentifier": self.filter_formula[1],
                    "filterByFormula": {
                        "conditionalFormula": self.filter_formula[0],
                        "status": True,
                    },
                }
            )
        if not self.filter_subset is None and not self.om_format:
            self.view_requests[0]["viewChanges"].append(
                {
                    "dimensionIdentifier": f"{self.filter_subset[0]}",
                    "type": "FILTER_BY_SUBSETS",
                    "entityLongIds": [self.filter_subset[1]],
                    "subsetDropDownType": {"type": "LIST"},
                }
            )
        if not self.filter_rows is None and not self.om_format:
            self.view_requests[0]["viewChanges"].append(FilterRows(*self.filter_rows))

        if not self.filter_cols is None and not self.om_format:
            self.view_requests[0]["viewChanges"].append(FilterCols(*self.filter_cols))


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class GetSavedViewDefinitionMessage(BaseMessage):
    """Сообщение-параметры для получения информации о сохраненных viewDefinition представления."""

    system_actions: List[Dict] = field(
        default_factory=lambda: [
            {
                "actionId": "GET_SAVED_VIEW_DEFINITION_INFO",
                "params": {"entityLongId": 0},
            }
        ]
    )
