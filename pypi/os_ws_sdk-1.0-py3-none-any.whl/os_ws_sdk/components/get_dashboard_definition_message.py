from dataclasses import dataclass, field
from typing import Dict, List

from dataclasses_json import Exclude, LetterCase, Undefined, config, dataclass_json

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class GetDashboardDefinitionMessage(BaseMessage):
    """Сообщение-параметры для получения definitionJsonString дашборда."""

    dashboard_id: int = field(metadata=config(exclude=Exclude.ALWAYS), default=0)
    system_actions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "GET_DASHBOARD_DEFINITION",
                "params": {"entityLongId": self.dashboard_id},
            }
        ]
