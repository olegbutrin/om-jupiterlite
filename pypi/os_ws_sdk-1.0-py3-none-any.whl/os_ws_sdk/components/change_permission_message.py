"""JSON-RPC message for changing model role permissions."""

from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import (
    Exclude,
    LetterCase,
    Undefined,
    config,
    dataclass_json,
)

from os_ws_sdk.components.base_message import BaseMessage


_EXCLUDE = config(exclude=Exclude.ALWAYS)


@dataclass_json(
    letter_case=LetterCase.CAMEL,
    undefined=Undefined.INCLUDE,
)
@dataclass
class ChangePermissionMessage(BaseMessage):
    """Builds one ``cellInput`` submission for a permission grid."""

    grid_id: int = field(default=0, metadata=_EXCLUDE)
    permission_property_id: int = field(default=0, metadata=_EXCLUDE)
    object_id: int = field(default=0, metadata=_EXCLUDE)
    role_id: int = field(default=0, metadata=_EXCLUDE)
    current_text: str = field(default="", metadata=_EXCLUDE)
    new_text: str = field(default="", metadata=_EXCLUDE)
    submission_key: str = field(default="ROLES_MODULES", metadata=_EXCLUDE)
    message_id: str = field(default="messageId_sdk", metadata=_EXCLUDE)

    submissions: List[Dict] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.submissions = [
            {
                "entityLongId": self.grid_id,
                "key": self.submission_key,
                "messageId": self.message_id,
                "specialActionMessage": "cellInput",
                "cellChanges": [
                    {
                        "asText": True,
                        "noCurrentValue": False,
                        "entityLongIds": [
                            self.grid_id,
                            self.permission_property_id,
                            self.object_id,
                            self.role_id,
                        ],
                        "currentText": self.current_text,
                        "newText": self.new_text,
                    }
                ],
            }
        ]
