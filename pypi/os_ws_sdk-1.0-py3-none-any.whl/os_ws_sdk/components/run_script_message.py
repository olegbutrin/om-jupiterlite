from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import dataclass_json, LetterCase, Undefined, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class RunScriptMessage(BaseMessage):
    """Класс сообщение-параметры для запуска скрипта."""

    script_id: int = field(metadata=config(exclude=Exclude.ALWAYS), default=1)
    system_actions: List[Dict] = field(default_factory=list)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "SAVED_ACTION_RUN",
                "params": {"savedActionLongId": self.script_id},
            }
        ]
