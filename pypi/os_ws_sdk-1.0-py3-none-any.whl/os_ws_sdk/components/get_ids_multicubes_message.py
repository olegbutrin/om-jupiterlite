from dataclasses import dataclass, field
from typing import List

from dataclasses_json import dataclass_json, LetterCase, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage
from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class Param(BaseObject):
    query: str = ""


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class Rule(BaseObject):
    params: List[Param] = field(default_factory=list)
    type: str = ""


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class EtlAction(BaseObject):
    rules: List[Rule] = field(default_factory=list)


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class GetIdMulticubeByNameMessage(BaseMessage):
    """Класс сообщение-параметры для получения id мультикубов по их именам."""

    name: str = field(metadata=config(exclude=Exclude.ALWAYS), default="")
    etl_action: EtlAction = field(default_factory=EtlAction)

    def __post_init__(self):
        self.etl_action.rules.append(
            Rule(params=[Param(query=self.name)], type="SEARCH_MULTICUBE_BY_NAME")
        )
