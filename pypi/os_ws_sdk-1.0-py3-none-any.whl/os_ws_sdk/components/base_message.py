from dataclasses import dataclass, field
from typing import Optional, List, Any

from dataclasses_json import dataclass_json, LetterCase, Undefined, CatchAll

from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class BaseMessage(BaseObject):
    model_id: Optional[str] = None
    params: Optional[CatchAll] = None
    request_type: str = "VIEW_REQUEST_SET"
    fetch_all_model_summaries: bool = False
    lazy_load_grid_views_selectors: bool = True
    without_workspace_info: bool = False
    view_requests: List[Any] = field(default_factory=list)
    model_definition_serial_number: Optional[int] = None
    system_actions: List[Any] = field(default_factory=list)
