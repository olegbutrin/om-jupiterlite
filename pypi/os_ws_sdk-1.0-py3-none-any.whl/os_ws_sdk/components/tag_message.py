from dataclasses import dataclass
from typing import Optional

from dataclasses_json import dataclass_json, LetterCase

from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class TagMessage(BaseObject):
    long_id: int
    name: str
    color: Optional[str]
    use_in_filters: bool
    is_personal: bool
