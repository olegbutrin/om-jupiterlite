"""Модуль с классом Enum для обозначения типа кодировки."""

from enum import Enum


class EncodingTypeExport(Enum):
    """Класс перечисления для обозначения типа кодировки при экспорте данных."""

    WINDOWS_1251 = "windows-1251"
    WINDOWS_1251_UPPER = "WINDOWS-1251"
    WIN = "win"
    WIN_UPPER = "WIN"
    UTF = "utf"
    UTF_UPPER = "UTF"
    UTF_8 = "utf-8"
    UTF_8_UPPER = "UTF-8"


class EncodingTypeImport(Enum):
    """Класс перечисления для обозначения типа кодировки при импорте данных."""

    WINDOWS_1251 = "WINDOWS-1251"
    WIN = "win"
    UTF = "utf"
    UTF_8_UPPER = "UTF-8"
    AUTO = "auto"
    AUTO_UPPER = "AUTO"
