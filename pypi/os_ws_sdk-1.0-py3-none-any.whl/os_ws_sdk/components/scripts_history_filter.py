from __future__ import annotations

from datetime import datetime, timedelta, timezone
from enum import IntEnum
from typing import Any, Dict, Iterable, Optional, Union


class ScriptStatus(IntEnum):
    """Статусы выполнения скрипта для фильтра истории."""

    NONE = 0
    WAIT_IN_QUEUE = 1
    IN_PROGRESS = 2
    SUCCESS = 3
    FAILED = 4
    ABORTED = 5


class ScriptRunType(IntEnum):
    """Тип запуска скрипта для фильтра истории."""

    INTERFACE = 0
    SCHEDULER = 1
    API = 2


TimestampValue = Union[int, float, datetime]
TimeValue = Union[str, int]


def _timestamp_to_seconds(
    value: TimestampValue,
    *,
    field_name: str,
) -> Union[int, float]:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return int(value.timestamp())

    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(
            f"{field_name} должен быть Unix timestamp в секундах "
            "или datetime"
        )

    return value


def _enum_value(
    value: Union[int, IntEnum],
    enum_type,
    *,
    field_name: str,
) -> int:
    if isinstance(value, bool):
        raise ValueError(f"Недопустимое значение {field_name}: {value}")

    try:
        return int(enum_type(value))
    except (TypeError, ValueError) as error:
        allowed = ", ".join(
            f"{item.name}={item.value}" for item in enum_type
        )
        raise ValueError(
            f"Недопустимое значение {field_name}: {value}. "
            f"Допустимые значения: {allowed}"
        ) from error


def _normalize_identifiers(
    identifiers: Optional[Iterable[int]],
) -> Optional[list[int]]:
    if identifiers is None:
        return None

    if isinstance(identifiers, (str, bytes)):
        raise TypeError("identifiers должен быть коллекцией integer ID")

    result = []
    for identifier in identifiers:
        if isinstance(identifier, bool) or not isinstance(identifier, int):
            raise TypeError(
                "Каждый элемент identifiers должен быть integer ID"
            )
        result.append(identifier)

    return result


def _normalize_time_value(
    value: Optional[TimeValue],
    *,
    field_name: str,
) -> Optional[TimeValue]:
    if value is None:
        return None

    if isinstance(value, bool) or not isinstance(value, (str, int)):
        raise TypeError(
            f"{field_name} должен быть строкой времени или integer"
        )

    return value


def build_scripts_history_filter(
    *,
    identifiers: Optional[Iterable[int]] = None,
    date_from: Optional[TimestampValue] = None,
    date_to: Optional[TimestampValue] = None,
    elapsed_time: Optional[Union[int, float]] = None,
    request_id: Optional[str] = None,
    run_type: Optional[Union[int, ScriptRunType]] = None,
    show_archive: Optional[bool] = None,
    status: Optional[Union[int, ScriptStatus]] = None,
    time_from: Optional[TimeValue] = None,
    time_to: Optional[TimeValue] = None,
    user: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Формирует top-level фильтр ``SCRIPTS_HISTORY_FILTER``.

    Если ``date_from`` не задан, используется момент за 24 часа до
    текущего времени UTC. Даты передаются backend как Unix timestamp
    в секундах.
    """

    if date_from is None:
        date_from = datetime.now(timezone.utc) - timedelta(hours=24)

    normalized_date_from = _timestamp_to_seconds(
        date_from,
        field_name="date_from",
    )

    normalized_date_to = None
    if date_to is not None:
        normalized_date_to = _timestamp_to_seconds(
            date_to,
            field_name="date_to",
        )
        if normalized_date_from > normalized_date_to:
            raise ValueError("date_from не может быть больше date_to")

    if elapsed_time is not None:
        if isinstance(elapsed_time, bool) or not isinstance(
            elapsed_time,
            (int, float),
        ):
            raise TypeError("elapsed_time должен быть числом")

    if request_id is not None and not isinstance(request_id, str):
        raise TypeError("request_id должен быть строкой")

    if show_archive is not None and not isinstance(show_archive, bool):
        raise TypeError("show_archive должен быть bool")

    if user is not None and not isinstance(user, str):
        raise TypeError("user должен быть строкой")

    params: Dict[str, Any] = {
        "dateFrom": normalized_date_from,
    }

    normalized_identifiers = _normalize_identifiers(identifiers)
    if normalized_identifiers is not None:
        params["identifiers"] = normalized_identifiers

    if normalized_date_to is not None:
        params["dateTo"] = normalized_date_to

    if elapsed_time is not None:
        params["elapsedTime"] = elapsed_time

    if request_id is not None:
        params["requestId"] = request_id

    if run_type is not None:
        params["runType"] = _enum_value(
            run_type,
            ScriptRunType,
            field_name="run_type",
        )

    if show_archive is not None:
        params["showArchive"] = show_archive

    if status is not None:
        params["status"] = _enum_value(
            status,
            ScriptStatus,
            field_name="status",
        )

    normalized_time_from = _normalize_time_value(
        time_from,
        field_name="time_from",
    )
    if normalized_time_from is not None:
        params["timeFrom"] = normalized_time_from

    normalized_time_to = _normalize_time_value(
        time_to,
        field_name="time_to",
    )
    if normalized_time_to is not None:
        params["timeTo"] = normalized_time_to

    if user is not None:
        params["user"] = user

    return {
        "type": "SCRIPTS_HISTORY_FILTER",
        "params": params,
    }
