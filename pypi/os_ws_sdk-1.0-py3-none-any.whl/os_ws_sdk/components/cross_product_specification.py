from dataclasses import dataclass
from typing import List, Any

from dataclasses_json import dataclass_json, LetterCase

from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class CrossProductSpecification(BaseObject):
    child_axis_definitions: List[Any]  # TODO: Определить класс ChildAxisDefinition
    type: str = "CROSS_PRODUCT"
