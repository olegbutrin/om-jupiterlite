from dataclasses import dataclass, field
from typing import Any, Literal

from dataclasses_json import dataclass_json, LetterCase

from os_ws_sdk.components.download_format import (
    DownloadFormat,
)
from os_ws_sdk.components.view_definition import ViewDefinition
from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class View(BaseObject):
    escape: Literal[None, "\\", '"'] = "\\"
    view_definition: ViewDefinition = field(default_factory=ViewDefinition)
    decimal_separator: str = "."
    delimiter: str = ";"
    enclosure: str = '"'
    encoding: str = "utf-8"
    exact_view: bool = False
    file_name: str = "example"
    format: DownloadFormat = field(default_factory=lambda: DownloadFormat.CSV)
    include_codes: bool = False
    include_model_identifier: bool = False
    is_summary: bool = False
    mapping_for_advanced_import: bool = False
    mapping_for_flexible_import: bool = False
    omit_empty_rows: bool = False
    omit_row_headers: bool = False
    omit_summary_rows: bool = False
    round_number: int = -1
    save_as_action: bool = False
    show_aliases_without_names: bool = False
    show_export_report_info: bool = False
    source_map: Any = 0
    use_code_like_labels: bool = False
