from dataclasses import dataclass, field
from typing import List, Dict, Optional, Union

from dataclasses_json import dataclass_json, LetterCase, Undefined, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage
from os_ws_sdk.components.encoding_type import EncodingTypeImport

exclude = config(exclude=Exclude.ALWAYS)


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class BaseCatalogMessage(BaseMessage):
    """Базовый класс сообщений-параметров для работы со справочниками в модели."""

    submissions: List[Dict] = field(
        default_factory=lambda: [
            {"modelChanges": [{"modelChangeJson": {"type": ..., "params": {}}}]}
        ]
    )
    names: Optional[List[str]] = field(metadata=exclude, default=None)
    count: int = field(metadata=exclude, default=1)
    position: str = field(metadata=exclude, default="End")
    relative_to: Optional[str] = field(metadata=exclude, default=None)
    catalog_id: Optional[int] = field(metadata=exclude, default=None)
    ids: List[int] = field(metadata=exclude, default=None)
    type_index: int = field(metadata=exclude, default=None)

    def _set_params(self):
        pass

    def __post_init__(self):
        self._set_params()


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class CreateCatalogMessage(BaseCatalogMessage):
    """Класс сообщение-параметры для создания нового справочника в модели."""

    def _set_params(self):
        self.submissions[0]["modelChanges"][0]["modelChangeJson"].update(
            type="DefineHierarchy"
        )
        if not self.names is None:
            self.submissions[0]["modelChanges"][0]["modelChangeJson"].update(
                params=[
                    {
                        "name": name,
                        "position": self.position,
                        "relativeTo": self.relative_to,
                    }
                    for name in self.names
                ]
            )
        else:
            self.submissions[0]["modelChanges"][0]["modelChangeJson"]["params"].update(
                entityCount=self.count,
                position=self.position,
                relativeTo=self.relative_to,
            )


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class DeleteCatalogMessage(BaseCatalogMessage):
    """Класс сообщение-параметры для удаления справочника в модели."""

    def _set_params(self):
        self.submissions[0]["modelChanges"][0]["modelChangeJson"].update(
            type="DeleteHierarchy", params=[{"entityLongId": id} for id in self.ids]
        )


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class AddElementsMessage(BaseCatalogMessage):
    """Класс сообщение-параметры для добавления элементов в справочник."""

    def _set_params(self):
        self.submissions[0]["modelChanges"][0]["modelChangeJson"].update(
            type="DefineEntities",
            entityLongId=self.catalog_id,
            params={
                "position": self.position,
                "entityTypeIndex": self.type_index,
                "relativeTo": self.relative_to,
            },
        )
        if not self.names is None:
            self.submissions[0]["modelChanges"][0]["modelChangeJson"]["params"].update(
                items=[{"name": name, "new": True} for name in self.names]
            )
        else:
            self.submissions[0]["modelChanges"][0]["modelChangeJson"]["params"].update(
                entityCount=self.count
            )


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class RenameCatalogMessage(BaseCatalogMessage):
    """Класс сообщение-параметры для переименования справочников."""

    def _set_params(self):
        self.submissions[0]["modelChanges"][0]["modelChangeJson"].update(
            type="RenameEntity"
        )
        if self.ids is None:
            self.submissions[0]["modelChanges"][0]["modelChangeJson"].update(
                params=[{"newName": self.names[0], "entityLongId": self.catalog_id}]
            )
        else:
            self.submissions[0]["modelChanges"][0]["modelChangeJson"].update(
                params=[
                    {"newName": name, "entityLongId": id}
                    for name, id in zip(self.names, self.ids)
                ]
            )


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class DeleteElementsMessage(BaseCatalogMessage):
    """Класс сообщение-параметры для удаления элементов из справочника."""

    def _set_params(self):
        self.submissions[0]["modelChanges"][0]["modelChangeJson"].update(
            type="DeleteEntities",
            entityLongId=self.catalog_id,
            params={"items": {}, "entityTypeIndex": self.type_index},
        )
        if not self.ids is None:
            self.submissions[0]["modelChanges"][0]["modelChangeJson"]["params"].update(
                items=[{"entityLongId": id} for id in self.ids],
            )
        elif not self.names is None:
            self.submissions[0]["modelChanges"][0]["modelChangeJson"]["params"].update(
                items=[{"entityName": name} for name in self.names],
            )


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class GetCatalogMessage(BaseMessage):
    """Класс сообщение-параметры для получения справочников."""

    start: int = field(metadata=exclude, default=0)
    count: int = field(metadata=exclude, default=-1)
    filters: Optional[List[Union[str, int]]] = None
    system_actions: List[Dict] = field(default_factory=list)

    def _set_filters(self) -> None:
        self.system_actions[0]["params"].update(
            filters={
                ["identifiers", "names"][isinstance(self.filters[0], str)]: self.filters
            }
        )

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "GET_HIERARCHIES_INFO",
                "params": {"start": self.start, "count": self.count},
            }
        ]
        if not self.filters is None:
            self._set_filters()


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ClearCatalogMessage(BaseMessage):
    """Класс сообщение-параметры для очистки справочника."""

    system_actions: List[Dict] = field(default_factory=list)
    catalog_id: Optional[int] = field(metadata=exclude, default=None)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "DELETE_ALL_LIST_ENTITIES",
                "params": {"identifier": {"entityLongId": self.catalog_id}},
            }
        ]


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class GetDataCatalogMessage(BaseMessage):
    """Класс сообщение-параметры для получения данных справочника."""

    view_data: Dict = field(default_factory=dict, metadata=exclude)
    row_count: int = field(default=1000000, metadata=exclude)
    column_count: int = field(default=10000, metadata=exclude)

    def __post_init__(self):
        self.view_requests = [
            {
                "dataPageRequests": [
                    {"startRow": 0, "startColumn": 0, "rowCount": self.row_count, "columnCount": self.column_count}
                ],
                "rowLabelPageRequests": [{"start": 0, "count": 71}],
                "columnLabelPageRequests": [{"start": 0, "count": 41}],
                "viewDefinition": self.view_data,
            }
        ]


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ImportCatalogMessage(BaseMessage):
    """Класс сообщение-параметры для импорта данных из другого справочника."""

    system_actions: List[Dict] = field(default_factory=list)
    source_id: Optional[int] = field(metadata=exclude, default=None)
    destination_id: Optional[int] = field(metadata=exclude, default=None)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "IMPORT_LIST_FROM_MODEL",
                "params": {
                    "sourceModelId": self.model_id,
                    "sourceListLongId": self.source_id,
                    "destinationListLongId": self.destination_id,
                    "proxySourceColumnDataMap": [],
                },
            }
        ]


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ImportFileMessage(BaseMessage):
    """Сообщение-параметры для импорта данных в справочник из файла."""

    system_actions: List[Dict] = field(default_factory=list)
    hierarchy_long_id: int = field(
        metadata=config(exclude=Exclude.ALWAYS), default=None
    )
    encoding: EncodingTypeImport = field(default=EncodingTypeImport.AUTO)

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "IMPORT_FILE_IN_COMMON",
                "params": {
                    "hierarchyLongId": self.hierarchy_long_id,
                    "importTypeLongId": 131000000002,  # видимо id типа сущности, так же было в мультикубах, но там другое значение, надо будет найти что это такое
                    "encoding": self.encoding,
                    "decimalSeparator": ".",
                    "saveAsAction": False,
                    "key": f"LIST_VIEW_HIERARCHY_{self.hierarchy_long_id}",
                },
            }
        ]
