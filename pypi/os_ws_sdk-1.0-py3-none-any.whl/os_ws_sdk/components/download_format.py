"""Модуль с классом Enum для определения формата скачиваемого файла."""

from enum import Enum


class DownloadFormat(Enum):
    """Класс DownloadFormat с форматами скачиваемого файла при экспорте View в обычных форматах."""

    CSV = "csv"
    TXT = "txt"
    XLS = "xls"
    XLSX = "xlsx"


class DownloadFormatOM(Enum):
    """Класс DownloadFormatOM с форматами скачиваемого файла при экспорте View в форматах OM_*."""

    OM_CSV = "csv"
    OM_TXT = "txt"
    OM_ZIP = "gz"
