from dataclasses import dataclass

from dataclasses_json import dataclass_json, LetterCase

from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class PostponeEditModeStub(BaseObject): ...  # TODO
