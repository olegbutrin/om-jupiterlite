from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import dataclass_json, LetterCase, Undefined

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ImportLpMappingMessage(BaseMessage):
    """Класс сообщение-параметры для импорта решения оптимизационной задачи."""

    system_actions: List[Dict] = field(
        default_factory=lambda: [
            {"actionId": "IMPORT_OPTIMIZATION_RESULT", "params": {}}
        ]
    )
