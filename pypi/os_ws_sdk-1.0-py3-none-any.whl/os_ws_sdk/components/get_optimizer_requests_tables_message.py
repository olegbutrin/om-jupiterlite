from dataclasses import dataclass, field
from typing import Dict, Optional

from dataclasses_json import Exclude, LetterCase, Undefined, config, dataclass_json

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class GetOptimizerRequestsTablesMessage(BaseMessage):
    """Сообщение для получения системной таблицы optimizer requests."""

    entity_default_view_entity_long_id: Optional[int] = field(
        metadata=config(exclude=Exclude.ALWAYS), default=None
    )
    start_row: int = field(metadata=config(exclude=Exclude.ALWAYS), default=0)
    start_column: int = field(metadata=config(exclude=Exclude.ALWAYS), default=0)
    row_count: int = field(metadata=config(exclude=Exclude.ALWAYS), default=1000)
    column_count: int = field(metadata=config(exclude=Exclude.ALWAYS), default=20)

    def __post_init__(self):
        view_request: Dict = {
            "key": "OPTIMIZER_REQUESTS_TABLES",
            "dataPageRequests": [
                {
                    "startRow": self.start_row,
                    "startColumn": self.start_column,
                    "rowCount": self.row_count,
                    "columnCount": self.column_count,
                }
            ],
            "rowLabelPageRequests": [
                {"start": self.start_row, "count": self.row_count}
            ],
            "columnLabelPageRequests": [
                {"start": self.start_column, "count": self.column_count}
            ],
        }

        if self.entity_default_view_entity_long_id is not None:
            view_request["viewReference"] = {
                "entityDefaultViewEntityLongId": self.entity_default_view_entity_long_id
            }

        self.view_requests = [view_request]
