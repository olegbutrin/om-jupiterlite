"""JSON-RPC message for changing one UAM cell."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from dataclasses_json import (
    Exclude,
    LetterCase,
    Undefined,
    config,
    dataclass_json,
)

from os_ws_sdk.components.base_message import BaseMessage


_EXCLUDE = config(exclude=Exclude.ALWAYS)


@dataclass_json(
    letter_case=LetterCase.CAMEL,
    undefined=Undefined.INCLUDE,
)
@dataclass
class ChangeUamMessage(BaseMessage):
    """Builds one ``cellInput`` submission for a list UAM grid."""

    uam_grid_id: int = field(default=0, metadata=_EXCLUDE)
    list_id: int = field(default=0, metadata=_EXCLUDE)
    item_id: int = field(default=0, metadata=_EXCLUDE)
    user_id: int = field(default=0, metadata=_EXCLUDE)
    permission_property_id: int = field(default=4000001005, metadata=_EXCLUDE)
    current_text: Optional[str] = field(default=None, metadata=_EXCLUDE)
    new_text: str = field(default="None", metadata=_EXCLUDE)
    no_current_value: bool = field(default=True, metadata=_EXCLUDE)
    message_id: str = field(default="messageId_sdk", metadata=_EXCLUDE)

    submissions: List[Dict] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.submissions = [
            {
                "entityLongId": self.list_id,
                "key": f"HIERARCHY_SELECTIVE_ACCESS_{self.list_id}",
                "messageId": self.message_id,
                "specialActionMessage": "cellInput",
                "cellChanges": [
                    {
                        "asText": True,
                        "noCurrentValue": self.no_current_value,
                        "entityLongIds": [
                            self.uam_grid_id,
                            self.list_id,
                            self.permission_property_id,
                            self.item_id,
                            self.user_id,
                        ],
                        "currentText": self.current_text,
                        "newText": self.new_text,
                    }
                ],
            }
        ]
