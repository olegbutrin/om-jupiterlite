from dataclasses import dataclass, field
from typing import List, Dict, Literal, Optional

from dataclasses_json import dataclass_json, LetterCase, Undefined, config, Exclude

from os_ws_sdk.components.base_message import BaseMessage
from os_ws_sdk.components.download_format import DownloadFormat
from os_ws_sdk.components.encoding_type import EncodingTypeExport
from os_ws_sdk.components.get_view_definition_message import GetViewDefinitionMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ExportViewMessage(BaseMessage):
    """Сообщение-параметры для экспорта представления."""

    system_actions: List[Dict] = field(default_factory=list)
    view_data: Dict = field(
        default_factory=dict, metadata=config(exclude=Exclude.ALWAYS)
    )
    format: DownloadFormat = field(default=DownloadFormat.CSV)
    escape: Literal[None, "\\", '"'] = "\\"
    decimal_separator: str = "."
    delimiter: str = ";"
    enclosure: str = '"'
    encoding: EncodingTypeExport = EncodingTypeExport.UTF_8
    file_name: str = "example"

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "EXPORT_VIEW",
                "params": {
                    "fileName": self.file_name,
                    "viewDefinition": GetViewDefinitionMessage.from_dict(
                        self.view_data
                    ),
                    "omitEmptyRows": False,
                    "omitSummaryRows": True,
                    "omitRowHeaders": False,
                    "showAliasesWithoutNames": False,
                    "includeCodes": False,
                    "mappingForFlexibleImport": False,
                    "mappingForAdvancedImport": False,
                    "saveAsAction": False,
                    "showExportReportInfo": False,
                    "delimiter": self.delimiter,
                    "encoding": self.encoding.value,
                    "decimalSeparator": self.decimal_separator,
                    "format": self.format.value,
                    "escape": self.escape,
                    "enclosure": self.enclosure,
                },
            }
        ]


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class ExportViewOmMessage(BaseMessage):
    """Сообщение-параметры для экспорта представления в форматах OM."""

    system_actions: List[Dict] = field(default_factory=list)
    view_data: Dict = field(
        default_factory=dict, metadata=config(exclude=Exclude.ALWAYS)
    )
    format: DownloadFormat = field(default=DownloadFormat.CSV)
    escape: Literal[None, "\\", '"'] = "\\"
    decimal_separator: str = "."
    delimiter: str = ";"
    enclosure: str = '"'
    encoding: str = "utf-8"
    file_name: str = "example"
    boolean_cube_filter_long_id: Optional[int] = None
    filter_formula: Optional[str] = None

    def __post_init__(self):
        self.system_actions = [
            {
                "actionId": "EXPORT_STORAGE_VIEW",
                "params": {
                    "fileName": self.file_name,
                    "viewDefinition": GetViewDefinitionMessage.from_dict(
                        self.view_data
                    ),
                    "delimiter": self.delimiter,
                    "encoding": self.encoding,
                    "decimalSeparator": self.decimal_separator,
                    "format": self.format.value,
                    "escape": self.escape,
                    "enclosure": self.enclosure,
                    "omitEmptyRows": False,
                    "omitSummaryRows": False,
                },
            }
        ]
        if self.boolean_cube_filter_long_id is not None:
            self.system_actions[0]["params"][
                "booleanCubeFilterLongId"
            ] = self.boolean_cube_filter_long_id

        if self.filter_formula is not None:
            self.system_actions[0]["params"]["filterFormula"] = self.filter_formula
