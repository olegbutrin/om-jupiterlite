from dataclasses import dataclass
from typing import Dict, Optional, List

from dataclasses_json import dataclass_json, LetterCase

from os_ws_sdk.components.calculated_headers import CalculatedHeaders
from os_ws_sdk.objects.base_object import BaseObject


@dataclass_json(letter_case=LetterCase.CAMEL)
@dataclass
class DefaultCellSizesMessage(BaseObject):
    columns_width: List | Dict[str, int]
    rows_height: Dict[str, int] = None
    calculated_headers: Optional[CalculatedHeaders] = None
    default_cell_height: Optional[int] = None
    default_cell_width: Optional[int] = None
