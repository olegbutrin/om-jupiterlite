"""Модуль с классом Enum для определения позиции вставки при создании сущностей."""

from enum import Enum


class Position(Enum):
    """Перечисление для определения позиции вставки при создании сущностей."""

    START = "Start"
    END = "End"
    BEFORE = "Before"
    AFTER = "After"
