from dataclasses import dataclass, field
from typing import List, Dict

from dataclasses_json import dataclass_json, LetterCase, Undefined

from os_ws_sdk.components.base_message import BaseMessage


@dataclass_json(letter_case=LetterCase.CAMEL, undefined=Undefined.INCLUDE)
@dataclass
class GetSavedViewsMessage(BaseMessage):
    """Сообщение-параметры для получения информации о сохраненных Views."""

    system_actions: List[Dict] = field(
        default_factory=lambda: [
            {"actionId": "GET_SAVED_VIEWS_INFO", "params": {"count": -1, "start": 0}}
        ]
    )
