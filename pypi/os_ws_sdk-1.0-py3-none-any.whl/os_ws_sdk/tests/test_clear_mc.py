import asyncio
import sys

import pytest

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_clear_mc1(model, model_iol):
    model1 = await model
    model2 = await model_iol
    mk1 = await model1.get_multicube_by_name("Тестовый мультикуб 1")
    mk2 = await model2.get_multicube(102000000083)
    await asyncio.gather(mk1.clear(), mk2.clear())
