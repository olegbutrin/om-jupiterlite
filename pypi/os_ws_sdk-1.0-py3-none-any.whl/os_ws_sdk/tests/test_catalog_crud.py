import asyncio
import os
import random
import sys

import pytest

from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.components.download_format import DownloadFormat
from os_ws_sdk.components.position import Position
from os_ws_sdk.objects.catalog import Catalog
from os_ws_sdk.objects.model import Model

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_create_catalogs(model):
    model_: Model = await model
    await model_.create_catalogs(
        names=[f"Еще один новый справочник {i}" for i in range(1, 4)],
        # count=3,
        position=Position.END,
        relative_to="Roles",
    )
    catalog: Catalog = await model_.get_catalog_by_name("Еще один новый справочник 1")
    await catalog.create(
        model_id=catalog.model_id, names=["Еще один новый справочник 4"]
    )


@pytest.mark.asyncio
async def test_delete_catalogs(model):
    model_: Model = await model
    tasks = [
        asyncio.create_task(
            model_.get_catalog_by_name(f"Еще один новый справочник {i}")
        )
        for i in range(1, 5)
    ]
    catalog1, catalog2, catalog3, catalog4 = await asyncio.gather(*tasks)
    await model_.delete_catalogs([catalog1.id, catalog2.id, catalog3.id])
    with pytest.raises(WorkspaceException):
        await model_.get_catalog_by_name("Еще один новый справочник 1")
    await catalog4.delete()
    with pytest.raises(WorkspaceException):
        await model_.get_catalog_by_name("Еще один новый справочник 4")


@pytest.mark.asyncio
async def test_add_elements(model):
    model_: Model = await model
    catalog: Catalog = await model_.get_catalog(101000000012)
    await catalog.add_elements(names=["тест1", "тест2"], position=Position.END)
    # await catalog.add_elements(count=2)


@pytest.mark.asyncio
async def test_delete_elements(model):
    model_: Model = await model
    catalog: Catalog = await model_.get_catalog(101000000012)
    # await catalog.delete_elements(ids=[473000000036, 473000000037])
    await catalog.delete_elements(names=["тест1", "тест2"])


@pytest.mark.asyncio
async def test_rename_catalogs_and_elements(model):
    model_: Model = await model
    catalog: Catalog = await model_.get_catalog(101000000012)
    elements_ids = [235000000003, 235000000004]  # ids элементов справочника
    catalogs_ids = [101000000134, 101000000135]  # ids справочников
    task1 = catalog.rename(names=[f"Тест{random.randint(1, 1000)}"])
    task2 = catalog.rename_elements(
        names=[f"Тест{random.randint(1, 1000)}" for _ in elements_ids],
        elements_ids=elements_ids,
    )
    task3 = model_.rename_catalogs(
        names=[f"Тест{random.randint(1, 1000)}" for _ in catalogs_ids], ids=catalogs_ids
    )
    await asyncio.gather(task1, task2, task3)


@pytest.mark.asyncio
async def test_get_catalogs(model):
    """
    Тестирование получения справочников.
    """
    model_ = await model
    catalogs = await model_.get_catalogs(start=2, count=5)
    assert isinstance(catalogs, list)
    assert isinstance(catalogs[0], Catalog)
    assert len(catalogs) == 5


@pytest.mark.asyncio
async def test_get_catalog_by_id_name(model):
    # Формируем name существующего справочника в модели
    name = "1.0 Продукция"
    id = 101000000005
    model_ = await model
    task1 = model_.get_catalog_by_name(name)
    task2 = model_.get_catalog(id)
    catalogs = await asyncio.gather(task1, task2)
    for catalog in catalogs:
        assert isinstance(catalog, Catalog)
    with pytest.raises(WorkspaceException):
        await model_.get_catalog_by_name("Invalid name")
    with pytest.raises(WorkspaceException):
        await model_.get_catalog(1000000000000000000)


@pytest.mark.asyncio
async def test_clear_catalog(model):
    model_: Model = await model
    catalog: Catalog = await model_.get_catalog(101000000136)  # Справочник Тест очистка
    # Сначала добавим элементы в справочник
    await catalog.add_elements(count=3)
    # Далее удалим все элементы из справочника
    await catalog.clear()


@pytest.mark.asyncio
async def test_get_elements(model):
    model_: Model = await model
    catalog: Catalog = await model_.get_catalog(
        101000000006
    )  # Справочник 1.0 Устройства
    # Получим все элементы справочника
    elements = await catalog.get_elements()
    assert isinstance(elements, tuple)
    assert elements[1][-1][0] == "Блок питания"


@pytest.mark.asyncio
async def test_import_from_catalog(model):
    model_: Model = await model
    catalog: Catalog = await model_.get_catalog(
        101000000137
    )  # Справочник "Тест импорт из справочника"
    # очистим справочник от элементов
    await catalog.clear()
    source_catalog_id = 101000000012
    await catalog.import_catalog(source_catalog_id=source_catalog_id)


@pytest.mark.asyncio
async def test_import_from_file(model, path_file_view_import):
    model_: Model = await model
    catalog: Catalog = await model_.get_catalog(
        101000000138
    )  # Справочник "Тест импорт из файла"
    # очистим справочник от элементов
    await catalog.clear()
    path = os.path.join(path_file_view_import, "test_import_list.xlsx")
    await catalog.import_file(path=path)


@pytest.mark.asyncio
async def test_export_to_catalog(model):
    model_: Model = await model
    catalog: Catalog = await model_.get_catalog(
        101000000137
    )  # Справочник "Тест импорт из справочника"
    destination_catalog_id = 101000000139  # Справочник "Тест экспорт в справочник"
    await catalog.export_catalog(destination_catalog_id=destination_catalog_id)


@pytest.mark.asyncio
async def test_export_to_file(model, path_for_download):
    model_: Model = await model
    catalog: Catalog = await model_.get_catalog(
        id=101000000140
    )  # Справочник "Тест экспорт в файл"
    await catalog.export_file(path=path_for_download)
    # Проверяем существование файла
    assert os.path.exists(
        os.path.join(path_for_download, f"{catalog.name}.{DownloadFormat.XLSX.value}")
    )
