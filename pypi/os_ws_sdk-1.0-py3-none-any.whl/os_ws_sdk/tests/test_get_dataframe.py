import asyncio
import sys

import pytest
import pandas as pd

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_get_dataframe(multicube_for_export_df, view_for_export_df):
    """Тест получения данных мультикуба в виде DataFrame."""
    multicube_ = await multicube_for_export_df
    view_ = await view_for_export_df
    for df in await asyncio.gather(multicube_.export_df(), view_.export_df()):
        assert isinstance(df, pd.DataFrame)
        print("\n")
        print(df.head())
        print()
