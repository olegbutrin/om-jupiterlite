import asyncio
import os
import sys

import pytest

from os_ws_sdk.components.download_format import DownloadFormat

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_import_view_multicube(multicubes_for_import_view, path_file_view_import):
    """
    Тестирование импорта представления мультикуба, в разных форматах.

    Аргументы:
        multicube_for_import_view (MultiCubes): Мультикуб для импорта.
        path_file_view_import (str): Путь к файлу.
    """
    multicubes = await multicubes_for_import_view
    for format, multicube in zip(DownloadFormat.__members__.values(), multicubes):
        path = os.path.join(
            path_file_view_import, f"x_SDK_test_export_view.{format.value}"
        )

        await multicube.import_file(path)


@pytest.mark.asyncio
async def test_import_subview(view, path_file_view_import):
    """
    Тестирование импорта сохраненного представления.

    Аргументы:
        view (View): Представление для импорта.
        path_file_view_import (str): Путь к файлу.
    """
    path = os.path.join(path_file_view_import, "test_export_sub_view.csv")
    view_ = await view

    await view_.import_file(path)


@pytest.mark.asyncio
async def test_import_multicube_om(multicube_for_import_om, path_file_view_import):
    """
    Тестирование импорта мультикуба, в формате OM.

    Аргументы:
        multicube_for_import_view (MultiCubes): Мультикуб для импорта.
        path_file_view_import (str): Путь к файлу.
    """
    path = os.path.join(path_file_view_import, "test_import_multicube_om.csv")
    multicube = await multicube_for_import_om
    await multicube.import_om_file(path)

    # path = os.path.join(path_file_view_import, "test_import_multicube_om.txt")
    # await multicube.import_om_file(path)
    #
    # path = os.path.join(path_file_view_import, "test_import_multicube_om.gz")
    # await multicube.import_om_file(path)


@pytest.mark.asyncio
async def test_import_subview_om(view_for_import_om, path_file_view_import):
    """
    Тестирование импорта сохраненного представления в ОМ формате.

    Аргументы:
        view (View): Представление для импорта.
        path_file_view_import (str): Путь к файлу.
    """

    view_ = await view_for_import_om

    path = os.path.join(path_file_view_import, "Test_import_view_om.csv")
    await view_.import_om_file(path)
