import asyncio
import os
import sys

import pytest

from os_ws_sdk.components.download_format import (
    DownloadFormat,
    DownloadFormatOM,
)
from os_ws_sdk.objects.view import View
from os_ws_sdk.logging_sdk.logger import logger
from os_ws_sdk.objects.multicube import Multicube

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_export_view(multicube, path_for_download):
    """
    Тестирование экспорта сущности модели, в данном случае мультикуба, в формате CSV-файла.

    Аргументы:
        multicube (Multicube): Объект Multicube.
        path_for_download (str): Путь для сохранения файла.
        download_format_csv (DownloadFormat): Формат для экспорта.
    """

    multicube_ = await multicube
    tasks = [
        multicube_.export_file(rf"{path_for_download}", format)
        for format in DownloadFormat
    ]
    await asyncio.gather(*tasks)

    # Проверяем существование файла
    assert os.path.exists(
        os.path.join(path_for_download, f"{multicube_.name}.{DownloadFormat.CSV.value}")
    )

    # Проверка ошибок
    try:
        # Передаем не верный путь
        await multicube_.export_file("wrong_path")
    except Exception as e:
        logger.error(f"Ошибка при экспорте в csv из-за неверного пути, ошибка {e}")


@pytest.mark.asyncio
async def test_export_sub_view_csv(view, path_for_download):
    view_ = await view
    await view_.export_file(rf"{path_for_download}")


@pytest.mark.asyncio
async def test_export_mc_om_formats(multicube, path_for_download):
    mc_ = await multicube
    await mc_.export_om_file(rf"{path_for_download}")


@pytest.mark.asyncio
async def test_export_view_om_formats(view, path_for_download, download_format_om):
    view_ = await view
    tasks = [
        view_.export_om_file(rf"{path_for_download}", format_om)
        for format_om in download_format_om
    ]
    await asyncio.gather(*tasks)


@pytest.mark.asyncio
async def test_export_views(multicube, path_for_download):
    multicube_ = await multicube
    await multicube_.export_views(path_for_download)


@pytest.mark.asyncio
async def test_export_om_bool_filter(model_iol, path_for_download):
    boolean_cube_filter_long_id = int(os.getenv("CUBE_FILTER_ID")) #248000000252
    model_ = await model_iol
    mc = await model_.get_multicube(int(os.getenv("MC_ID"))) #102000000039
    mc1 = await model_.get_multicube(int(os.getenv("MC_ID_1"))) #102000000029
    view_mc1 = await mc1.get_view_by_name(os.getenv("MC_VIEW_NAME_1")) # "Тест импорт view"
    task1 = view_mc1.export_om_file(
        path=path_for_download, boolean_cube_filter_long_id=int(os.getenv("CUBE_FILTER_ID_1"))
    )
    task2 = mc.export_om_file(
        path=path_for_download, boolean_cube_filter_long_id=boolean_cube_filter_long_id
    )
    await asyncio.gather(task1, task2)


@pytest.mark.asyncio
async def test_export_om_filter_formula(model, path_for_download):
    model_ = await model
    mc = await model_.get_multicube(int(os.getenv("MC_ID")))
    formula1 = os.getenv("MC_FORMULA_FILTER")  # "'Тест экспорт фильтр формула'.'Строка TXT' = 5 AND 'Тест экспорт фильтр формула'.'Булеан' = TRUE"
    view_mc = await mc.get_view_by_name(os.getenv("MC_VIEW_NAME"))
    formula2 = (
       os.getenv("MC_FORMULA_FILTER_1")  # "('Тест экспорт фильтр формула'.'Строка CSV' = 3 OR 'Тест экспорт фильтр формула'.'Строка CSV' = 6) AND 'Тест экспорт фильтр формула'.'Булеан' = FALSE"
    )
    task1 = mc.export_om_file(
        path=path_for_download, filter_formula=formula1, format=DownloadFormatOM.OM_TXT
    )
    task2 = view_mc.export_om_file(
        path=path_for_download, filter_formula=formula2, format=DownloadFormatOM.OM_CSV
    )

    await asyncio.gather(task1, task2)


@pytest.mark.asyncio
async def test_export_bool_filter(model, path_for_download):
    filter_boolean_cube = [int(os.getenv("CUBE_FILTER_ID")),int(os.getenv("CUBE_FILTER_DIMENSION"))]#[220000000069, 13000000003]
    model_ = await model
    mc = await model_.get_multicube_by_name(os.getenv("MC_NAME"))
    view_mc = await mc.get_view_by_name(os.getenv("MC_VIEW_NAME"))
    task1 = mc.export_file(
        path=path_for_download, filter_boolean_cube=filter_boolean_cube
    )
    task2 = view_mc.export_file(
        path=path_for_download, filter_boolean_cube=filter_boolean_cube
    )

    await asyncio.gather(task1,task2)


@pytest.mark.asyncio
async def test_export_filter_formula(model, path_for_download):
    model_ = await model
    mc = await model_.get_multicube_by_name(os.getenv("MC_NAME"))  # "Тест экспорт фильтр формула"
    formula1 = os.getenv("MC_FORMULA_FILTER")  # "'Тест экспорт фильтр формула'.'Строка TXT' = 5 AND 'Тест экспорт фильтр формула'.'Булеан' = TRUE"
    view_mc = await mc.get_view_by_name(os.getenv("MC_VIEW_NAME")) #вью1
    formula2 = (
        os.getenv("MC_FORMULA_FILTER_1")  # "('Тест экспорт фильтр формула'.'Строка CSV' = 3 OR 'Тест экспорт фильтр формула'.'Строка CSV' = 6) AND 'Тест экспорт фильтр формула'.'Булеан' = FALSE"
    )
    task1 = mc.export_file(
        path=path_for_download,
        filter_formula=[formula1, int(os.getenv("CUBE_FILTER_DIMENSION"))],
        format=DownloadFormat.TXT,
    )
    task2 = view_mc.export_file(
        path=path_for_download,
        filter_formula=[formula2, int(os.getenv("CUBE_FILTER_DIMENSION"))],
    )

    await asyncio.gather(task1, task2)


@pytest.mark.asyncio
async def test_export_filter_subset(model_iol, path_for_download):
    model_ = await model_iol
    mk = await model_.get_multicube_by_name(os.getenv("MC_NAME"))
    view_ = await mk.get_view_by_name(os.getenv("MC_VIEW_NAME"))
    dimension_id = int(os.getenv("CUBE_FILTER_DIMENSION")) #101000000005
    subset_id = int(os.getenv("DIMENSION_SUBSET")) #109000000010
    task1 = mk.export_file(
        path=path_for_download, filter_subset=[dimension_id, subset_id]
    )
    task2 = view_.export_file(
        path=path_for_download, filter_subset=[dimension_id, subset_id]
    )
    await asyncio.gather(task1, task2)


@pytest.mark.asyncio
async def test_export_filter_axis(model, path_for_download):
    model_ = await model
    mk: Multicube = await model_.get_multicube_by_name(os.getenv("MC_NAME"))  # "Тест фильтр осей вью"
    view: View = await mk.get_view_by_name(os.getenv("MC_VIEW_NAME"))  # "Тест фильтр осей вью"

    rows = [227000000012, 227000000013, 227000000014] #[226000000081, 226000000085, 226000000090]
    cols = [272000000346, 272000000347] #[5441970031, 5442280028, 5442560031]
    task1 = mk.export_file(
        filter_rows=["SHOW_ONLY", rows],
        filter_cols=["HIDE", cols],
        path=path_for_download,
    )
    task2 = view.export_file(
        filter_rows=["HIDE", rows],
        filter_cols=["SHOW_ONLY", cols],
        path=path_for_download,
    )

    await asyncio.gather(task1, task2)
