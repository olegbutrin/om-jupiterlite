import asyncio
import sys

import pytest

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_import_solution_mapping(model, path_file_solution_lp):
    """Тестирование импорта решения оптимизационного запроса из файла."""
    model_ = await model

    response = await model_.import_solution_mapping(path_file_solution_lp)

    # Проверяем, успешность ответа
    assert response["success"]

    # Проверяем ошибку при передаче неверного пути к файлу
    with pytest.raises(Exception):
        await model.import_solution_mapping("wrong_path")
