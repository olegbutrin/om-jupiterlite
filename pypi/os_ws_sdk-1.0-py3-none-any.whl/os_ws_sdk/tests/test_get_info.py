import asyncio
import sys

import pytest

from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.objects.model import Model
from os_ws_sdk.dto.ws_info import WsInfo

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_get_info(workspace, expected_ws_name):
    """
    Тестирование получения информации о рабочем пространстве.

    Аргументы:
        workspace (Workspace): Объект Workspace.
        expected_ws_name (str): Ожидаемое имя рабочего пространства.

    """
    # Получаем информацию о рабочем пространстве
    ws = await workspace.info()

    # # Проверяем что имя рабочего пространства соответствует ожидаемому значению
    # assert ws["workspaceName"] == expected_ws_name
    # Проверяем что возвращается объект WS
    assert isinstance(ws, WsInfo)


@pytest.mark.asyncio
async def test_wrong_token(invalid_workspace, expected_model_id, expected_model_name):
    """
    Тестирование отсутствия возвращаемых значений при передаче неверного токена.

    Аргументы:
        invalid_workspace (Workspace): Объект Workspace с неверным токеном.
        expected_model_id (str): Ожидаемый идентификатор модели.
        expected_model_name (str): Ожидаемое имя модели.

    """

    # Проверяем что при передаче неверного токена выбрасывается исключение WorkspaceException
    with pytest.raises(WorkspaceException):
        ws = await invalid_workspace.info()


@pytest.mark.asyncio
async def test_get_models(workspace):
    """
    Тестирование получения списка моделей.

    Аргументы:
        workspace (Workspace): Объект Workspace.

    """
    models = await workspace.get_models()
    # Проверяем, что именно возвращается список, именно список моделей и что идентификатор
    # и имя одной из моделей соответствует ожидаемым значениям
    assert type(models) == list
    assert all(isinstance(model, Model) for model in models)
    assert len(models) == 5  # FIXME: могут добавить или удалить модели


@pytest.mark.asyncio
async def test_get_model(workspace, expected_model_id, expected_model_name):
    """
    Тестирование получения объекта модели.

    Аргументы:
        workspace (Workspace): Объект Workspace.
        expected_model_id (str): Ожидаемый идентификатор модели.
        expected_model_name (str): Ожидаемое имя модели.

    """
    model = await workspace.get_model(expected_model_id)
    assert expected_model_name == model.model_name
    assert model.model_id == expected_model_id


@pytest.mark.asyncio
async def test_model_info(model):
    """Тестирование получения информации о модели - ModelInfo."""
    model_ = await model
    model_info = model_.info()
    assert model_info.model_id == model_.model_id
    assert model_info.model_name == model_.model_name


@pytest.mark.asyncio
async def test_multicube_info(multicube):
    """Тестирование получения информации о мультикубе - MulticubeInfo."""
    multicube_ = await multicube
    multicube_info = await multicube_.info()
    assert multicube_info.id == multicube_.id
    assert multicube_info.name == multicube_.name


@pytest.mark.asyncio
async def test_view_onfo(view):
    """Тестирование получения информации о view - ViewInfo."""
    view_ = await view
    view_info = await view_.info()
    assert view_info.name == view_.name
    assert view_info.id == view_.id
