import asyncio
import sys

import pandas as pd
import pytest

from os_ws_sdk.objects.model import Model
from os_ws_sdk.objects.multicube import Multicube
from os_ws_sdk.objects.view import View

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_get_filter_df(model_iol, model):
    """Тест получения данных мультикуба в виде DataFrame после фильтрации."""
    model1 = await model_iol
    model1: Model
    model2 = await model
    model2: Model
    mk1, mk2 = await asyncio.gather(
        model1.get_multicube_by_name("M01.09 Материальный баланс (месяцы)"),
        model2.get_multicube_by_name("Тест экспорт фильтр формула"),
    )
    bool_cube_id = 129000000008
    dimension_id = 101000000005
    subset_entity_id = 109000000010
    formula = (
        "('Тест экспорт фильтр формула'.'Строка TXT' = 5 OR 'Тест экспорт фильтр формула'.'Строка TXT' = 8) "
        "AND 'Тест экспорт фильтр формула'.'Булеан' = TRUE"
    )
    dimension_id_by_formula = 13000000003
    task1 = asyncio.create_task(
        mk1.export_df(filter_boolean_cube=[bool_cube_id, dimension_id])
    )
    task2 = asyncio.create_task(
        mk1.export_df(filter_subset=[dimension_id, subset_entity_id])
    )
    task3 = asyncio.create_task(
        mk2.export_df(filter_formula=[formula, dimension_id_by_formula])
    )
    mk3: Multicube = await model2.get_multicube_by_name("Тест фильтр осей")
    view: View = await mk3.get_view_by_name("Тест фильтр осей вью")
    rows = [226000000081, 226000000085, 226000000090]
    cols = [5441970031, 5442280028, 5442560031]
    task4 = mk3.export_df(
        filter_rows=["SHOW_ONLY", rows],
        filter_cols=["HIDE", cols],
    )
    task5 = view.export_df(
        filter_rows=["HIDE", rows],
        filter_cols=["SHOW_ONLY", cols],
    )

    for df in await asyncio.gather(task1, task2, task3, task4, task5):
        assert isinstance(df, pd.DataFrame)
        print("\n")
        print(df.head())
        print()
