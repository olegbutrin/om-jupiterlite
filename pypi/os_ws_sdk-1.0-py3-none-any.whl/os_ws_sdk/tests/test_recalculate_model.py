import asyncio
import os
import sys
from zipfile import ZipFile

import pytest

from os_ws_sdk.components.recalc_model_message import ReCalcModelMessage
from os_ws_sdk.objects.model import Model

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_recalculate(model: Model):
    """Тестирование пересчёта модели."""

    model_ = await model
    res = await model_.recalculate()
    assert res == True

@pytest.mark.asyncio
async def test_recalculate_wrong_model (model: Model):
    """Тестирование пересчёта модели."""

    model_ = await model
    model_.model_id = "ERR"
    with pytest.raises(ValueError):
        await model_.recalculate()


@pytest.mark.asyncio
async def test_recalculate_message_err(model: Model):
    """Тестирование ошибок при неправильном экшене в пересчёте модели."""

    model_ = await model
    message_request = ReCalcModelMessage(model_id=model_.model_id)
    message_request.system_actions = [
            {
                "actionId": "RECALCULATE_MODEL_ERR",
            }
        ]
    response = await model_._connector._post(
        url=model_.json_rpc_url, model=message_request
    )
    result = response.get("result", {}).get("systemActionResults", [{}])[0]
    assert result["modalInfo"]
    
   