import asyncio
import sys

import pytest

from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.objects.catalog import Catalog
from os_ws_sdk.objects.multicube import Multicube
from os_ws_sdk.objects.view import View

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_get_multicubes(model):
    """
    Тестирование получения мультикубов модели.

    Аргументы:
        model (Model): Объект Model.
    """
    model_ = await model
    multicubes = await model_.get_multicubes()
    assert isinstance(multicubes, list)
    assert multicubes


@pytest.mark.asyncio
async def test_get_multicube(model, expected_multicube_name, expected_multicube_id):
    model_ = await model

    multicube = await model_.get_multicube(expected_multicube_id)
    assert isinstance(multicube, Multicube)
    assert multicube.name == expected_multicube_name
    invalid_id_multicube = 545446464
    # Проверка на невалидный id мультикуба, метод должен вернуть None
    invalid_multicube = await model_.get_multicube(invalid_id_multicube)
    assert invalid_multicube is None


@pytest.mark.asyncio
async def test_get_catalogs(model):
    """
    Тестирование получения справочников.

    Аргументы:
        workspace (Workspace): Объект Workspace.
        expected_model_id (str): id существующей модели.
    """
    model_ = await model
    catalogs = await model_.get_catalogs(start=0, count=1)
    assert isinstance(catalogs, list)
    assert isinstance(catalogs[0], Catalog)


@pytest.mark.asyncio
async def test_get_catalog_by_id_name(model):
    # Формируем name существующего справочника в модели
    name = "1.0 Продукция"
    id = 101000000008
    model_ = await model
    task1 = model_.get_catalog_by_name(name)
    task2 = model_.get_catalog(id)
    catalogs = await asyncio.gather(task1, task2)
    for catalog in catalogs:
        assert isinstance(catalog, Catalog)
    with pytest.raises(WorkspaceException):
        await model_.get_catalog_by_name("Invalid name")
    with pytest.raises(WorkspaceException):
        await model_.get_catalog(1000000000000000000)


@pytest.mark.asyncio
async def test_get_views(multicube):
    """Тест получения представлений мультикуба."""
    multicube = await multicube
    views = await multicube.get_views(count=1)
    assert isinstance(views, list)
    assert isinstance(views[0], View)
    assert len(views) == 1


@pytest.mark.asyncio
async def test_get_view(multicube):
    """Тест получения представления мультикуба по его name."""
    multicube = await multicube
    name = "test_export_sub_view"
    view = await multicube.get_view_by_name(name)
    assert isinstance(view, View)
    assert view.name == name


@pytest.mark.asyncio
async def test_get_view_invalid_name(multicube):
    """Тест получения несуществующего представления мультикуба."""
    multicube = await multicube
    name = "invalid_view"
    view = await multicube.get_view_by_name(name)
    assert view is None
