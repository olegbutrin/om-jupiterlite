import asyncio
import sys

import pytest

from os_ws_sdk.common.exceptions import WorkspaceException
from os_ws_sdk.objects.model import Model

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_get_id_multicube(model_151ws):
    model_: Model = await model_151ws
    correct_name = "x_sdk_test_error"
    incorrect_name = "x_sdk_test_error1"
    id = await model_.get_id_multicube_by_name(correct_name)
    assert id == 102000000229
    with pytest.raises(WorkspaceException):
        await model_.get_id_multicube_by_name(incorrect_name)
