import asyncio
import sys

import pytest

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_change_cell_value(model):
    model = await model
    mk = await model.get_multicube_by_name("Тест изменения значений ячеек")
    cubes = [
        225000000075,
        225000000076,
        225000000077,
        225000000078,
        225000000079,
        225000000080,
    ]
    dimension = 5441970031
    values = [10, 11.6, "Текст", "02.04.2025", "04.02.2025", True]
    tasks = (
        mk.change_cell_value(value, cube, dimension)
        for cube, value in zip(cubes, values)
    )
    await asyncio.gather(*tasks)
