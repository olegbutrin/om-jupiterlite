import asyncio
import os
import sys
from zipfile import ZipFile

import pytest

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_export_lp_mapping(model_optimizer, path_for_download):
    """Тестирование экспорта оптимизационного запроса в LP файл."""

    model_ = await model_optimizer
    optimization_query_id = int(os.getenv("OPTIMIZATION_ID"))  # id оптимизационного запроса
    lp_file_name = await model_.export_lp_mapping(optimization_query_id, rf"{path_for_download}")

    # Проверяем наличие zip-файла
    zip_file_path = os.path.join(path_for_download, lp_file_name)
    assert os.path.exists(zip_file_path)
    
    # Проверяем, что zip-файл содержит LP-файл
    with ZipFile(zip_file_path, "r") as zip_file:
        assert "optimizer.lp" in zip_file.namelist()
        assert "optimizer.map" in zip_file.namelist()
