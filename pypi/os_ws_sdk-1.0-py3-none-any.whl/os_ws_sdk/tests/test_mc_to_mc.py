import asyncio
import sys

import pytest

from os_ws_sdk.objects.model import Model
from os_ws_sdk.objects.multicube import Multicube

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_mc_to_mc(model_151ws):
    """
    Тестирование экспорта-импорта данных из мультикуба в другой мультикуб.
    """

    model_: Model = await model_151ws
    mc_source: Multicube = await model_.get_multicube(
        102000000220
    )  #  x_SDK_test_export_view
    destination_mc_id = 102000000226  # x_SDK_test_mc_to_mc
    mc_destination: Multicube = await model_.get_multicube(
        102000000230
    )  # x_SDK_test_mc_from_mc
    task1 = mc_source.export_to_multicube(destination_mc_id=destination_mc_id)
    task2 = mc_destination.import_from_multicube(source_mc_id=mc_source.id)
    await asyncio.gather(task1, task2)
