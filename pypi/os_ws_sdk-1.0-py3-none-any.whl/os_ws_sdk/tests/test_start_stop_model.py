import asyncio
import os
import sys
from zipfile import ZipFile

import pytest

from os_ws_sdk.components.recalc_model_message import ReCalcModelMessage
from os_ws_sdk.objects.model import Model

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.dependency()
@pytest.mark.asyncio
async def test_stop(model: Model):
    """Тестирование остановки модели."""

    model_ = await model
    is_offline = model_.is_offline
    res = await model_.stop()
    if is_offline:
        assert res == False
    else:
        assert res == True
    model_info = model_.info()
    assert model_info.is_offline is True

@pytest.mark.dependency(depends=["test_stop"])
@pytest.mark.asyncio
async def test_start(model: Model):
    """Тестирование включения модели."""

    model_ = await model
    res = await model_.start()
    assert res == True
    model_info = model_.info()
    assert model_info.is_offline is False

