import asyncio
import sys

import pytest

from os_ws_sdk.components.base_message import BaseMessage

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_logger_error(workspace):
    """
    Тестирование логгера ошибок в методах get и post в _connector.
    """
    await workspace._connector._get("test_url")
    await workspace._connector._post("test_url", BaseMessage())
