import asyncio
import sys

import pytest

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


@pytest.mark.asyncio
async def test_run_script(model_iol):
    model1 = await model_iol
    scritp_id = 117000000011
    result = "Request 'Оптимизационный расчет по месяцам': выполнен\n"
    response = await model1.run_script(scritp_id)
    assert result == response
