import os

import pytest
from dotenv import load_dotenv
from pathlib import Path

from os_ws_sdk.api.v1.connector_v1 import ConnectorV1
from os_ws_sdk.objects.workspace import Workspace
from os_ws_sdk.components.download_format import (
    DownloadFormat,
    DownloadFormatOM,
)

load_dotenv()


@pytest.fixture
def valid_connector():
    """Фикстура для создания объекта Connector с токеном из переменной окружения."""
    return ConnectorV1(os.getenv("TOKEN117WS")) #ConnectorV1(os.getenv("TOKENSDKWS"))


@pytest.fixture
def invalid_connector():
    """Фикстура для создания объекта Connector с неверным токеном."""
    return ConnectorV1("invalid_token")


@pytest.fixture
def workspace(valid_connector):
    """Фикстура для создания объекта Workspace с базовым URL и верным коннектором."""
    # ws = Workspace("https://sdk-ws.optisoft.net", valid_connector)
    ws = Workspace(os.getenv("WS"), valid_connector)
    return ws


@pytest.fixture
def invalid_workspace(invalid_connector):
    """Фикстура для создания объекта Workspace с базовым URL и неверным коннектором."""
    # ws = Workspace("https://sdk-ws.optisoft.net/", invalid_connector)
    ws = Workspace(os.getenv("WS"), invalid_connector)
    return ws


@pytest.fixture
def expected_ws_name():
    """Фикстура для создания ожидаемого имени рабочего пространства."""
    return "WORKSPACE"


@pytest.fixture
def expected_model_id():
    """Фикстура для создания ожидаемого идентификатора модели."""
    return os.getenv("MODEL_ID") # "00001b433c05e1f5c523118d4637cfd8"

@pytest.fixture
def expected_model_id_optimizer():
    """Фикстура для создания ожидаемого идентификатора модели."""
    return os.getenv("MODEL_ID_LP")

@pytest.fixture
def expected_model_name():
    """Фикстура для создания ожидаемого имени модели."""
    return os.getenv("MODEL_NAME") #"TEST_SDK ##1.0"


@pytest.fixture
def expected_multicube_name():
    """Фикстура для создания ожидаемого имени модели."""
    return os.getenv("MC_NAME")  # "x_SDK_test_export_view"


@pytest.fixture
def expected_multicube_id():
    """Фикстура для создания ожидаемого идентификатора модели."""
    return os.getenv("MC_ID") #102000000002


@pytest.fixture
def path_for_download():
    """Фикстура для создания пути для скачивания файла."""
    DATA_PATH = Path(os.getenv("DOWNLOAD_PATH_TEST", "data")).resolve()
    return DATA_PATH


@pytest.fixture
def entity_name():
    """Фикстура, возвращающая название существующей сущности (мультикуба или справочника)."""
    return os.getenv("MC_NAME")


@pytest.fixture
async def model_optimizer(workspace, expected_model_id_optimizer):
    """Фикстура, возвращающая модель."""
    return await workspace.get_model(expected_model_id_optimizer)


@pytest.fixture
async def model(workspace, expected_model_id):
    """Фикстура, возвращающая модель."""
    return await workspace.get_model(expected_model_id)


@pytest.fixture
async def multicube(model, entity_name):
    """Фикстура, возвращающая мультикуб."""
    model_ = await model
    return await model_.get_multicube_by_name(entity_name)


@pytest.fixture
def path_file_solution_lp():
    """Фикстура для создания пути для загрузки solution_lp."""
    LP_PATH = Path(os.getenv("PATH_FILE_SOLUTION_LP", "lp_files")).resolve()
    return LP_PATH


@pytest.fixture
def path_file_view_import():
    """Фикстура для создания пути для загрузки представления в разных форматах."""
    VIEW_PATH = Path(os.getenv("PATH_FILE_VIEW_IMPORT", "views_import")).resolve()
    return VIEW_PATH


@pytest.fixture
async def multicubes_for_import_view(model):
    model_ = await model
    names = (
        "x_SDK_test_import_view_csv",
        "x_SDK_test_import_view_txt",
        "x_SDK_test_import_view_xls",
        "x_SDK_test_import_view_xlsx",
    )
    multicubes = [await model_.get_multicube_by_name(name) for name in names]
    return multicubes


@pytest.fixture
def download_format_om():
    """Фикстура, возвращающая формат скачивания OM."""
    format = DownloadFormatOM
    return format


@pytest.fixture
async def view(multicube):
    """Фикстура, возвращающая представление."""
    view_name = os.getenv("MC_VIEW_NAME")  # "test_export_sub_view"
    multicube_ = await multicube
    view = await multicube_.get_view_by_name(view_name)
    return view


@pytest.fixture
async def multicube_for_import_om(model):
    model_ = await model
    name = os.getenv("MC_NAME")  # "Тест импорт"
    multicube = await model_.get_multicube_by_name(name)
    return multicube


@pytest.fixture
async def view_for_import_om(multicube_for_import_om):
    multicube = await multicube_for_import_om
    name_view = os.getenv("MC_VIEW_NAME")  # "Тест импорт view"
    return await multicube.get_view_by_name(name_view)


@pytest.fixture
async def multicube_for_export_df():
    # con = ConnectorV1(os.getenv("TOKEN151WS"))
    con = ConnectorV1(os.getenv("TOKEN117WS"))
    # ws = Workspace("https://ws151.optimacros.com", con)
    ws = Workspace(os.getenv("WS"), con)
    # model_id = "d1d06bff75ae55bab84ee15a8a341303"
    model_id = os.getenv("MODEL_ID")
    # multicube_id = 102000000180
    multicube_id = os.getenv("MC_ID")
    model = await ws.get_model(model_id)
    multicube = await model.get_multicube(multicube_id)
    return multicube


@pytest.fixture
async def view_for_export_df():
    # con = ConnectorV1(os.getenv("TOKEN151WS"))
    # ws = Workspace("https://ws151.optimacros.com", con)
    # model_id = "d1d06bff75ae55bab84ee15a8a341303"
    # multicube_id = 102000000039
    con = ConnectorV1(os.getenv("TOKEN117WS"))
    ws = Workspace(os.getenv("WS"), con)
    model_id = os.getenv("MODEL_ID")
    multicube_id = os.getenv("MC_ID")
    multicube_name = (os.getenv("MC_NAME")) #("Производство L12.2 (установка-тип продукта-продукт) + num + hours (сценарии)")
    name_view = os.getenv("MC_VIEW_NAME_1") #("Ошибки последнего шага")
    model = await ws.get_model(model_id)
    multicube = await model.get_multicube(multicube_id)
    view = await multicube.get_view_by_name(name_view)
    return view


@pytest.fixture
async def model_iol(workspace):
    model = await workspace.get_model(os.getenv("MODEL_ID"))  # "961758c052c99c5bfefc57f0be28f747"
    return model


@pytest.fixture
async def model_151ws():
    ws151 = Workspace(
        "https://ws151.optimacros.com", ConnectorV1(os.getenv("TOKEN151WS"))
    )
    model_151ws = await ws151.get_model("d1d06bff75ae55bab84ee15a8a341303")
    return model_151ws
